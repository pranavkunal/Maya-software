import json

import pytest

from core.object_types import SceneObjectType
from core.scene import Scene
from core.scene_object import SceneObject
from core.transform import Vector3
from sceneio.scene_serializer import (
    SceneSerializationError,
    load_scene,
    save_scene,
    scene_from_dict,
    scene_to_dict,
)


def test_save_and_load_roundtrip(tmp_path):
    scene = Scene.create_default("MyScene")
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH)
    cube.transform.position = Vector3(1, 2, 3)
    scene.add_object(cube)

    path = tmp_path / "test_scene.mya"
    save_scene(scene, path)
    assert path.exists()

    loaded = load_scene(path)
    names = {o.name for o in loaded.all_objects()}
    assert names == {"Camera", "Light", "Cube"}

    loaded_cube = next(o for o in loaded.all_objects() if o.name == "Cube")
    assert loaded_cube.transform.position.as_tuple() == (1.0, 2.0, 3.0)


def test_save_and_load_preserves_hierarchy(tmp_path):
    scene = Scene()
    group = SceneObject(name="Group", type=SceneObjectType.GROUP)
    scene.add_object(group)
    child = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(child, parent_id=group.id)

    path = tmp_path / "hierarchy.mya"
    save_scene(scene, path)
    loaded = load_scene(path)

    loaded_group = next(o for o in loaded.all_objects() if o.name == "Group")
    loaded_child = next(o for o in loaded.all_objects() if o.name == "Cube")
    assert loaded_child.parent_id == loaded_group.id
    assert loaded_child.id in loaded_group.children_ids


def test_load_missing_file_raises(tmp_path):
    missing_path = tmp_path / "does_not_exist.mya"
    with pytest.raises(SceneSerializationError):
        load_scene(missing_path)


def test_load_invalid_json_raises(tmp_path):
    path = tmp_path / "bad.mya"
    path.write_text("{not valid json", encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_load_missing_version_raises(tmp_path):
    path = tmp_path / "no_version.mya"
    path.write_text(json.dumps({"objects": []}), encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_load_unsupported_version_raises(tmp_path):
    path = tmp_path / "future.mya"
    path.write_text(json.dumps({"version": 999, "objects": [], "root_ids": []}), encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_scene_to_dict_from_dict_roundtrip_in_memory():
    scene = Scene.create_default()
    data = scene_to_dict(scene)
    restored = scene_from_dict(data)
    assert len(restored) == len(scene)
    assert {o.name for o in restored.all_objects()} == {o.name for o in scene.all_objects()}
