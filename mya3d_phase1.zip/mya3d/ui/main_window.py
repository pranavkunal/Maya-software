"""Main application window.

MainWindow's job is assembly and wiring only: it builds the menu bar,
toolbar, docks, and status bar, and connects them to the Scene /
SelectionManager / CommandStack / ToolManager. Actual widget behavior
lives in the individual ui.* modules; actual data logic lives in
core/editor. This keeps MainWindow from becoming a god-object as the
app grows in later phases.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QFileDialog,
    QLabel,
    QMainWindow,
    QMessageBox,
    QStatusBar,
)

from app.settings import AppSettings
from core.object_types import SceneObjectType
from core.scene import Scene
from core.transform import Transform
from editor.commands import (
    CommandStack,
    CreateObjectCommand,
    DeleteObjectCommand,
    DuplicateObjectCommand,
    TransformObjectCommand,
)
from editor.selection import SelectionManager
from editor.tools import ToolManager, ToolType
from sceneio.scene_serializer import SceneSerializationError, load_scene, save_scene
from ui.outliner import OutlinerDock
from ui.properties import PropertiesDock
from ui.styles import DARK_THEME_STYLESHEET
from ui.timeline import TimelineDock
from ui.toolbar import MainToolBar
from ui.viewport import ViewportWidget

logger = logging.getLogger(__name__)

APP_TITLE = "MYA 3D Editor"

_COMING_SOON = "Coming in a future phase."


class MainWindow(QMainWindow):
    """The application's main window."""

    def __init__(self, parent: Optional[QMainWindow] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(APP_TITLE)
        self.resize(1400, 850)
        self.setMinimumSize(1024, 640)
        self.setStyleSheet(DARK_THEME_STYLESHEET)

        # -- domain state ------------------------------------------------
        self.settings = AppSettings()
        self.scene: Scene = Scene.create_default("Untitled")
        self.selection = SelectionManager()
        self.command_stack = CommandStack()
        self.tool_manager = ToolManager()
        self._current_scene_path: Optional[str] = None

        # -- UI ------------------------------------------------------------
        self._build_toolbar()
        self._build_docks()
        self._build_central_viewport()
        self._build_menu_bar()
        self._build_status_bar()

        self._connect_domain_signals()
        self._restore_window_state()

        self._update_window_title()
        self.status_bar.showMessage("Ready", 4000)
        logger.info("MainWindow initialized")

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def _build_central_viewport(self) -> None:
        self.viewport = ViewportWidget(self)
        self.setCentralWidget(self.viewport)

    def _build_toolbar(self) -> None:
        self.toolbar = MainToolBar(self)
        self.addToolBar(self.toolbar)

        self.toolbar.action_new.triggered.connect(self.action_new_scene)
        self.toolbar.action_open.triggered.connect(self.action_open_scene)
        self.toolbar.action_save.triggered.connect(self.action_save_scene)
        self.toolbar.action_undo.triggered.connect(self.action_undo)
        self.toolbar.action_redo.triggered.connect(self.action_redo)

        self.toolbar.action_select.triggered.connect(
            lambda: self.tool_manager.set_active_tool(ToolType.SELECT)
        )
        self.toolbar.action_move.triggered.connect(
            lambda: self.tool_manager.set_active_tool(ToolType.MOVE)
        )
        self.toolbar.action_rotate.triggered.connect(
            lambda: self.tool_manager.set_active_tool(ToolType.ROTATE)
        )
        self.toolbar.action_scale.triggered.connect(
            lambda: self.tool_manager.set_active_tool(ToolType.SCALE)
        )

    def _build_docks(self) -> None:
        self.outliner_dock = OutlinerDock(self.scene, self.selection, self.command_stack, self)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.outliner_dock)

        self.properties_dock = PropertiesDock(self.scene, self.selection, self.command_stack, self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.properties_dock)

        self.timeline_dock = TimelineDock(self)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.timeline_dock)

    def _build_status_bar(self) -> None:
        self.status_bar = QStatusBar(self)
        self.setStatusBar(self.status_bar)

        self._status_selection_label = QLabel("No selection")
        self._status_frame_label = QLabel("Frame: 1")
        self._status_tool_label = QLabel("Tool: Select")
        for label in (self._status_selection_label, self._status_frame_label, self._status_tool_label):
            self.status_bar.addPermanentWidget(label)

    # -- Menu bar -------------------------------------------------------
    def _build_menu_bar(self) -> None:
        menu_bar = self.menuBar()

        self._build_file_menu(menu_bar)
        self._build_edit_menu(menu_bar)
        self._build_create_menu(menu_bar)
        self._build_select_menu(menu_bar)
        self._build_modify_menu(menu_bar)
        self._build_display_menu(menu_bar)
        self._build_windows_menu(menu_bar)
        self._build_help_menu(menu_bar)

    def _build_file_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&File")

        act_new = menu.addAction("New Scene")
        act_new.triggered.connect(self.action_new_scene)

        act_open = menu.addAction("Open Scene...")
        act_open.triggered.connect(self.action_open_scene)

        act_save = menu.addAction("Save Scene")
        act_save.triggered.connect(self.action_save_scene)

        act_save_as = menu.addAction("Save Scene As...")
        act_save_as.triggered.connect(self.action_save_scene_as)

        menu.addSeparator()

        act_import = menu.addAction("Import...")
        act_import.triggered.connect(lambda: self._show_coming_soon("Import"))

        act_export = menu.addAction("Export...")
        act_export.triggered.connect(lambda: self._show_coming_soon("Export"))

        menu.addSeparator()

        act_exit = menu.addAction("Exit")
        act_exit.triggered.connect(self.close)

    def _build_edit_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Edit")

        self.action_undo_menu = menu.addAction("Undo")
        self.action_undo_menu.triggered.connect(self.action_undo)

        self.action_redo_menu = menu.addAction("Redo")
        self.action_redo_menu.triggered.connect(self.action_redo)

        menu.addSeparator()

        act_cut = menu.addAction("Cut")
        act_cut.triggered.connect(lambda: self._show_coming_soon("Cut"))

        act_copy = menu.addAction("Copy")
        act_copy.triggered.connect(lambda: self._show_coming_soon("Copy"))

        act_paste = menu.addAction("Paste")
        act_paste.triggered.connect(lambda: self._show_coming_soon("Paste"))

        act_delete = menu.addAction("Delete")
        act_delete.triggered.connect(self.action_delete_selected)

    def _build_create_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Create")

        act_group = menu.addAction("Group")
        act_group.triggered.connect(lambda: self.action_create_object(SceneObjectType.GROUP, "Group"))

        act_null = menu.addAction("Null")
        act_null.triggered.connect(lambda: self.action_create_object(SceneObjectType.NULL, "Null"))

        act_camera = menu.addAction("Camera")
        act_camera.triggered.connect(lambda: self.action_create_object(SceneObjectType.CAMERA, "Camera"))

        act_light = menu.addAction("Light")
        act_light.triggered.connect(lambda: self.action_create_object(SceneObjectType.LIGHT, "Light"))

        menu.addSeparator()

        act_cube = menu.addAction("Cube")
        act_cube.triggered.connect(lambda: self.action_create_primitive("cube"))

        act_sphere = menu.addAction("Sphere")
        act_sphere.triggered.connect(lambda: self.action_create_primitive("sphere"))

        act_cylinder = menu.addAction("Cylinder")
        act_cylinder.triggered.connect(lambda: self.action_create_primitive("cylinder"))

        act_plane = menu.addAction("Plane")
        act_plane.triggered.connect(lambda: self.action_create_primitive("plane"))

    def _build_select_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Select")

        act_all = menu.addAction("Select All")
        act_all.triggered.connect(self.action_select_all)

        act_none = menu.addAction("Deselect All")
        act_none.triggered.connect(self.action_deselect_all)

    def _build_modify_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Modify")

        act_freeze = menu.addAction("Freeze Transform")
        act_freeze.triggered.connect(self.action_freeze_transform)

        act_reset = menu.addAction("Reset Transform")
        act_reset.triggered.connect(self.action_reset_transform)

        act_duplicate = menu.addAction("Duplicate")
        act_duplicate.triggered.connect(self.action_duplicate_selected)

    def _build_display_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Display")

        act_grid = menu.addAction("Grid")
        act_grid.setCheckable(True)
        act_grid.setChecked(True)
        act_grid.triggered.connect(lambda checked: self._show_coming_soon("Grid toggle"))

        act_wireframe = menu.addAction("Wireframe")
        act_wireframe.setCheckable(True)
        act_wireframe.triggered.connect(lambda checked: self._show_coming_soon("Wireframe display mode"))

        act_shaded = menu.addAction("Shaded")
        act_shaded.setCheckable(True)
        act_shaded.setChecked(True)
        act_shaded.triggered.connect(lambda checked: self._show_coming_soon("Shaded display mode"))

        menu.addSeparator()

        act_outliner = menu.addAction("Show/Hide Outliner")
        act_outliner.setCheckable(True)
        act_outliner.setChecked(True)
        act_outliner.toggled.connect(self.outliner_dock.setVisible)
        self.outliner_dock.visibilityChanged.connect(act_outliner.setChecked)

        act_properties = menu.addAction("Show/Hide Properties")
        act_properties.setCheckable(True)
        act_properties.setChecked(True)
        act_properties.toggled.connect(self.properties_dock.setVisible)
        self.properties_dock.visibilityChanged.connect(act_properties.setChecked)

        act_timeline = menu.addAction("Show/Hide Timeline")
        act_timeline.setCheckable(True)
        act_timeline.setChecked(True)
        act_timeline.toggled.connect(self.timeline_dock.setVisible)
        self.timeline_dock.visibilityChanged.connect(act_timeline.setChecked)

    def _build_windows_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Windows")

        act_reset_layout = menu.addAction("Reset Layout")
        act_reset_layout.triggered.connect(self.action_reset_layout)

    def _build_help_menu(self, menu_bar) -> None:
        menu = menu_bar.addMenu("&Help")

        act_about = menu.addAction("About MYA 3D Editor")
        act_about.triggered.connect(self.action_show_about)

    # ------------------------------------------------------------------
    # Domain signal wiring
    # ------------------------------------------------------------------
    def _connect_domain_signals(self) -> None:
        self.selection.selection_changed.connect(self._on_selection_changed)
        self.tool_manager.tool_changed.connect(self._on_tool_changed)
        self.timeline_dock.timeline.frame_changed.connect(self._on_frame_changed)
        self.scene.object_added.connect(lambda obj: self.selection.select(obj.id))

    def _on_selection_changed(self, selected_ids) -> None:
        if not selected_ids:
            self._status_selection_label.setText("No selection")
            return
        if len(selected_ids) == 1:
            obj = self.scene.get_object(selected_ids[0])
            name = obj.name if obj else "?"
            self._status_selection_label.setText(f"Selected: {name}")
        else:
            self._status_selection_label.setText(f"Selected: {len(selected_ids)} objects")

    def _on_tool_changed(self, tool: ToolType) -> None:
        self._status_tool_label.setText(f"Tool: {str(tool).capitalize()}")

    def _on_frame_changed(self, frame: int) -> None:
        self._status_frame_label.setText(f"Frame: {frame}")

    # ------------------------------------------------------------------
    # File actions
    # ------------------------------------------------------------------
    def action_new_scene(self) -> None:
        self.command_stack.clear()
        self.selection.deselect_all()
        self.scene.clear()
        new_scene = Scene.create_default("Untitled")
        self._replace_scene(new_scene)
        self._current_scene_path = None
        self._update_window_title()
        self.status_bar.showMessage("New scene created", 3000)
        logger.info("New scene created")

    def action_open_scene(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Scene", "", "MYA Scene Files (*.mya);;All Files (*)"
        )
        if not path:
            return
        try:
            loaded = load_scene(path)
        except SceneSerializationError as exc:
            logger.error("Failed to open scene: %s", exc)
            QMessageBox.critical(self, "Open Scene Failed", str(exc))
            return

        self.command_stack.clear()
        self.selection.deselect_all()
        self._replace_scene(loaded)
        self._current_scene_path = path
        self._update_window_title()
        self.status_bar.showMessage(f"Scene loaded: {path}", 4000)
        logger.info("Scene opened from %s", path)

    def action_save_scene(self) -> None:
        if self._current_scene_path is None:
            self.action_save_scene_as()
            return
        self._save_to_path(self._current_scene_path)

    def action_save_scene_as(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Scene As", "untitled.mya", "MYA Scene Files (*.mya);;All Files (*)"
        )
        if not path:
            return
        if not path.lower().endswith(".mya"):
            path += ".mya"
        self._save_to_path(path)

    def _save_to_path(self, path: str) -> None:
        try:
            save_scene(self.scene, path)
        except SceneSerializationError as exc:
            logger.error("Failed to save scene: %s", exc)
            QMessageBox.critical(self, "Save Scene Failed", str(exc))
            return
        self._current_scene_path = path
        self._update_window_title()
        self.status_bar.showMessage(f"Scene saved: {path}", 4000)

    def _replace_scene(self, new_scene: Scene) -> None:
        """Swap in a new Scene instance and rewire docks to observe it.

        Signals are per-Scene-instance (see core.signal.Signal), so
        when the whole Scene object is replaced (New/Open), the docks'
        old connections are simply left with their now-orphaned Scene
        and we reconnect them to the new one directly.
        """
        self.scene = new_scene
        self.outliner_dock.tree._scene = new_scene  # noqa: SLF001 - internal rewire
        self.properties_dock.panel._scene = new_scene  # noqa: SLF001
        self.outliner_dock.tree._scene.object_added.connect(self.outliner_dock.tree._on_object_added)
        self.outliner_dock.tree._scene.object_removed.connect(self.outliner_dock.tree._on_object_removed)
        self.outliner_dock.tree._scene.object_renamed.connect(self.outliner_dock.tree._on_object_renamed)
        self.outliner_dock.tree._scene.scene_reset.connect(self.outliner_dock.tree.rebuild_from_scene)
        self.properties_dock.panel._scene.object_changed.connect(self.properties_dock.panel._on_object_changed)
        self.properties_dock.panel._scene.object_renamed.connect(self.properties_dock.panel._on_object_changed)
        self.properties_dock.panel._scene.object_removed.connect(self.properties_dock.panel._on_object_removed)
        self.scene.object_added.connect(lambda obj: self.selection.select(obj.id))
        self.outliner_dock.tree.rebuild_from_scene()
        self.properties_dock.panel._show_selected_object(None)  # noqa: SLF001

    def _update_window_title(self) -> None:
        scene_label = self._current_scene_path or "Untitled"
        self.setWindowTitle(f"{APP_TITLE} \u2013 {scene_label}")

    # ------------------------------------------------------------------
    # Edit actions
    # ------------------------------------------------------------------
    def action_undo(self) -> None:
        if self.command_stack.undo():
            self.status_bar.showMessage("Undo", 2000)
        else:
            self.status_bar.showMessage("Nothing to undo", 2000)

    def action_redo(self) -> None:
        if self.command_stack.redo():
            self.status_bar.showMessage("Redo", 2000)
        else:
            self.status_bar.showMessage("Nothing to redo", 2000)

    def action_delete_selected(self) -> None:
        selected_ids = self.selection.selected_ids()
        if not selected_ids:
            self.status_bar.showMessage("Nothing selected to delete", 2000)
            return
        for object_id in selected_ids:
            if object_id not in self.scene:
                continue
            self.command_stack.execute(DeleteObjectCommand(self.scene, object_id))
        self.selection.deselect_all()
        self.status_bar.showMessage("Deleted selection", 2000)

    # ------------------------------------------------------------------
    # Create actions
    # ------------------------------------------------------------------
    def action_create_object(self, object_type: SceneObjectType, base_name: str) -> None:
        name = self._generate_unique_name(base_name)
        transform = Transform()
        if object_type == SceneObjectType.LIGHT:
            transform.position.y = 2.0
        command = CreateObjectCommand(self.scene, name, object_type, transform=transform)
        self.command_stack.execute(command)
        self.status_bar.showMessage(f"Created {name}", 2000)

    def action_create_primitive(self, primitive: str) -> None:
        base_name = primitive.capitalize()
        name = self._generate_unique_name(base_name)
        command = CreateObjectCommand(
            self.scene,
            name,
            SceneObjectType.MESH,
            metadata={"primitive": primitive},
        )
        self.command_stack.execute(command)
        self.status_bar.showMessage(f"Created {name}", 2000)

    def _generate_unique_name(self, base_name: str) -> str:
        existing = {obj.name for obj in self.scene.all_objects()}
        if base_name not in existing:
            return base_name
        index = 1
        candidate = f"{base_name}{index}"
        while candidate in existing:
            index += 1
            candidate = f"{base_name}{index}"
        return candidate

    # ------------------------------------------------------------------
    # Select actions
    # ------------------------------------------------------------------
    def action_select_all(self) -> None:
        all_ids = [obj.id for obj in self.scene.all_objects()]
        self.selection.select_multiple(all_ids)

    def action_deselect_all(self) -> None:
        self.selection.deselect_all()

    # ------------------------------------------------------------------
    # Modify actions
    # ------------------------------------------------------------------
    def action_freeze_transform(self) -> None:
        obj_id = self.selection.primary_selected_id()
        if obj_id is None:
            self.status_bar.showMessage("Nothing selected", 2000)
            return
        obj = self.scene.require_object(obj_id)
        frozen_transform = obj.transform.copy()
        frozen_transform.freeze()
        self.command_stack.execute(TransformObjectCommand(self.scene, obj_id, frozen_transform))
        self.status_bar.showMessage(f"Froze transform on {obj.name}", 2000)

    def action_reset_transform(self) -> None:
        obj_id = self.selection.primary_selected_id()
        if obj_id is None:
            self.status_bar.showMessage("Nothing selected", 2000)
            return
        obj = self.scene.require_object(obj_id)
        reset_transform = obj.transform.copy()
        reset_transform.reset()
        self.command_stack.execute(TransformObjectCommand(self.scene, obj_id, reset_transform))
        self.status_bar.showMessage(f"Reset transform on {obj.name}", 2000)

    def action_duplicate_selected(self) -> None:
        obj_id = self.selection.primary_selected_id()
        if obj_id is None:
            self.status_bar.showMessage("Nothing selected", 2000)
            return
        command = DuplicateObjectCommand(self.scene, obj_id)
        self.command_stack.execute(command)
        duplicate = command.duplicate_object
        self.selection.select(duplicate.id)
        self.status_bar.showMessage(f"Duplicated as {duplicate.name}", 2000)

    # ------------------------------------------------------------------
    # Windows / Help actions
    # ------------------------------------------------------------------
    def action_reset_layout(self) -> None:
        self.outliner_dock.setVisible(True)
        self.properties_dock.setVisible(True)
        self.timeline_dock.setVisible(True)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.outliner_dock)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.properties_dock)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.timeline_dock)
        self.outliner_dock.setFloating(False)
        self.properties_dock.setFloating(False)
        self.timeline_dock.setFloating(False)
        self.settings.clear_all()
        self.status_bar.showMessage("Layout reset", 2000)
        logger.info("Layout reset to defaults")

    def action_show_about(self) -> None:
        QMessageBox.about(
            self,
            "About MYA 3D Editor",
            "<h3>MYA 3D Editor</h3>"
            "<p>Phase 1: Professional editor foundation.</p>"
            "<p>An original application inspired by the workflow of "
            "professional 3D content creation tools. Not affiliated with "
            "or endorsed by Autodesk.</p>",
        )

    def _show_coming_soon(self, feature_name: str) -> None:
        self.status_bar.showMessage(f"{feature_name}: {_COMING_SOON}", 3000)

    # ------------------------------------------------------------------
    # Window geometry / state persistence
    # ------------------------------------------------------------------
    def _restore_window_state(self) -> None:
        geometry = self.settings.load_window_geometry()
        if geometry is not None:
            self.restoreGeometry(geometry)
        state = self.settings.load_window_state()
        if state is not None:
            self.restoreState(state)

    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802 (Qt override)
        try:
            self.settings.save_window_geometry(self.saveGeometry())
            self.settings.save_window_state(self.saveState())
            self.settings.sync()
        except Exception:  # pragma: no cover - defensive, must not block close
            logger.exception("Failed to persist window state on close")
        logger.info("MainWindow closing")
        super().closeEvent(event)
