"""Central viewport widget.

Phase 1 has no real 3D renderer. ``ViewportWidget`` draws a simple
placeholder (dark background + label + subtle grid hint) but is
already structured around a ``RendererInterface`` slot so Phase 2 can
call ``set_renderer(some_renderer)`` and start driving real frames
through ``render()`` without the surrounding widget/layout code
changing.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from graphics.renderer_interface import RendererInterface
from ui.styles import COLOR_BORDER, COLOR_TEXT_SECONDARY, COLOR_VIEWPORT_BG

logger = logging.getLogger(__name__)


class ViewportSurface(QFrame):
    """The actual drawing surface of the viewport.

    Separated from ``ViewportWidget`` (which also owns the small
    perspective/shading toolbar) so that in Phase 2 this specific
    widget's native window handle/paint surface can be handed to the
    renderer (or replaced by a QOpenGLWidget/QRhiWidget subclass)
    without touching the surrounding chrome.
    """

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("ViewportFrame")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setMinimumSize(200, 150)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)

        self._renderer: Optional[RendererInterface] = None
        self._placeholder_text = "3D Viewport"
        self._subtext = "Renderer not yet initialized \u2013 arrives in Phase 2"

    # -- future renderer integration point ---------------------------
    def set_renderer(self, renderer: Optional[RendererInterface]) -> None:
        """Attach a RendererInterface implementation (Phase 2+)."""
        if self._renderer is not None:
            self._renderer.shutdown()
        self._renderer = renderer
        if self._renderer is not None:
            self._renderer.initialize(self)
            self._renderer.resize(self.width(), self.height())
        self.update()

    def has_renderer(self) -> bool:
        return self._renderer is not None

    # -- Qt event handlers --------------------------------------------
    def resizeEvent(self, event) -> None:  # noqa: N802 (Qt override)
        super().resizeEvent(event)
        if self._renderer is not None:
            self._renderer.resize(self.width(), self.height())

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt override)
        if self._renderer is not None:
            # Phase 2: the renderer would draw here (or the widget
            # would be a QOpenGLWidget/QRhiWidget and paintGL would be
            # used instead of paintEvent entirely).
            self._renderer.render()
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor(COLOR_VIEWPORT_BG))

        pen = QPen(QColor(COLOR_BORDER))
        pen.setWidth(1)
        painter.setPen(pen)
        painter.drawRect(self.rect().adjusted(0, 0, -1, -1))

        painter.setPen(QColor(COLOR_TEXT_SECONDARY))
        font = painter.font()
        font.setPointSize(13)
        painter.setFont(font)
        title_rect = self.rect().adjusted(0, -12, 0, -12)
        painter.drawText(title_rect, Qt.AlignmentFlag.AlignCenter, self._placeholder_text)

        font.setPointSize(9)
        painter.setFont(font)
        sub_rect = self.rect().adjusted(0, 16, 0, 16)
        painter.drawText(sub_rect, Qt.AlignmentFlag.AlignCenter, self._subtext)
        painter.end()

    def mousePressEvent(self, event) -> None:  # noqa: N802 (Qt override)
        # Phase 1: just take focus so keyboard shortcuts scoped to the
        # viewport work; real object picking arrives with the renderer.
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        super().mousePressEvent(event)

    def keyPressEvent(self, event) -> None:  # noqa: N802 (Qt override)
        # Never let an unhandled key crash the app; just pass it along.
        super().keyPressEvent(event)


class ViewportWidget(QWidget):
    """Central viewport panel: a small toolbar plus the drawing surface."""

    shading_mode_changed = Signal(str)
    view_preset_changed = Signal(str)

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._toolbar = self._build_toolbar()
        layout.addWidget(self._toolbar)

        self.surface = ViewportSurface(self)
        layout.addWidget(self.surface, stretch=1)

    def _build_toolbar(self) -> QWidget:
        bar = QWidget(self)
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(6, 4, 6, 4)
        bar_layout.setSpacing(10)

        bar_layout.addWidget(self._labeled_combo(
            "View", ["Perspective", "Top", "Front", "Side", "Back", "Left", "Bottom"],
            self.view_preset_changed,
        ))
        bar_layout.addWidget(self._labeled_combo(
            "Shading", ["Shaded", "Wireframe", "Shaded + Wireframe"],
            self.shading_mode_changed,
        ))
        bar_layout.addStretch(1)
        return bar

    def _labeled_combo(self, label_text: str, items: list, signal: Signal) -> QWidget:
        container = QWidget(self)
        row = QHBoxLayout(container)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)
        label = QLabel(label_text)
        label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY};")
        combo = QComboBox()
        combo.addItems(items)
        combo.setToolTip(f"{label_text} (Phase 1 placeholder \u2013 does not yet affect rendering)")
        combo.currentTextChanged.connect(signal.emit)
        row.addWidget(label)
        row.addWidget(combo)
        return container

    # -- public API used by MainWindow --------------------------------
    def set_renderer(self, renderer: Optional[RendererInterface]) -> None:
        self.surface.set_renderer(renderer)
