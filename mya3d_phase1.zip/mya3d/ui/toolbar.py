"""Main toolbar.

Built entirely from QAction objects (also used by the menu bar) so
there is a single source of truth per command instead of duplicated
button/menu-item logic.
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QSize
from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import QMainWindow, QToolBar


class MainToolBar(QToolBar):
    """The primary application toolbar.

    ``actions`` (a plain namespace-like dict) is populated with the
    QActions that MainWindow's menu bar also reuses, so File/Edit
    behavior is defined exactly once.
    """

    def __init__(self, parent: Optional[QMainWindow] = None) -> None:
        super().__init__("Main Toolbar", parent)
        self.setObjectName("MainToolBar")
        self.setMovable(False)
        self.setFloatable(False)
        self.setIconSize(QSize(20, 20))

        self.action_new: QAction
        self.action_open: QAction
        self.action_save: QAction
        self.action_undo: QAction
        self.action_redo: QAction
        self.action_select: QAction
        self.action_move: QAction
        self.action_rotate: QAction
        self.action_scale: QAction

        self._build()

    def _build(self) -> None:
        self.action_new = QAction("New", self)
        self.action_new.setToolTip("New Scene")
        self.addAction(self.action_new)

        self.action_open = QAction("Open", self)
        self.action_open.setToolTip("Open Scene...")
        self.addAction(self.action_open)

        self.action_save = QAction("Save", self)
        self.action_save.setToolTip("Save Scene")
        self.addAction(self.action_save)

        self.addSeparator()

        self.action_undo = QAction("Undo", self)
        self.action_undo.setToolTip("Undo")
        self.addAction(self.action_undo)

        self.action_redo = QAction("Redo", self)
        self.action_redo.setToolTip("Redo")
        self.addAction(self.action_redo)

        self.addSeparator()

        # Editor tools: mutually exclusive, checkable.
        tool_group = QActionGroup(self)
        tool_group.setExclusive(True)

        self.action_select = QAction("Select", self)
        self.action_select.setToolTip("Select Tool (Q)")
        self.action_select.setCheckable(True)
        self.action_select.setChecked(True)
        tool_group.addAction(self.action_select)
        self.addAction(self.action_select)

        self.action_move = QAction("Move", self)
        self.action_move.setToolTip("Move Tool (W) \u2013 gizmo arrives in Phase 2")
        self.action_move.setCheckable(True)
        tool_group.addAction(self.action_move)
        self.addAction(self.action_move)

        self.action_rotate = QAction("Rotate", self)
        self.action_rotate.setToolTip("Rotate Tool (E) \u2013 gizmo arrives in Phase 2")
        self.action_rotate.setCheckable(True)
        tool_group.addAction(self.action_rotate)
        self.addAction(self.action_rotate)

        self.action_scale = QAction("Scale", self)
        self.action_scale.setToolTip("Scale Tool (R) \u2013 gizmo arrives in Phase 2")
        self.action_scale.setCheckable(True)
        tool_group.addAction(self.action_scale)
        self.addAction(self.action_scale)

        self._tool_group = tool_group
