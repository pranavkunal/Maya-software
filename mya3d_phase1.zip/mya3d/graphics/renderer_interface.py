"""Renderer abstraction.

This module intentionally contains NO real rendering code. Phase 1's
ViewportWidget depends only on this interface, never on a concrete
renderer, so Phase 2 can drop in a ModernGL/OpenGL implementation
(or swap renderers later) without changing viewport.py.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class RendererInterface(ABC):
    """Abstract base class every future renderer backend must implement.

    Phase 1 ships no concrete subclass -- ``ViewportWidget`` simply
    holds an ``Optional[RendererInterface]`` that is ``None`` for now
    and draws its own placeholder content instead.
    """

    @abstractmethod
    def initialize(self, surface: Any) -> None:
        """Set up GPU resources against the given native surface/widget."""

    @abstractmethod
    def resize(self, width: int, height: int) -> None:
        """Handle a viewport resize."""

    @abstractmethod
    def render(self) -> None:
        """Render a single frame."""

    @abstractmethod
    def shutdown(self) -> None:
        """Release all GPU resources."""


class NullRenderer(RendererInterface):
    """A no-op renderer.

    Not used by the Phase 1 UI (the viewport currently draws its own
    placeholder rather than instantiating a renderer at all), but
    provided as a trivial, safe reference implementation of the
    interface and a convenient default for tests that need *some*
    RendererInterface instance.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._size: Optional[tuple] = None

    def initialize(self, surface: Any) -> None:
        self._initialized = True

    def resize(self, width: int, height: int) -> None:
        self._size = (width, height)

    def render(self) -> None:
        return None

    def shutdown(self) -> None:
        self._initialized = False
