# MYA 3D Editor

An original, Maya-inspired 3D content creation application shell, built in Python with PySide6/Qt6.

MYA 3D Editor is **not** affiliated with or endorsed by Autodesk. It is an independent application that follows the general *workflow* conventions of professional 3D DCC (Digital Content Creation) tools (outliner / viewport / properties / timeline layout) without copying any copyrighted visual assets, branding, or code.

## Current Phase: Phase 1 — Editor Foundation

Phase 1 delivers the **professional desktop editor shell**: window, menus, toolbar, docks, scene data model, selection system, undo/redo command system, and scene file I/O. It does **not** yet include real 3D rendering, mesh geometry, or animation playback — see [Features Intentionally NOT Implemented](#features-intentionally-not-implemented) and the [Roadmap](#roadmap--phase-2) below.

## Features Implemented

- **Main window** — dark, professional theme; resizable; saves/restores window geometry and dock layout between sessions (`QSettings`).
- **Menu bar** — File, Edit, Create, Select, Modify, Display, Windows, Help, matching the spec exactly. Actions that need future systems (Import/Export, Cut/Copy/Paste, Wireframe/Shaded display modes) show a clear "Coming in a future phase" status message instead of pretending to work.
- **Main toolbar** — New / Open / Save / Undo / Redo / Select / Move / Rotate / Scale, built from shared `QAction`s (the same actions used in the menu bar), with tooltips.
- **Outliner** (left dock) — live tree view of the scene hierarchy, backed by the core `Scene` model. Supports selection (single + multi), expand/collapse, inline rename, right-click context menu (Rename/Delete), and stays in sync with the central `SelectionManager`.
- **Viewport** (center) — placeholder `ViewportWidget`/`ViewportSurface` with a dark background, border, centered label, working mouse/keyboard focus handling, and a small Perspective/Shading toolbar. Architected around a `RendererInterface` abstraction so Phase 2 can attach a real renderer without changing this widget's structure.
- **Properties / Inspector** (right dock) — shows Name, Type, and Position/Rotation/Scale for the selected object, sourced from real `Transform` data. Edits are routed through `TransformObjectCommand` / `RenameObjectCommand` so they already participate in undo/redo.
- **Timeline** (bottom dock) — start/end frame fields, a frame scrubber slider, current-frame spinbox, and transport buttons (go to start/end, previous/next frame, play, stop). Backed by a plain `TimelineState` data object.
- **Status bar** — shows "Ready" on launch, then live selection summary, active tool, and current frame.
- **Scene data model** (`core/`) — `Scene`, `SceneObject`, `Transform`/`Vector3`, all framework-agnostic (no Qt imports), independently unit-testable.
- **Selection system** (`editor/selection.py`) — single `SelectionManager` that both the Outliner and Properties dock observe; they never talk to each other directly.
- **Undo/redo command system** (`editor/commands.py`) — `Command`/`CommandStack` foundation with working `CreateObjectCommand`, `DeleteObjectCommand`, `RenameObjectCommand`, `DuplicateObjectCommand`, and `TransformObjectCommand`.
- **Object creation** — Create menu (Group, Null, Camera, Light) and primitives (Cube, Sphere, Cylinder, Plane) all create real `SceneObject`s, add them to the `Scene`, show them in the Outliner, auto-select them, and populate the Properties panel.
- **Rename** — from the Outliner (inline edit) or the Properties panel Name field; updates `Scene`, Outliner, and Properties; object IDs never change.
- **Delete** — removes the selected object(s) (and descendants) from `Scene`; Outliner and Properties update; selection remains valid (cleared if it pointed at the deleted object).
- **Duplicate** — creates a new object with a new unique ID, a unique name (`Cube` → `Cube1` → `Cube2`, ...), and its own independent `Transform` (never shares a mutable object with the original).
- **Freeze Transform / Reset Transform** (Modify menu) — operate on the selected object's transform through `TransformObjectCommand`, so they're undoable.
- **Scene serialization** (`sceneio/scene_serializer.py`) — versioned JSON `.mya` files. `save_scene()` / `load_scene()` round-trip object IDs, names, types, parent/child hierarchy, and transforms. Handles missing files, invalid JSON, unknown/duplicate IDs, and unsupported format versions with clear errors instead of crashing.
- **Show/Hide docks + Reset Layout** — Display menu toggles for Outliner/Properties/Timeline actually show/hide the docks (and stay in sync if the user closes a dock directly); Windows > Reset Layout restores default dock positions and clears saved geometry.
- **About dialog** — Help > About MYA 3D Editor.
- **Error handling & logging** — invalid scene files, missing files, and bad JSON are caught and reported via `QMessageBox` rather than crashing; a rotating-free log file is written to `logs/mya3d.log` (falls back to console-only if the directory isn't writable) alongside console logging, covering startup/shutdown, scene create/save/load, object create/delete, and errors.

## Features Intentionally NOT Implemented (Phase 1)

By design, Phase 1 does **not** include:

- OpenGL / ModernGL / Vulkan / DirectX rendering, or any real-time 3D rendering
- Real mesh geometry, vertex/edge/face editing, extrude, bevel, UV editing, sculpting
- Rigging, skinning, or a working animation/keyframe system (the Timeline UI exists; frames don't yet drive anything)
- Physics, particles, PBR materials, real shaders, real lighting
- GPU object picking or transform gizmos (Move/Rotate/Scale tools exist as toolbar state only)
- A plugin system or Python scripting console
- Import/Export, and Cut/Copy/Paste (menu items exist and show a "coming soon" status message)

These are explicitly deferred to later phases so Phase 1 stays focused on a correct, professional editor foundation.

## Requirements

- Python 3.12+
- PySide6 (Qt6)
- pytest (for running tests)

See `requirements.txt`.

## Installation

```bash
# from the project root (the directory containing this README)
python3 -m venv .venv
source .venv/bin/activate        # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Running the Application

```bash
python main.py
```

On launch you should see the main window with menu bar, toolbar, Outliner (left), Viewport (center), Properties (right), Timeline (bottom), and status bar, with a default scene containing a Camera and a Light already in the Outliner.

## Running Tests

```bash
pytest
```

Tests live in `tests/` and cover the framework-agnostic `core`/`editor`/`sceneio` layers (no Qt event loop required): scene creation, object creation/deletion/duplication, unique IDs, transform behavior, selection, the undo/redo command stack, and scene file save/load. `tests/conftest.py` adds the project root to `sys.path` so tests run directly with `pytest` from the project root without an editable install.

## Project Architecture

```
mya3d/
├── main.py                   # Thin entry point: logging + QApplication + MainWindow
│
├── app/                       # Application bootstrap
│   ├── application.py         # Logging config, QApplication factory
│   └── settings.py            # QSettings wrapper (window geometry/state, theme)
│
├── core/                      # Framework-agnostic scene data model (no Qt imports)
│   ├── ids.py                 # Unique ID generation
│   ├── object_types.py        # SceneObjectType enum
│   ├── transform.py           # Vector3 / Transform
│   ├── scene_object.py        # SceneObject
│   ├── scene.py                # Scene (owns objects + hierarchy, emits Signals)
│   └── signal.py              # Minimal Qt-independent Signal/slot helper
│
├── editor/                    # Editor logic, still Qt-independent
│   ├── selection.py            # SelectionManager (single source of truth for selection)
│   ├── tools.py                # ToolManager / ToolType (Select/Move/Rotate/Scale state)
│   └── commands.py             # Command / CommandStack + concrete undoable commands
│
├── ui/                         # PySide6 widgets
│   ├── main_window.py          # Assembly/wiring only — no business logic
│   ├── viewport.py             # Placeholder viewport + RendererInterface hookup point
│   ├── outliner.py             # Outliner dock (Scene -> tree, tree -> SelectionManager)
│   ├── properties.py           # Properties dock (Selection + Scene -> form, form -> Commands)
│   ├── timeline.py             # Timeline dock + TimelineState
│   ├── toolbar.py              # Main toolbar (QActions)
│   └── styles.py               # Centralized dark theme stylesheet
│
├── sceneio/                    # File I/O
│   └── scene_serializer.py     # Versioned JSON .mya save/load
│
├── graphics/                   # Rendering abstraction (interface only in Phase 1)
│   └── renderer_interface.py   # RendererInterface ABC + NullRenderer reference impl
│
├── resources/icons/            # Icon assets (placeholder for now)
│
├── tests/                      # pytest test suite (core/editor/sceneio, Qt-free)
│   ├── conftest.py
│   ├── test_transform.py
│   ├── test_scene.py
│   ├── test_selection.py
│   ├── test_commands.py
│   └── test_serializer.py
│
├── requirements.txt
├── .gitignore
└── README.md
```

**Design principles followed throughout:**

- `core/` and `editor/` never import PySide6/Qt — they're plain Python and unit-testable headlessly.
- `ui/` widgets read from `Scene`/`SelectionManager` and write through `CommandStack`; widgets never call each other directly (e.g. the Outliner never touches the Properties panel — both observe the same `SelectionManager`).
- `MainWindow` only assembles and wires components; it does not contain scene/selection/command business logic itself.
- The viewport depends on `graphics.RendererInterface`, an abstraction, not a concrete renderer — Phase 2 can implement a real renderer without changing `ui/viewport.py`'s structure.
- The `.mya` scene format is versioned (`SCENE_FORMAT_VERSION` in `sceneio/scene_serializer.py`) so the format can evolve in later phases without breaking old files outright (unsupported versions fail with a clear error rather than corrupting data).

> **Note on the `sceneio` package name:** the file-I/O package is named `sceneio`, not `io`, specifically to avoid shadowing Python's built-in `io` module (naming a top-level package `io` breaks standard-library imports throughout the interpreter).

## Roadmap / Phase 2

Phase 1 is a complete, working editor **shell**. Phase 2 is expected to add:

- Real GPU rendering (ModernGL/OpenGL) behind the existing `RendererInterface`
- 3D math (vectors/matrices/quaternions) and a proper camera system
- Grid and real 3D primitive geometry for Cube/Sphere/Cylinder/Plane
- Viewport navigation (orbit/pan/zoom) and GPU-based object picking
- Move/Rotate/Scale transform gizmos wired to the existing `ToolManager` state
- A real animation/keyframe system layered on the existing `TimelineState`

Phase 2 has not been started; this repository currently contains Phase 1 only.
