"""Renderer abstraction.

Phase 1 shipped this module with NO real rendering code, so
``ViewportWidget`` could depend only on the interface and never a
concrete renderer. Phase 2 implements it for real in
``graphics/opengl_renderer.py`` (``OpenGLRenderer``), but the
abstraction is preserved so a future renderer backend could still be
swapped in without changing ``ui/viewport.py``'s structure.

Extension note (Phase 2): the ``render()`` method now takes ``scene``
and ``camera`` arguments, matching the spec's requested
``render(scene, camera)`` signature -- this is the one intentional
change to the Phase 1 interface, needed because a real renderer must
know *what* to draw and *from where*. Concrete renderers may also
expose additional, non-abstract attributes/methods (e.g.
``OpenGLRenderer.selected_ids`` / ``.grid_visible``) for
renderer-specific state that doesn't belong in the shared interface.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class RendererInterface(ABC):
    """Abstract base class every renderer backend must implement."""

    @abstractmethod
    def initialize(self, surface: Any) -> None:
        """Set up GPU resources against the given native surface/widget."""

    @abstractmethod
    def resize(self, width: int, height: int) -> None:
        """Handle a viewport resize."""

    @abstractmethod
    def render(self, scene: Any, camera: Any) -> None:
        """Render a single frame of ``scene`` as seen from ``camera``."""

    @abstractmethod
    def shutdown(self) -> None:
        """Release all GPU resources."""


class NullRenderer(RendererInterface):
    """A no-op renderer.

    Not used by the running application, but provided as a trivial,
    safe reference implementation of the interface and a convenient
    default for tests that need *some* RendererInterface instance
    without touching real GPU resources.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._size: Optional[tuple] = None

    def initialize(self, surface: Any) -> None:
        self._initialized = True

    def resize(self, width: int, height: int) -> None:
        self._size = (width, height)

    def render(self, scene: Any, camera: Any) -> None:
        return None

    def shutdown(self) -> None:
        self._initialized = False
