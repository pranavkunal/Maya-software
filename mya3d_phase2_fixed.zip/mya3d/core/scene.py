"""Scene data model.

The Scene owns every SceneObject and the hierarchy relationships
between them. It is framework-agnostic: no Qt imports. UI code
(Outliner, Properties, Viewport) observes it via the plain ``Signal``
objects exposed below rather than the Scene knowing anything about
Qt widgets.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

from core.object_types import SceneObjectType
from core.scene_object import SceneObject
from core.signal import Signal

logger = logging.getLogger(__name__)


class SceneError(Exception):
    """Raised for invalid scene operations (unknown IDs, bad parents, etc.)."""


class Scene:
    """Owns all SceneObjects for the currently open document.

    Signals (see core.signal.Signal):
        object_added(SceneObject): emitted after an object is added.
        object_removed(str): emitted with the removed object's id.
        object_renamed(str): emitted with the renamed object's id.
        object_changed(str): emitted with an id whose data changed
            (transform, visibility, etc.) -- coarse-grained on purpose
            for Phase 1.
        scene_reset(): emitted when the entire scene is replaced
            (New Scene, Load Scene).
    """

    def __init__(self, name: str = "Untitled") -> None:
        self.name = name
        self._objects: Dict[str, SceneObject] = {}
        self._root_ids: List[str] = []

        self.object_added: Signal = Signal()
        self.object_removed: Signal = Signal()
        self.object_renamed: Signal = Signal()
        self.object_changed: Signal = Signal()
        self.scene_reset: Signal = Signal()

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def get_object(self, object_id: str) -> Optional[SceneObject]:
        return self._objects.get(object_id)

    def require_object(self, object_id: str) -> SceneObject:
        obj = self.get_object(object_id)
        if obj is None:
            raise SceneError(f"No object with id '{object_id}' in scene")
        return obj

    def all_objects(self) -> List[SceneObject]:
        return list(self._objects.values())

    def root_ids(self) -> List[str]:
        return list(self._root_ids)

    def children_of(self, object_id: Optional[str]) -> List[SceneObject]:
        if object_id is None:
            return [self._objects[oid] for oid in self._root_ids if oid in self._objects]
        parent = self.require_object(object_id)
        return [self._objects[oid] for oid in parent.children_ids if oid in self._objects]

    def __len__(self) -> int:
        return len(self._objects)

    def __contains__(self, object_id: str) -> bool:
        return object_id in self._objects

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def add_object(self, obj: SceneObject, parent_id: Optional[str] = None) -> SceneObject:
        """Add ``obj`` to the scene under ``parent_id`` (or as a root)."""
        if obj.id in self._objects:
            raise SceneError(f"Object id '{obj.id}' already exists in scene")

        if parent_id is not None:
            parent = self.require_object(parent_id)
            obj.parent_id = parent_id
            parent.children_ids.append(obj.id)
        else:
            obj.parent_id = None
            self._root_ids.append(obj.id)

        self._objects[obj.id] = obj
        logger.info("Object added: %s (%s) id=%s", obj.name, obj.type, obj.id)
        self.object_added.emit(obj)
        return obj

    def remove_object(self, object_id: str, *, _is_recursive_call: bool = False) -> None:
        """Remove an object and all of its descendants from the scene."""
        obj = self.require_object(object_id)

        # Remove children first (depth-first) so we never leave dangling refs.
        for child_id in list(obj.children_ids):
            self.remove_object(child_id, _is_recursive_call=True)

        if obj.parent_id is not None:
            parent = self._objects.get(obj.parent_id)
            if parent is not None and object_id in parent.children_ids:
                parent.children_ids.remove(object_id)
        elif object_id in self._root_ids:
            self._root_ids.remove(object_id)

        del self._objects[object_id]
        logger.info("Object removed: %s id=%s", obj.name, object_id)
        self.object_removed.emit(object_id)

    def rename_object(self, object_id: str, new_name: str) -> None:
        obj = self.require_object(object_id)
        new_name = new_name.strip() or obj.name
        obj.name = new_name
        logger.info("Object renamed: id=%s -> '%s'", object_id, new_name)
        self.object_renamed.emit(object_id)

    def notify_changed(self, object_id: str) -> None:
        """Call after mutating an object's transform/visibility in place."""
        self.require_object(object_id)
        self.object_changed.emit(object_id)

    def duplicate_object(self, object_id: str) -> SceneObject:
        """Duplicate a single object (not its children) with a unique name.

        The duplicate gets a brand new id and its own independent
        Transform instance (never shared with the original).
        """
        original = self.require_object(object_id)
        new_name = self._generate_unique_duplicate_name(original.name)
        duplicate = SceneObject(
            name=new_name,
            type=original.type,
            transform=original.transform.copy(),
            metadata=dict(original.metadata),
            visible=original.visible,
        )
        return self.add_object(duplicate, parent_id=original.parent_id)

    def _generate_unique_duplicate_name(self, base_name: str) -> str:
        existing_names = {o.name for o in self._objects.values()}
        # Strip a trailing numeric suffix from the base so "Cube1" -> "Cube"
        # then re-number, matching common DCC-app duplicate naming.
        stripped = base_name.rstrip("0123456789")
        stem = stripped if stripped else base_name
        index = 1
        candidate = f"{stem}{index}"
        while candidate in existing_names:
            index += 1
            candidate = f"{stem}{index}"
        return candidate

    def clear(self) -> None:
        self._objects.clear()
        self._root_ids.clear()
        logger.info("Scene cleared: %s", self.name)
        self.scene_reset.emit()

    # ------------------------------------------------------------------
    # Convenience factory for a default Phase-1 scene
    # ------------------------------------------------------------------
    @classmethod
    def create_default(cls, name: str = "Untitled") -> "Scene":
        """Create a new scene pre-populated with a Camera and a Light.

        We intentionally do NOT add a default Cube: an empty-but-for-
        camera-and-light scene most closely matches what professional
        DCC applications present on "New Scene", and keeps Phase 1's
        acceptance test (create Cube explicitly) meaningful.
        """
        scene = cls(name=name)
        camera = SceneObject(name="Camera", type=SceneObjectType.CAMERA)
        light = SceneObject(name="Light", type=SceneObjectType.LIGHT)
        light.transform.position.y = 2.0
        scene.add_object(camera)
        scene.add_object(light)
        return scene
