"""Procedural generation of primitive ``MeshData`` (cube, plane, sphere,
cylinder).

Pure NumPy -- no OpenGL dependency -- so every function here is fully
unit-testable without a GPU. See ``tests/test_primitives.py``.

All primitives are centered on the local origin (except the plane,
which sits *on* the local Y=0 plane, matching a ground/floor plane
convention) so that placing one via a SceneObject's Transform behaves
predictably.
"""
from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np

from graphics.mesh import MeshData


def generate_cube(size: float = 2.0) -> MeshData:
    """A cube centered on the origin, edge length ``size``.

    24 vertices (4 per face, not shared) so each face gets a correct
    flat-shaded normal rather than an averaged vertex normal.
    """
    h = size / 2.0

    # Each face: 4 corner positions (CCW when viewed from outside) + its normal.
    faces = [
        # +X
        ([(h, -h, -h), (h, h, -h), (h, h, h), (h, -h, h)], (1, 0, 0)),
        # -X
        ([(-h, -h, h), (-h, h, h), (-h, h, -h), (-h, -h, -h)], (-1, 0, 0)),
        # +Y
        ([(-h, h, -h), (-h, h, h), (h, h, h), (h, h, -h)], (0, 1, 0)),
        # -Y
        ([(-h, -h, h), (-h, -h, -h), (h, -h, -h), (h, -h, h)], (0, -1, 0)),
        # +Z
        ([(-h, -h, h), (h, -h, h), (h, h, h), (-h, h, h)], (0, 0, 1)),
        # -Z
        ([(h, -h, -h), (-h, -h, -h), (-h, h, -h), (h, h, -h)], (0, 0, -1)),
    ]

    positions: List[Tuple[float, float, float]] = []
    normals: List[Tuple[float, float, float]] = []
    indices: List[int] = []

    for corners, normal in faces:
        base = len(positions)
        positions.extend(corners)
        normals.extend([normal] * 4)
        indices.extend([base, base + 1, base + 2, base, base + 2, base + 3])

    return MeshData(
        positions=np.array(positions, dtype=np.float32),
        normals=np.array(normals, dtype=np.float32),
        indices=np.array(indices, dtype=np.uint32),
    )


def generate_plane(width: float = 4.0, depth: float = 4.0, segments: int = 1) -> MeshData:
    """A flat plane on the local Y=0 (X/Z) plane, centered on the origin.

    ``segments`` subdivides each axis (>=1); the surface normal is
    +Y (up) everywhere, matching the "Y is up" convention.
    """
    segments = max(1, int(segments))
    half_w = width / 2.0
    half_d = depth / 2.0

    positions: List[Tuple[float, float, float]] = []
    normals: List[Tuple[float, float, float]] = []
    indices: List[int] = []

    for row in range(segments + 1):
        v = row / segments
        z = -half_d + v * depth
        for col in range(segments + 1):
            u = col / segments
            x = -half_w + u * width
            positions.append((x, 0.0, z))
            normals.append((0.0, 1.0, 0.0))

    cols = segments + 1
    for row in range(segments):
        for col in range(segments):
            i0 = row * cols + col
            i1 = i0 + 1
            i2 = i0 + cols
            i3 = i2 + 1
            # Two CCW triangles (viewed from +Y, looking down -Y).
            indices.extend([i0, i2, i1, i1, i2, i3])

    return MeshData(
        positions=np.array(positions, dtype=np.float32),
        normals=np.array(normals, dtype=np.float32),
        indices=np.array(indices, dtype=np.uint32),
    )


def generate_sphere(radius: float = 1.0, rings: int = 16, segments: int = 24) -> MeshData:
    """A UV sphere centered on the origin.

    ``rings`` is the number of latitude subdivisions (>=2), ``segments``
    the number of longitude subdivisions (>=3). Vertex normals equal
    the normalized position (a sphere centered at the origin), so
    shading is smooth.
    """
    rings = max(2, int(rings))
    segments = max(3, int(segments))

    positions: List[Tuple[float, float, float]] = []
    normals: List[Tuple[float, float, float]] = []
    indices: List[int] = []

    for ring in range(rings + 1):
        theta = ring * math.pi / rings  # 0 (north pole) .. pi (south pole)
        sin_theta = math.sin(theta)
        cos_theta = math.cos(theta)
        for seg in range(segments + 1):
            phi = seg * 2.0 * math.pi / segments
            sin_phi = math.sin(phi)
            cos_phi = math.cos(phi)

            x = sin_theta * cos_phi
            y = cos_theta
            z = sin_theta * sin_phi

            positions.append((x * radius, y * radius, z * radius))
            normals.append((x, y, z))

    verts_per_ring = segments + 1
    for ring in range(rings):
        for seg in range(segments):
            i0 = ring * verts_per_ring + seg
            i1 = i0 + verts_per_ring
            i2 = i0 + 1
            i3 = i1 + 1
            indices.extend([i0, i1, i2, i2, i1, i3])

    return MeshData(
        positions=np.array(positions, dtype=np.float32),
        normals=np.array(normals, dtype=np.float32),
        indices=np.array(indices, dtype=np.uint32),
    )


def generate_cylinder(
    radius: float = 1.0, height: float = 2.0, segments: int = 24
) -> MeshData:
    """A cylinder centered on the origin, axis along local Y, with
    separate side, top-cap, and bottom-cap geometry (each with correct
    per-face-group normals -- side normals point radially outward, cap
    normals point straight up/down).
    """
    segments = max(3, int(segments))
    half_h = height / 2.0

    positions: List[Tuple[float, float, float]] = []
    normals: List[Tuple[float, float, float]] = []
    indices: List[int] = []

    # --- Side wall -----------------------------------------------------
    for seg in range(segments + 1):
        angle = seg * 2.0 * math.pi / segments
        x = math.cos(angle)
        z = math.sin(angle)
        # bottom ring vertex, then top ring vertex, sharing the radial normal
        positions.append((x * radius, -half_h, z * radius))
        normals.append((x, 0.0, z))
        positions.append((x * radius, half_h, z * radius))
        normals.append((x, 0.0, z))

    for seg in range(segments):
        i0 = seg * 2
        i1 = i0 + 1
        i2 = i0 + 2
        i3 = i0 + 3
        indices.extend([i0, i2, i1, i1, i2, i3])

    # --- Top cap ---------------------------------------------------------
    top_center_index = len(positions)
    positions.append((0.0, half_h, 0.0))
    normals.append((0.0, 1.0, 0.0))
    top_ring_start = len(positions)
    for seg in range(segments + 1):
        angle = seg * 2.0 * math.pi / segments
        x = math.cos(angle)
        z = math.sin(angle)
        positions.append((x * radius, half_h, z * radius))
        normals.append((0.0, 1.0, 0.0))
    for seg in range(segments):
        indices.extend([top_center_index, top_ring_start + seg, top_ring_start + seg + 1])

    # --- Bottom cap --------------------------------------------------------
    bottom_center_index = len(positions)
    positions.append((0.0, -half_h, 0.0))
    normals.append((0.0, -1.0, 0.0))
    bottom_ring_start = len(positions)
    for seg in range(segments + 1):
        angle = seg * 2.0 * math.pi / segments
        x = math.cos(angle)
        z = math.sin(angle)
        positions.append((x * radius, -half_h, z * radius))
        normals.append((0.0, -1.0, 0.0))
    for seg in range(segments):
        indices.extend(
            [bottom_center_index, bottom_ring_start + seg + 1, bottom_ring_start + seg]
        )

    return MeshData(
        positions=np.array(positions, dtype=np.float32),
        normals=np.array(normals, dtype=np.float32),
        indices=np.array(indices, dtype=np.uint32),
    )


#: Maps the ``metadata["primitive"]`` string stored on a mesh
#: SceneObject to the generator function that builds its MeshData.
PRIMITIVE_GENERATORS = {
    "cube": generate_cube,
    "plane": generate_plane,
    "sphere": generate_sphere,
    "cylinder": generate_cylinder,
}


def generate_primitive(name: str) -> MeshData:
    """Generate a ``MeshData`` for a primitive name using default parameters.

    Raises:
        ValueError: if ``name`` is not a known primitive type.
    """
    generator = PRIMITIVE_GENERATORS.get(name)
    if generator is None:
        raise ValueError(f"Unknown primitive type: {name!r}")
    return generator()
