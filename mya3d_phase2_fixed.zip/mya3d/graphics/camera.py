"""A 3D editor ("orbit") camera.

This is the **editor camera** used to navigate the viewport -- it is
entirely separate from any ``Camera``-type ``SceneObject`` in the
scene graph (see ``core/object_types.py``). A scene Camera object
represents an in-scene, renderable/animatable camera a future phase
may render *through*; this class is purely a UI navigation aid, like
the viewport camera in any DCC application, and is never serialized
into the ``.mya`` scene file.

Implemented as an orbit camera: position is derived from a target
point, a distance, and yaw/pitch angles, which makes orbit/pan/zoom
navigation simple and keeps the camera from ever flipping upside down
(pitch is clamped).
"""
from __future__ import annotations

import math
from typing import Tuple

import numpy as np

from graphics import math3d

Vec3 = Tuple[float, float, float]

_MIN_PITCH_DEG = -89.0
_MAX_PITCH_DEG = 89.0
_MIN_DISTANCE = 0.05
_MAX_DISTANCE = 10_000.0


class EditorCamera:
    """Orbit-style editor/viewport camera.

    Coordinate convention: right-handed, Y-up (see graphics/math3d.py
    module docstring). Yaw rotates around world +Y; pitch tilts up/down
    and is clamped to avoid the camera flipping through the poles.
    """

    def __init__(
        self,
        target: Vec3 = (0.0, 0.0, 0.0),
        distance: float = 8.0,
        yaw_degrees: float = -40.0,
        pitch_degrees: float = 25.0,
        fov_y_degrees: float = 45.0,
        near: float = 0.01,
        far: float = 5000.0,
        aspect_ratio: float = 1.0,
    ) -> None:
        self.target = np.array(target, dtype=np.float32)
        self.distance = float(distance)
        self.yaw_degrees = float(yaw_degrees)
        self.pitch_degrees = float(pitch_degrees)
        self.fov_y_degrees = float(fov_y_degrees)
        self.near = float(near)
        self.far = float(far)
        self.aspect_ratio = float(aspect_ratio) if aspect_ratio > 0 else 1.0

    # ------------------------------------------------------------------
    def position(self) -> np.ndarray:
        """World-space camera eye position, derived from target/distance/angles."""
        yaw = math.radians(self.yaw_degrees)
        pitch = math.radians(self.pitch_degrees)
        x = self.distance * math.cos(pitch) * math.sin(yaw)
        y = self.distance * math.sin(pitch)
        z = self.distance * math.cos(pitch) * math.cos(yaw)
        return self.target + np.array([x, y, z], dtype=np.float32)

    def forward(self) -> np.ndarray:
        """Unit vector from the camera towards its target."""
        return math3d.normalize(self.target - self.position())

    def right(self) -> np.ndarray:
        world_up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        return math3d.normalize(np.cross(self.forward(), world_up))

    def up(self) -> np.ndarray:
        return math3d.normalize(np.cross(self.right(), self.forward()))

    # ------------------------------------------------------------------
    def get_view_matrix(self) -> np.ndarray:
        eye = self.position()
        return math3d.look_at_matrix(
            tuple(eye), tuple(self.target), (0.0, 1.0, 0.0)
        )

    def get_projection_matrix(self) -> np.ndarray:
        return math3d.perspective_matrix(
            self.fov_y_degrees, self.aspect_ratio, self.near, self.far
        )

    def set_aspect_ratio(self, width: int, height: int) -> None:
        if height <= 0:
            height = 1
        self.aspect_ratio = width / height

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def orbit(self, delta_yaw_degrees: float, delta_pitch_degrees: float) -> None:
        """Rotate the camera around ``self.target``."""
        self.yaw_degrees = (self.yaw_degrees + delta_yaw_degrees) % 360.0
        self.pitch_degrees = max(
            _MIN_PITCH_DEG, min(_MAX_PITCH_DEG, self.pitch_degrees + delta_pitch_degrees)
        )

    def pan(self, delta_x: float, delta_y: float) -> None:
        """Move the camera (and its target) parallel to the view plane.

        ``delta_x``/``delta_y`` are in the same "world units per pixel"
        scale the caller chooses (the viewport scales these by distance
        so panning feels consistent whether zoomed in or out).
        """
        offset = self.right() * (-delta_x) + self.up() * delta_y
        self.target = self.target + offset

    def zoom(self, delta: float) -> None:
        """Move the camera towards (`delta` > 0) or away from (`delta` < 0) the target."""
        self.distance = max(_MIN_DISTANCE, min(_MAX_DISTANCE, self.distance - delta))

    def frame_target(self, center: Vec3, radius: float) -> None:
        """Point the camera at ``center`` with a distance that fits ``radius``."""
        self.target = np.array(center, dtype=np.float32)
        fov_rad = math.radians(max(1.0, self.fov_y_degrees))
        fit_distance = max(radius, 0.01) / math.sin(fov_rad / 2.0)
        self.distance = max(_MIN_DISTANCE, min(_MAX_DISTANCE, fit_distance * 1.5))

    def reset(self) -> None:
        """Restore a sensible default editor view."""
        self.target = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        self.distance = 8.0
        self.yaw_degrees = -40.0
        self.pitch_degrees = 25.0
