#version 330 core

// Interleaved vertex attributes: position (3 floats) + normal (3 floats).
// Layout locations match graphics/mesh.py MeshGPU attribute bindings.
layout(location = 0) in vec3 in_position;
layout(location = 1) in vec3 in_normal;

uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_projection;
// Inverse-transpose of the model matrix, for correct normal transformation
// under non-uniform scale. Computed on the CPU (NumPy) per draw call.
uniform mat3 u_normal_matrix;

out vec3 v_world_normal;
out vec3 v_world_position;

void main() {
    vec4 world_position = u_model * vec4(in_position, 1.0);
    v_world_position = world_position.xyz;
    v_world_normal = normalize(u_normal_matrix * in_normal);

    gl_Position = u_projection * u_view * world_position;
}
