#version 330 core

in vec3 v_world_normal;
in vec3 v_world_position;

// Base (display) color of the object -- logical scene data, set per
// draw call from SceneObject.metadata["color"], not baked into the mesh.
uniform vec3 u_base_color;

// Simple directional light (Phase 2: one light is enough to make
// geometry visually understandable; see graphics/opengl_renderer.py).
uniform vec3 u_light_direction;   // points FROM the light TOWARDS the surface
uniform vec3 u_light_color;
uniform vec3 u_camera_position;

// Selection highlight: additively tinted when > 0.
uniform float u_selected;

out vec4 out_color;

void main() {
    vec3 normal = normalize(v_world_normal);
    vec3 to_light = normalize(-u_light_direction);

    float ambient_strength = 0.25;
    vec3 ambient = ambient_strength * u_light_color;

    float diffuse_strength = max(dot(normal, to_light), 0.0);
    vec3 diffuse = diffuse_strength * u_light_color;

    // A small rim/specular-ish term to help read curved surfaces (cheap,
    // not physically based -- Phase 2 explicitly avoids full PBR).
    vec3 view_dir = normalize(u_camera_position - v_world_position);
    vec3 half_vec = normalize(to_light + view_dir);
    float spec_strength = pow(max(dot(normal, half_vec), 0.0), 16.0) * 0.15;

    vec3 lit_color = (ambient + diffuse) * u_base_color + spec_strength * u_light_color;

    // Selection tint: blend towards a bright highlight color without
    // permanently altering the object's actual base color.
    vec3 selection_color = vec3(1.0, 0.65, 0.15);
    lit_color = mix(lit_color, selection_color, u_selected * 0.45);

    out_color = vec4(lit_color, 1.0);
}
