"""Shader compilation/linking with useful diagnostics.

Shader compilation/link failures raise ``ShaderCompilationError`` with
the shader name, GLSL source stage, and the driver's own error log --
callers (the renderer) are expected to catch this, log it, and show it
to the user rather than crash with a bare traceback (see spec section
on shader error handling).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

try:
    from OpenGL import GL as gl  # type: ignore
    _HAS_OPENGL = True
except ImportError:  # pragma: no cover
    gl = None  # type: ignore
    _HAS_OPENGL = False


class ShaderCompilationError(Exception):
    """Raised when a shader fails to compile or a program fails to link."""


class ShaderProgram:
    """A linked GLSL program built from a vertex + fragment shader pair."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._program_id: Optional[int] = None
        self._uniform_locations: Dict[str, int] = {}

    @property
    def program_id(self) -> Optional[int]:
        return self._program_id

    @classmethod
    def from_files(cls, name: str, vertex_path: Path, fragment_path: Path) -> "ShaderProgram":
        vertex_src = Path(vertex_path).read_text(encoding="utf-8")
        fragment_src = Path(fragment_path).read_text(encoding="utf-8")
        program = cls(name)
        program.compile_and_link(vertex_src, fragment_src)
        return program

    def compile_and_link(self, vertex_src: str, fragment_src: str) -> None:
        if not _HAS_OPENGL:
            raise ShaderCompilationError(
                f"[{self.name}] PyOpenGL is not installed; cannot compile shaders. "
                "Install it with `pip install PyOpenGL`."
            )

        vertex_shader = self._compile_stage(gl.GL_VERTEX_SHADER, vertex_src, "vertex")
        fragment_shader = self._compile_stage(gl.GL_FRAGMENT_SHADER, fragment_src, "fragment")

        program_id = gl.glCreateProgram()
        gl.glAttachShader(program_id, vertex_shader)
        gl.glAttachShader(program_id, fragment_shader)
        gl.glLinkProgram(program_id)

        link_status = gl.glGetProgramiv(program_id, gl.GL_LINK_STATUS)
        if not link_status:
            log = gl.glGetProgramInfoLog(program_id)
            log_text = log.decode("utf-8", errors="replace") if isinstance(log, bytes) else str(log)
            gl.glDeleteProgram(program_id)
            gl.glDeleteShader(vertex_shader)
            gl.glDeleteShader(fragment_shader)
            raise ShaderCompilationError(
                f"[{self.name}] Shader program link failed:\n{log_text}"
            )

        # Shaders are linked into the program now; the individual shader
        # objects are no longer needed.
        gl.glDeleteShader(vertex_shader)
        gl.glDeleteShader(fragment_shader)

        self._program_id = program_id
        logger.info("Shader program '%s' compiled and linked successfully", self.name)

    def _compile_stage(self, stage: int, source: str, stage_name: str) -> int:
        shader_id = gl.glCreateShader(stage)
        gl.glShaderSource(shader_id, source)
        gl.glCompileShader(shader_id)

        compile_status = gl.glGetShaderiv(shader_id, gl.GL_COMPILE_STATUS)
        if not compile_status:
            log = gl.glGetShaderInfoLog(shader_id)
            log_text = log.decode("utf-8", errors="replace") if isinstance(log, bytes) else str(log)
            gl.glDeleteShader(shader_id)
            raise ShaderCompilationError(
                f"[{self.name}] {stage_name} shader compilation failed:\n{log_text}"
            )
        return shader_id

    # ------------------------------------------------------------------
    def use(self) -> None:
        if self._program_id is None:
            raise RuntimeError(f"Shader program '{self.name}' used before compile_and_link()")
        gl.glUseProgram(self._program_id)

    @staticmethod
    def unuse() -> None:
        if _HAS_OPENGL:
            gl.glUseProgram(0)

    def uniform_location(self, name: str) -> int:
        if name in self._uniform_locations:
            return self._uniform_locations[name]
        if self._program_id is None:
            raise RuntimeError(f"Shader program '{self.name}' has no linked program")
        location = gl.glGetUniformLocation(self._program_id, name)
        self._uniform_locations[name] = location
        return location

    def set_mat4(self, name: str, matrix) -> None:
        location = self.uniform_location(name)
        if location < 0:
            return
        gl.glUniformMatrix4fv(location, 1, gl.GL_TRUE, matrix)

    def set_mat3(self, name: str, matrix) -> None:
        location = self.uniform_location(name)
        if location < 0:
            return
        gl.glUniformMatrix3fv(location, 1, gl.GL_TRUE, matrix)

    def set_vec3(self, name: str, x: float, y: float, z: float) -> None:
        location = self.uniform_location(name)
        if location < 0:
            return
        gl.glUniform3f(location, x, y, z)

    def set_float(self, name: str, value: float) -> None:
        location = self.uniform_location(name)
        if location < 0:
            return
        gl.glUniform1f(location, value)

    def release(self) -> None:
        if _HAS_OPENGL and self._program_id is not None:
            try:
                gl.glDeleteProgram(self._program_id)
            except Exception:  # pragma: no cover - defensive
                logger.exception("Failed to delete shader program '%s'", self.name)
        self._program_id = None
        self._uniform_locations.clear()
