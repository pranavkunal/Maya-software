"""Timeline dock: frame range, current-frame scrubber, transport controls.

Phase 1 has no keyframe/animation system. ``TimelineState`` still models
current/start/end frame as real data (not just UI widget state) so
Phase 2's keyframe editor can be layered on top of the same state
object instead of a rewrite.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

logger = logging.getLogger(__name__)


class TimelineState:
    """Plain data holder for the current animation range/frame.

    Deliberately Qt-independent (mirrors the core/editor pattern) even
    though it currently lives in the ui package, since it's purely a
    UI-driven concept in Phase 1 with no scene-level keyframe data yet.
    """

    def __init__(self, start_frame: int = 1, end_frame: int = 240, current_frame: int = 1) -> None:
        self.start_frame = start_frame
        self.end_frame = end_frame
        self.current_frame = current_frame

    def clamp_current(self) -> None:
        self.current_frame = max(self.start_frame, min(self.end_frame, self.current_frame))


class TimelineWidget(QWidget):
    """Frame scrubber + transport controls."""

    frame_changed = Signal(int)
    play_requested = Signal()
    stop_requested = Signal()

    def __init__(self, state: Optional[TimelineState] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.state = state or TimelineState()
        self._is_playing = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 6, 8, 6)
        outer.setSpacing(4)

        outer.addWidget(self._build_transport_row())
        outer.addWidget(self._build_scrub_row())

    # ------------------------------------------------------------------
    def _build_transport_row(self) -> QWidget:
        row = QWidget(self)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.start_frame_spin = QSpinBox()
        self.start_frame_spin.setRange(-100000, 100000)
        self.start_frame_spin.setValue(self.state.start_frame)
        self.start_frame_spin.setToolTip("Start Frame")
        self.start_frame_spin.valueChanged.connect(self._on_start_frame_changed)

        self.end_frame_spin = QSpinBox()
        self.end_frame_spin.setRange(-100000, 100000)
        self.end_frame_spin.setValue(self.state.end_frame)
        self.end_frame_spin.setToolTip("End Frame")
        self.end_frame_spin.valueChanged.connect(self._on_end_frame_changed)

        self.btn_go_start = QPushButton("|\u25c0")
        self.btn_go_start.setToolTip("Go to Start Frame")
        self.btn_go_start.setFixedWidth(32)
        self.btn_go_start.clicked.connect(self._go_to_start)

        self.btn_prev_frame = QPushButton("\u25c0")
        self.btn_prev_frame.setToolTip("Previous Frame")
        self.btn_prev_frame.setFixedWidth(32)
        self.btn_prev_frame.clicked.connect(self._go_to_previous_frame)

        self.btn_play = QPushButton("\u25b6")
        self.btn_play.setToolTip("Play")
        self.btn_play.setFixedWidth(32)
        self.btn_play.setCheckable(True)
        self.btn_play.clicked.connect(self._on_play_clicked)

        self.btn_stop = QPushButton("\u25a0")
        self.btn_stop.setToolTip("Stop")
        self.btn_stop.setFixedWidth(32)
        self.btn_stop.clicked.connect(self._on_stop_clicked)

        self.btn_next_frame = QPushButton("\u25b6")
        self.btn_next_frame.setToolTip("Next Frame")
        self.btn_next_frame.setFixedWidth(32)
        self.btn_next_frame.clicked.connect(self._go_to_next_frame)

        self.btn_go_end = QPushButton("\u25b6|")
        self.btn_go_end.setToolTip("Go to End Frame")
        self.btn_go_end.setFixedWidth(32)
        self.btn_go_end.clicked.connect(self._go_to_end)

        self.current_frame_spin = QSpinBox()
        self.current_frame_spin.setRange(-100000, 100000)
        self.current_frame_spin.setValue(self.state.current_frame)
        self.current_frame_spin.setToolTip("Current Frame")
        self.current_frame_spin.valueChanged.connect(self._on_current_frame_spin_changed)

        layout.addWidget(QLabel("Start:"))
        layout.addWidget(self.start_frame_spin)
        layout.addWidget(self.btn_go_start)
        layout.addWidget(self.btn_prev_frame)
        layout.addWidget(self.btn_play)
        layout.addWidget(self.btn_stop)
        layout.addWidget(self.btn_next_frame)
        layout.addWidget(self.btn_go_end)
        layout.addWidget(QLabel("End:"))
        layout.addWidget(self.end_frame_spin)
        layout.addStretch(1)
        layout.addWidget(QLabel("Frame:"))
        layout.addWidget(self.current_frame_spin)
        return row

    def _build_scrub_row(self) -> QWidget:
        row = QWidget(self)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.scrub_slider = QSlider(Qt.Orientation.Horizontal)
        self.scrub_slider.setMinimum(self.state.start_frame)
        self.scrub_slider.setMaximum(max(self.state.start_frame, self.state.end_frame))
        self.scrub_slider.setValue(self.state.current_frame)
        self.scrub_slider.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.scrub_slider.valueChanged.connect(self._on_slider_changed)
        self.scrub_slider.setToolTip("Timeline")

        layout.addWidget(self.scrub_slider)
        return row

    # ------------------------------------------------------------------
    def _set_current_frame(self, frame: int, *, from_widget: Optional[QWidget] = None) -> None:
        frame = max(self.state.start_frame, min(self.state.end_frame, frame))
        if frame == self.state.current_frame:
            return
        self.state.current_frame = frame

        if from_widget is not self.current_frame_spin:
            self.current_frame_spin.blockSignals(True)
            self.current_frame_spin.setValue(frame)
            self.current_frame_spin.blockSignals(False)
        if from_widget is not self.scrub_slider:
            self.scrub_slider.blockSignals(True)
            self.scrub_slider.setValue(frame)
            self.scrub_slider.blockSignals(False)

        self.frame_changed.emit(frame)

    def _on_current_frame_spin_changed(self, value: int) -> None:
        self._set_current_frame(value, from_widget=self.current_frame_spin)

    def _on_slider_changed(self, value: int) -> None:
        self._set_current_frame(value, from_widget=self.scrub_slider)

    def _on_start_frame_changed(self, value: int) -> None:
        self.state.start_frame = value
        self.scrub_slider.setMinimum(value)
        self.state.clamp_current()

    def _on_end_frame_changed(self, value: int) -> None:
        self.state.end_frame = value
        self.scrub_slider.setMaximum(max(self.state.start_frame, value))
        self.state.clamp_current()

    def _go_to_start(self) -> None:
        self._set_current_frame(self.state.start_frame)

    def _go_to_end(self) -> None:
        self._set_current_frame(self.state.end_frame)

    def _go_to_previous_frame(self) -> None:
        self._set_current_frame(self.state.current_frame - 1)

    def _go_to_next_frame(self) -> None:
        self._set_current_frame(self.state.current_frame + 1)

    def _on_play_clicked(self, checked: bool) -> None:
        self._is_playing = checked
        self.btn_play.setText("\u23f8" if checked else "\u25b6")
        if checked:
            logger.info("Play requested (playback engine arrives in a future phase)")
            self.play_requested.emit()

    def _on_stop_clicked(self) -> None:
        if self._is_playing:
            self._is_playing = False
            self.btn_play.setChecked(False)
            self.btn_play.setText("\u25b6")
        self.stop_requested.emit()


class TimelineDock(QDockWidget):
    """Dock wrapper hosting the TimelineWidget."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__("Timeline", parent)
        self.setObjectName("TimelineDock")
        self.timeline = TimelineWidget(parent=self)
        self.setWidget(self.timeline)
        self.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
            | QDockWidget.DockWidgetFeature.DockWidgetClosable
        )
