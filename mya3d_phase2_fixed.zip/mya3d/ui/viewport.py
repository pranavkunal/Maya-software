"""Central viewport widget -- Phase 2: a real OpenGL 3D viewport.

Architecture:

    ViewportWidget (this module, outer container: small toolbar + GL surface)
        -> ViewportGLWidget (QOpenGLWidget subclass, owns the GL context)
            -> EditorCamera        (graphics/camera.py)
            -> OpenGLRenderer      (graphics/opengl_renderer.py, implements RendererInterface)

``ViewportGLWidget`` reads ``Scene``/``SelectionManager`` (read-only,
for rendering + highlighting) and writes to ``SelectionManager`` (on
click) and to the scene via ``editor.commands`` (on move-drag release),
mirroring the rest of the app: it never talks to the Outliner or
Properties dock directly -- see ``core.signal.Signal`` wiring below and
in ``ui/main_window.py``.

Mouse/keyboard controls (documented in full in README.md):
    * Left click (no drag)         -> select object under cursor
    * Left drag + Alt              -> orbit
    * Left drag (Move tool active, object selected) -> move selected
      object across the camera-facing plane through it; hold X/Y/Z
      while dragging to constrain to that world axis
    * Middle drag / Right drag     -> pan / orbit (see README)
    * Mouse wheel                  -> zoom
"""
from __future__ import annotations

import logging
from typing import List, Optional, Tuple

import numpy as np
from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QSurfaceFormat
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.object_types import SceneObjectType
from core.scene import Scene
from editor.commands import CommandStack, DeleteObjectCommand, TransformObjectCommand
from editor.selection import SelectionManager
from editor.tools import ToolManager, ToolType
from graphics import math3d
from graphics.camera import EditorCamera
from graphics.opengl_renderer import OpenGLRenderer, RendererInitError
from ui.styles import COLOR_TEXT_SECONDARY

logger = logging.getLogger(__name__)

_CLICK_MOVE_THRESHOLD_PX = 4
_ORBIT_SPEED = 0.4          # degrees per pixel
_PAN_SPEED = 0.0018         # world units per pixel, scaled by camera distance
_ZOOM_SPEED = 0.12          # fraction of current distance per wheel notch

# (yaw_degrees, pitch_degrees) presets for the "View" combo box. These
# are perspective-camera viewing-angle presets, NOT a true orthographic
# projection (that is future-phase work) -- see README "Limitations".
_VIEW_PRESETS = {
    "Perspective": (-40.0, 25.0),
    "Top": (0.0, 89.9),
    "Bottom": (0.0, -89.9),
    "Front": (0.0, 0.0),
    "Back": (180.0, 0.0),
    "Side": (90.0, 0.0),
    "Left": (-90.0, 0.0),
}


def _make_gl_surface_format() -> QSurfaceFormat:
    fmt = QSurfaceFormat()
    fmt.setRenderableType(QSurfaceFormat.RenderableType.OpenGL)
    fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
    fmt.setVersion(3, 3)
    fmt.setDepthBufferSize(24)
    fmt.setStencilBufferSize(8)
    fmt.setSamples(4)  # multisampling; harmless no-op if unsupported
    return fmt


class ViewportGLWidget(QOpenGLWidget):
    """Owns the OpenGL context, the editor camera, and the renderer."""

    render_error = Signal(str)

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        tool_manager: ToolManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setFormat(_make_gl_surface_format())
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setMinimumSize(200, 150)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self._scene = scene
        self._selection = selection
        self._tool_manager = tool_manager
        self._command_stack = command_stack

        self.camera = EditorCamera()
        self.renderer = OpenGLRenderer()
        self._init_error: Optional[str] = None

        self.grid_visible: bool = True
        self.wireframe: bool = False

        # -- drag/navigation state ---------------------------------------
        self._drag_mode: Optional[str] = None  # 'orbit' | 'pan' | 'move' | 'select_pending'
        self._last_pos: Optional[Tuple[int, int]] = None
        self._press_pos: Optional[Tuple[int, int]] = None

        self._move_object_id: Optional[str] = None
        self._move_start_transform = None
        self._move_plane_point: Optional[np.ndarray] = None
        self._move_plane_normal: Optional[np.ndarray] = None
        self._move_start_hit: Optional[np.ndarray] = None
        self._move_axis_lock: Optional[str] = None

        self._connect_scene_signals()
        self._selection.selection_changed.connect(self._on_external_change)

    # ------------------------------------------------------------------
    # Scene rewiring (mirrors ui/outliner.py and ui/properties.py so New
    # Scene / Open Scene keep the viewport in sync -- see
    # ui/main_window.py::_replace_scene).
    # ------------------------------------------------------------------
    def _connect_scene_signals(self) -> None:
        self._scene.object_added.connect(self._on_external_change)
        self._scene.object_removed.connect(self._on_external_change)
        self._scene.object_renamed.connect(self._on_external_change)
        self._scene.object_changed.connect(self._on_external_change)
        self._scene.scene_reset.connect(self._on_external_change)

    def _on_external_change(self, *_args) -> None:
        self.update()

    # ------------------------------------------------------------------
    # QOpenGLWidget lifecycle
    # ------------------------------------------------------------------
    def initializeGL(self) -> None:  # noqa: N802 (Qt override)
        try:
            self.renderer.initialize(self)
        except RendererInitError as exc:
            self._init_error = str(exc)
            logger.error("Viewport OpenGL initialization failed: %s", exc)
            self.render_error.emit(str(exc))
            return

        self.camera.set_aspect_ratio(max(1, self.width()), max(1, self.height()))

        context = self.context()
        if context is not None:
            context.aboutToBeDestroyed.connect(self._on_context_about_to_be_destroyed)

    def resizeGL(self, w: int, h: int) -> None:  # noqa: N802 (Qt override)
        if self._init_error:
            return
        # QOpenGLWidget renders into its own internally-managed FBO, not
        # system framebuffer 0 -- always query the real id (see the
        # OpenGLRenderer.render() docstring for why this matters).
        self.renderer.resize(w, h, self.defaultFramebufferObject())
        self.camera.set_aspect_ratio(w, h)

    def paintGL(self) -> None:  # noqa: N802 (Qt override)
        if self._init_error or not self.renderer.is_initialized:
            return
        self.renderer.selected_ids = set(self._selection.selected_ids())
        self.renderer.grid_visible = self.grid_visible
        self.renderer.wireframe = self.wireframe
        self.renderer.render(self._scene, self.camera, self.defaultFramebufferObject())

    def _on_context_about_to_be_destroyed(self) -> None:
        # The GL context is still current at this point (Qt guarantees
        # it for this signal), so it's safe to release GPU resources here.
        try:
            self.renderer.shutdown()
        except Exception:  # pragma: no cover - defensive, must not crash teardown
            logger.exception("Error releasing renderer resources on context teardown")

    def cleanup(self) -> None:
        """Explicit cleanup hook called by MainWindow before close, in
        case the context-destroyed signal doesn't fire in time.
        """
        if not self.renderer.is_initialized:
            return
        try:
            self.makeCurrent()
            self.renderer.shutdown()
        except Exception:  # pragma: no cover - defensive
            logger.exception("Error during explicit viewport cleanup")
        finally:
            try:
                self.doneCurrent()
            except Exception:  # pragma: no cover - defensive
                pass

    # ------------------------------------------------------------------
    # Public API used by ui/main_window.py
    # ------------------------------------------------------------------
    def rebind_scene(self, new_scene: Scene) -> None:
        """Point this widget at a different Scene instance (New/Open Scene)."""
        self._scene = new_scene
        self._connect_scene_signals()
        self.update()

    def set_grid_visible(self, visible: bool) -> None:
        self.grid_visible = visible
        self.update()

    def set_wireframe(self, enabled: bool) -> None:
        self.wireframe = enabled
        self.update()

    def reset_view(self) -> None:
        self.camera.reset()
        self.update()

    def apply_view_preset(self, preset_name: str) -> None:
        angles = _VIEW_PRESETS.get(preset_name)
        if angles is None:
            return
        self.camera.yaw_degrees, self.camera.pitch_degrees = angles
        self.update()

    def frame_selected(self) -> None:
        """Move the camera so the primary-selected object is nicely framed."""
        obj_id = self._selection.primary_selected_id()
        if obj_id is None:
            return
        obj = self._scene.get_object(obj_id)
        if obj is None:
            return
        local_radius = 1.0
        if obj.type == SceneObjectType.MESH:
            local_radius = self.renderer.get_local_radius(obj.metadata.get("primitive"))
        scale = obj.transform.scale.as_tuple()
        radius = local_radius * max(scale[0], scale[1], scale[2], 0.01)
        self.camera.frame_target(obj.transform.position.as_tuple(), max(radius, 0.5))
        self.update()

    # ------------------------------------------------------------------
    # Mouse navigation / selection / move
    # ------------------------------------------------------------------
    def _pixel_pos(self, event) -> Tuple[int, int]:
        pos: QPointF = event.position()
        return int(pos.x()), int(pos.y())

    def mousePressEvent(self, event) -> None:  # noqa: N802 (Qt override)
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        x, y = self._pixel_pos(event)
        self._last_pos = (x, y)
        self._press_pos = (x, y)

        button = event.button()
        modifiers = event.modifiers()

        if button == Qt.MouseButton.LeftButton:
            if modifiers & Qt.KeyboardModifier.AltModifier:
                self._drag_mode = "orbit"
            elif (
                self._tool_manager.active_tool == ToolType.MOVE
                and self._selection.has_selection()
            ):
                self._begin_move_drag(x, y)
            else:
                self._drag_mode = "select_pending"
        elif button == Qt.MouseButton.MiddleButton:
            self._drag_mode = "pan"
        elif button == Qt.MouseButton.RightButton:
            self._drag_mode = "orbit"

        event.accept()

    def mouseMoveEvent(self, event) -> None:  # noqa: N802 (Qt override)
        x, y = self._pixel_pos(event)
        if self._last_pos is None:
            self._last_pos = (x, y)
            return
        dx = x - self._last_pos[0]
        dy = y - self._last_pos[1]

        if self._drag_mode == "orbit":
            self.camera.orbit(dx * _ORBIT_SPEED, -dy * _ORBIT_SPEED)
            self.update()
        elif self._drag_mode == "pan":
            scale = max(0.01, self.camera.distance) * _PAN_SPEED
            self.camera.pan(dx * scale, dy * scale)
            self.update()
        elif self._drag_mode == "move":
            self._update_move_drag(x, y)
            self.update()

        self._last_pos = (x, y)
        event.accept()

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802 (Qt override)
        x, y = self._pixel_pos(event)
        button = event.button()

        if self._drag_mode == "select_pending" and button == Qt.MouseButton.LeftButton:
            if self._press_pos is not None:
                moved = max(abs(x - self._press_pos[0]), abs(y - self._press_pos[1]))
                if moved <= _CLICK_MOVE_THRESHOLD_PX:
                    self._perform_pick(x, y)
        elif self._drag_mode == "move" and button == Qt.MouseButton.LeftButton:
            self._finish_move_drag()

        self._drag_mode = None
        self._last_pos = None
        self._press_pos = None
        event.accept()

    def wheelEvent(self, event) -> None:  # noqa: N802 (Qt override)
        notches = event.angleDelta().y() / 120.0
        self.camera.zoom(notches * self.camera.distance * _ZOOM_SPEED)
        self.update()
        event.accept()

    def keyPressEvent(self, event) -> None:  # noqa: N802 (Qt override)
        if self._drag_mode == "move" and self._last_pos is not None:
            key = event.key()
            axis = {
                Qt.Key.Key_X: "X",
                Qt.Key.Key_Y: "Y",
                Qt.Key.Key_Z: "Z",
            }.get(key)
            if axis is not None:
                self._move_axis_lock = None if self._move_axis_lock == axis else axis
                self._update_move_drag(*self._last_pos)
                self.update()
                event.accept()
                return

        # Standard 3D-editor tool/action hotkeys. Deliberately handled
        # here (rather than as application-global QAction shortcuts) so
        # they only fire while the 3D viewport itself has keyboard
        # focus -- typing "w", "e", "r", "f", or pressing Delete while
        # renaming an object in the Outliner or editing the Name field
        # in Properties must type/delete text, not trigger a tool
        # switch or object deletion. See README "Keyboard Shortcuts".
        if not event.isAutoRepeat() and self._drag_mode is None:
            key = event.key()
            tool_for_key = {
                Qt.Key.Key_Q: ToolType.SELECT,
                Qt.Key.Key_W: ToolType.MOVE,
                Qt.Key.Key_E: ToolType.ROTATE,
                Qt.Key.Key_R: ToolType.SCALE,
            }.get(key)
            if tool_for_key is not None:
                self._tool_manager.set_active_tool(tool_for_key)
                event.accept()
                return
            if key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
                self._delete_selected()
                event.accept()
                return
            if key == Qt.Key.Key_F:
                self.frame_selected()
                event.accept()
                return

        super().keyPressEvent(event)

    def _delete_selected(self) -> None:
        selected_ids = self._selection.selected_ids()
        if not selected_ids:
            return
        for object_id in selected_ids:
            if object_id in self._scene:
                self._command_stack.execute(DeleteObjectCommand(self._scene, object_id))
        self._selection.deselect_all()

    # ------------------------------------------------------------------
    def _unproject(self, x: int, y: int) -> Tuple[np.ndarray, np.ndarray]:
        ndc_x, ndc_y = math3d.screen_to_ndc(x, y, max(1, self.width()), max(1, self.height()))
        view = self.camera.get_view_matrix()
        projection = self.camera.get_projection_matrix()
        return math3d.unproject_ray(ndc_x, ndc_y, view, projection)

    def _perform_pick(self, x: int, y: int) -> None:
        if not self.renderer.is_initialized:
            return
        object_id = self.renderer.pick(x, y, self._scene, self.camera, self.defaultFramebufferObject())
        if object_id is not None:
            self._selection.select(object_id)
        else:
            self._selection.deselect_all()

    def _begin_move_drag(self, x: int, y: int) -> None:
        obj_id = self._selection.primary_selected_id()
        obj = self._scene.get_object(obj_id) if obj_id else None
        if obj is None:
            self._drag_mode = None
            return

        self._drag_mode = "move"
        self._move_object_id = obj_id
        self._move_start_transform = obj.transform.copy()
        self._move_axis_lock = None
        self._move_plane_point = np.array(obj.transform.position.as_tuple(), dtype=np.float32)
        self._move_plane_normal = self.camera.forward().copy()

        origin, direction = self._unproject(x, y)
        hit = math3d.ray_plane_intersection(
            origin, direction, self._move_plane_point, self._move_plane_normal
        )
        self._move_start_hit = hit if hit is not None else self._move_plane_point.copy()

    def _update_move_drag(self, x: int, y: int) -> None:
        if self._move_object_id is None or self._move_start_hit is None:
            return
        obj = self._scene.get_object(self._move_object_id)
        if obj is None:
            return

        origin, direction = self._unproject(x, y)
        hit = math3d.ray_plane_intersection(
            origin, direction, self._move_plane_point, self._move_plane_normal
        )
        if hit is None:
            return

        delta = hit - self._move_start_hit
        if self._move_axis_lock == "X":
            delta = np.array([delta[0], 0.0, 0.0], dtype=np.float32)
        elif self._move_axis_lock == "Y":
            delta = np.array([0.0, delta[1], 0.0], dtype=np.float32)
        elif self._move_axis_lock == "Z":
            delta = np.array([0.0, 0.0, delta[2]], dtype=np.float32)

        start_pos = np.array(self._move_start_transform.position.as_tuple(), dtype=np.float32)
        new_pos = start_pos + delta
        obj.transform.position.x = float(new_pos[0])
        obj.transform.position.y = float(new_pos[1])
        obj.transform.position.z = float(new_pos[2])
        self._scene.notify_changed(self._move_object_id)

    def _finish_move_drag(self) -> None:
        object_id = self._move_object_id
        start_transform = self._move_start_transform
        if object_id is None or start_transform is None:
            self._reset_move_state()
            return

        obj = self._scene.get_object(object_id)
        if obj is None:
            self._reset_move_state()
            return

        final_transform = obj.transform.copy()
        moved = not np.allclose(
            final_transform.position.as_tuple(), start_transform.position.as_tuple(), atol=1e-6
        )

        if moved:
            # Revert to the pre-drag transform, then replay the change
            # through TransformObjectCommand so it becomes a single,
            # properly undoable edit instead of per-pixel history spam.
            obj.transform = start_transform.copy()
            self._scene.notify_changed(object_id)
            self._command_stack.execute(
                TransformObjectCommand(self._scene, object_id, final_transform)
            )

        self._reset_move_state()

    def _reset_move_state(self) -> None:
        self._move_object_id = None
        self._move_start_transform = None
        self._move_plane_point = None
        self._move_plane_normal = None
        self._move_start_hit = None
        self._move_axis_lock = None


class ViewportWidget(QWidget):
    """Central viewport panel: a small toolbar plus the OpenGL surface."""

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        tool_manager: ToolManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.gl_widget = ViewportGLWidget(scene, selection, tool_manager, command_stack, self)

        self._toolbar = self._build_toolbar()
        layout.addWidget(self._toolbar)
        layout.addWidget(self.gl_widget, stretch=1)

    def _build_toolbar(self) -> QWidget:
        bar = QWidget(self)
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(6, 4, 6, 4)
        bar_layout.setSpacing(10)

        bar_layout.addWidget(
            self._labeled_combo("View", list(_VIEW_PRESETS.keys()), self._on_view_preset_changed)
        )
        bar_layout.addWidget(
            self._labeled_combo(
                "Shading", ["Shaded", "Wireframe"], self._on_shading_mode_changed
            )
        )
        bar_layout.addStretch(1)
        return bar

    def _labeled_combo(self, label_text: str, items: List[str], slot) -> QWidget:
        container = QWidget(self)
        row = QHBoxLayout(container)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)
        label = QLabel(label_text)
        label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY};")
        combo = QComboBox()
        combo.addItems(items)
        combo.currentTextChanged.connect(slot)
        row.addWidget(label)
        row.addWidget(combo)
        return container

    def _on_view_preset_changed(self, preset_name: str) -> None:
        self.gl_widget.apply_view_preset(preset_name)

    def _on_shading_mode_changed(self, mode_name: str) -> None:
        self.gl_widget.set_wireframe(mode_name == "Wireframe")

    # -- public API used by MainWindow --------------------------------
    def rebind_scene(self, new_scene: Scene) -> None:
        self.gl_widget.rebind_scene(new_scene)

    def set_grid_visible(self, visible: bool) -> None:
        self.gl_widget.set_grid_visible(visible)

    def set_wireframe(self, enabled: bool) -> None:
        self.gl_widget.set_wireframe(enabled)

    def reset_view(self) -> None:
        self.gl_widget.reset_view()

    def frame_selected(self) -> None:
        self.gl_widget.frame_selected()

    def cleanup(self) -> None:
        self.gl_widget.cleanup()
