"""Centralized application theme.

An original dark theme (not a copy of any existing application's
stylesheet). Kept in one place so the whole look can be changed later
(e.g. a light theme, or user-configurable accent colors) without
hunting through every widget file.
"""
from __future__ import annotations

# Core palette -----------------------------------------------------------
COLOR_BG_DARKEST = "#1b1d21"
COLOR_BG_DARK = "#212328"
COLOR_BG_PANEL = "#26282e"
COLOR_BG_PANEL_ALT = "#2c2f36"
COLOR_BG_RAISED = "#32353d"
COLOR_BORDER = "#3a3d45"
COLOR_BORDER_LIGHT = "#4a4e58"

COLOR_TEXT_PRIMARY = "#e4e6eb"
COLOR_TEXT_SECONDARY = "#9aa0ac"
COLOR_TEXT_DISABLED = "#5f636d"

COLOR_ACCENT = "#4f9dff"
COLOR_ACCENT_HOVER = "#6bacff"
COLOR_ACCENT_PRESSED = "#3d84e0"

COLOR_SELECTION_BG = "#2f5d8a"
COLOR_SELECTION_BORDER = "#4f9dff"

COLOR_VIEWPORT_BG = "#17181b"

FONT_FAMILY = '"Segoe UI", "Inter", "Helvetica Neue", Arial, sans-serif'
FONT_SIZE_BASE = "12px"
FONT_SIZE_SMALL = "11px"
FONT_SIZE_HEADER = "12px"

DARK_THEME_STYLESHEET = f"""
* {{
    font-family: {FONT_FAMILY};
    font-size: {FONT_SIZE_BASE};
    color: {COLOR_TEXT_PRIMARY};
    outline: none;
}}

QMainWindow {{
    background-color: {COLOR_BG_DARK};
}}

QWidget {{
    background-color: {COLOR_BG_DARK};
}}

QMenuBar {{
    background-color: {COLOR_BG_DARKEST};
    border-bottom: 1px solid {COLOR_BORDER};
    padding: 2px;
}}

QMenuBar::item {{
    background: transparent;
    padding: 4px 10px;
    border-radius: 3px;
}}

QMenuBar::item:selected {{
    background-color: {COLOR_BG_RAISED};
}}

QMenu {{
    background-color: {COLOR_BG_PANEL};
    border: 1px solid {COLOR_BORDER_LIGHT};
    padding: 4px;
}}

QMenu::item {{
    padding: 5px 24px 5px 12px;
    border-radius: 3px;
}}

QMenu::item:selected {{
    background-color: {COLOR_ACCENT};
    color: white;
}}

QMenu::separator {{
    height: 1px;
    background: {COLOR_BORDER};
    margin: 4px 6px;
}}

QToolBar {{
    background-color: {COLOR_BG_DARKEST};
    border-bottom: 1px solid {COLOR_BORDER};
    spacing: 3px;
    padding: 4px;
}}

QToolBar::separator {{
    background-color: {COLOR_BORDER_LIGHT};
    width: 1px;
    margin: 4px 6px;
}}

QToolButton {{
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    padding: 4px 8px;
    color: {COLOR_TEXT_PRIMARY};
}}

QToolButton:hover {{
    background-color: {COLOR_BG_RAISED};
    border: 1px solid {COLOR_BORDER_LIGHT};
}}

QToolButton:pressed, QToolButton:checked {{
    background-color: {COLOR_SELECTION_BG};
    border: 1px solid {COLOR_SELECTION_BORDER};
}}

QDockWidget {{
    titlebar-close-icon: none;
    color: {COLOR_TEXT_PRIMARY};
    border: 1px solid {COLOR_BORDER};
}}

QDockWidget::title {{
    background-color: {COLOR_BG_PANEL_ALT};
    padding: 6px 8px;
    border-bottom: 1px solid {COLOR_BORDER};
    font-weight: 600;
    font-size: {FONT_SIZE_HEADER};
}}

QTreeWidget, QTreeView {{
    background-color: {COLOR_BG_PANEL};
    border: none;
    alternate-background-color: {COLOR_BG_PANEL_ALT};
    show-decoration-selected: 1;
}}

QTreeWidget::item, QTreeView::item {{
    padding: 3px 2px;
    border: none;
}}

QTreeWidget::item:selected, QTreeView::item:selected {{
    background-color: {COLOR_SELECTION_BG};
    color: white;
}}

QTreeWidget::item:hover, QTreeView::item:hover {{
    background-color: {COLOR_BG_RAISED};
}}

QHeaderView::section {{
    background-color: {COLOR_BG_PANEL_ALT};
    color: {COLOR_TEXT_SECONDARY};
    padding: 4px;
    border: none;
    border-bottom: 1px solid {COLOR_BORDER};
}}

QScrollBar:vertical {{
    background: {COLOR_BG_PANEL};
    width: 12px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background: {COLOR_BORDER_LIGHT};
    border-radius: 5px;
    min-height: 24px;
    margin: 2px;
}}

QScrollBar::handle:vertical:hover {{
    background: {COLOR_ACCENT};
}}

QScrollBar:horizontal {{
    background: {COLOR_BG_PANEL};
    height: 12px;
}}

QScrollBar::handle:horizontal {{
    background: {COLOR_BORDER_LIGHT};
    border-radius: 5px;
    min-width: 24px;
    margin: 2px;
}}

QScrollBar::add-line, QScrollBar::sub-line {{
    width: 0;
    height: 0;
    border: none;
}}

QStatusBar {{
    background-color: {COLOR_BG_DARKEST};
    border-top: 1px solid {COLOR_BORDER};
    color: {COLOR_TEXT_SECONDARY};
}}

QLabel {{
    background: transparent;
}}

QLabel[role="section-header"] {{
    color: {COLOR_TEXT_SECONDARY};
    font-weight: 600;
    font-size: {FONT_SIZE_SMALL};
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding-top: 6px;
}}

QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {{
    background-color: {COLOR_BG_PANEL_ALT};
    border: 1px solid {COLOR_BORDER};
    border-radius: 3px;
    padding: 3px 6px;
    color: {COLOR_TEXT_PRIMARY};
    selection-background-color: {COLOR_ACCENT};
}}

QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {{
    border: 1px solid {COLOR_ACCENT};
}}

QLineEdit:disabled, QDoubleSpinBox:disabled, QSpinBox:disabled {{
    color: {COLOR_TEXT_DISABLED};
    background-color: {COLOR_BG_PANEL};
}}

QPushButton {{
    background-color: {COLOR_BG_RAISED};
    border: 1px solid {COLOR_BORDER_LIGHT};
    border-radius: 4px;
    padding: 5px 12px;
}}

QPushButton:hover {{
    background-color: {COLOR_BORDER_LIGHT};
}}

QPushButton:pressed {{
    background-color: {COLOR_SELECTION_BG};
}}

QPushButton:disabled {{
    color: {COLOR_TEXT_DISABLED};
    background-color: {COLOR_BG_PANEL};
}}

QSlider::groove:horizontal {{
    background: {COLOR_BG_PANEL_ALT};
    height: 4px;
    border-radius: 2px;
}}

QSlider::handle:horizontal {{
    background: {COLOR_ACCENT};
    width: 12px;
    margin: -5px 0;
    border-radius: 6px;
}}

QFrame#ViewportFrame {{
    background-color: {COLOR_VIEWPORT_BG};
    border: 1px solid {COLOR_BORDER};
}}

QFrame#PanelSeparator {{
    background-color: {COLOR_BORDER};
}}

QSplitter::handle {{
    background-color: {COLOR_BG_DARK};
}}

QToolTip {{
    background-color: {COLOR_BG_RAISED};
    color: {COLOR_TEXT_PRIMARY};
    border: 1px solid {COLOR_BORDER_LIGHT};
    padding: 4px 6px;
}}
"""
