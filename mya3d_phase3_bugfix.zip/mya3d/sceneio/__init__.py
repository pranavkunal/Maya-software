"""File I/O: scene serialization to/from disk."""
