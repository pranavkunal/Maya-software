"""Scene serialization to/from ``.mya`` files (JSON internally).

The on-disk format is versioned (``SCENE_FORMAT_VERSION``) so future
phases can add fields while ``load_scene`` stays able to read older
files. Phase 3 bumps the version to 2 to record that animation data
may now be present, but the *scene object* schema itself hasn't
changed shape (mesh primitive, camera, and material data all already
lived in the generic ``SceneObject.metadata`` dict since Phase 1/2),
so version-1 files continue to load unchanged -- ``scene_from_dict``
accepts any version in ``SUPPORTED_VERSIONS``, not just an exact match.

Keyframe animation (``core.animation.AnimationClip``) is NOT part of
``Scene`` itself (see core/animation.py), so it isn't included by the
plain ``scene_to_dict``/``scene_from_dict``/``save_scene``/``load_scene``
functions below -- those keep their exact Phase 1/2 signatures and
behavior for full backward compatibility. Callers that also want
animation data (``ui/main_window.py``) use the ``*_with_animation``
variants instead, which store animation under top-level ``"animations"``
key (defaulting to empty/absent for old files).

Nothing here ever serializes raw GPU buffers or OpenGL state -- only
logical scene data.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from core.animation import AnimationClip
from core.scene import Scene
from core.scene_object import SceneObject

logger = logging.getLogger(__name__)

SCENE_FORMAT_VERSION = 2
#: Versions this build can read. All are structurally compatible (the
#: SceneObject/metadata shape has never changed between them) so no
#: migration logic is needed -- just accept the range.
SUPPORTED_VERSIONS = (1, 2)


class SceneSerializationError(Exception):
    """Raised when a scene file cannot be read or written."""


def scene_to_dict(scene: Scene) -> Dict[str, Any]:
    return {
        "version": SCENE_FORMAT_VERSION,
        "name": scene.name,
        "root_ids": scene.root_ids(),
        "objects": [obj.to_dict() for obj in scene.all_objects()],
    }


def scene_from_dict(data: Dict[str, Any]) -> Scene:
    if "version" not in data:
        raise SceneSerializationError("Scene file is missing a 'version' field")
    version = data["version"]
    if version not in SUPPORTED_VERSIONS:
        raise SceneSerializationError(
            f"Unsupported scene file version {version!r} "
            f"(this build supports versions {SUPPORTED_VERSIONS})"
        )

    scene = Scene(name=data.get("name", "Untitled"))

    raw_objects = data.get("objects", [])
    if not isinstance(raw_objects, list):
        raise SceneSerializationError("Scene file 'objects' must be a list")

    objects_by_id: Dict[str, SceneObject] = {}
    seen_ids = set()
    for raw in raw_objects:
        try:
            obj = SceneObject.from_dict(raw)
        except (KeyError, ValueError, TypeError) as exc:
            raise SceneSerializationError(f"Invalid object entry in scene file: {exc}") from exc
        if obj.id in seen_ids:
            raise SceneSerializationError(f"Duplicate object id in scene file: {obj.id}")
        seen_ids.add(obj.id)
        objects_by_id[obj.id] = obj

    # Reinsert respecting hierarchy: roots first (as declared), then
    # children, using Scene.add_object so internal indices stay
    # consistent. We bypass the id-collision check by constructing the
    # scene's private dict directly is avoided -- instead we walk the
    # tree using the public API.
    root_ids = data.get("root_ids", [])
    if not isinstance(root_ids, list):
        raise SceneSerializationError("Scene file 'root_ids' must be a list")

    def add_recursive(object_id: str, parent_id: Union[str, None]) -> None:
        obj = objects_by_id.get(object_id)
        if obj is None:
            raise SceneSerializationError(f"root_ids/children reference unknown id: {object_id}")
        children = list(obj.children_ids)
        # add_object mutates children_ids of the parent, and expects a
        # "fresh" object; reset children_ids, then re-add each child.
        obj.children_ids = []
        scene.add_object(obj, parent_id=parent_id)
        for child_id in children:
            add_recursive(child_id, object_id)

    for root_id in root_ids:
        add_recursive(root_id, None)

    # Any object not reachable from root_ids (corrupt file) is still
    # loaded as a root rather than silently dropped, so users don't
    # lose data.
    for obj_id, obj in objects_by_id.items():
        if obj_id not in scene:
            logger.warning("Object '%s' was not reachable from root_ids; attaching as root", obj_id)
            obj.children_ids = []
            obj.parent_id = None
            scene.add_object(obj, parent_id=None)

    return scene


def save_scene(scene: Scene, path: Union[str, Path]) -> None:
    """Save ``scene`` to ``path`` as a ``.mya`` (JSON) file."""
    path = Path(path)
    try:
        data = scene_to_dict(scene)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.info("Scene saved to %s", path)
    except OSError as exc:
        logger.error("Failed to save scene to %s: %s", path, exc)
        raise SceneSerializationError(f"Could not write scene file: {exc}") from exc


def load_scene(path: Union[str, Path]) -> Scene:
    """Load a scene from a ``.mya`` (JSON) file.

    Raises:
        SceneSerializationError: if the file is missing, unreadable,
            not valid JSON, or structurally invalid.
    """
    path = Path(path)
    if not path.exists():
        raise SceneSerializationError(f"Scene file does not exist: {path}")

    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.error("Failed to read scene file %s: %s", path, exc)
        raise SceneSerializationError(f"Could not read scene file: {exc}") from exc

    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        logger.error("Invalid JSON in scene file %s: %s", path, exc)
        raise SceneSerializationError(f"Scene file is not valid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise SceneSerializationError("Scene file root must be a JSON object")

    scene = scene_from_dict(data)
    logger.info("Scene loaded from %s", path)
    return scene


# ----------------------------------------------------------------------
# Animation-aware variants (Phase 3). See module docstring: kept
# separate from the functions above for full backward compatibility.
# ----------------------------------------------------------------------
def scene_to_dict_with_animation(
    scene: Scene, animation_clip: Optional[AnimationClip]
) -> Dict[str, Any]:
    data = scene_to_dict(scene)
    if animation_clip is not None:
        data["animations"] = animation_clip.to_dict()
    return data


def scene_from_dict_with_animation(data: Dict[str, Any]) -> Tuple[Scene, AnimationClip]:
    scene = scene_from_dict(data)
    raw_animations = data.get("animations")
    animation_clip = (
        AnimationClip.from_dict(raw_animations) if isinstance(raw_animations, dict) else AnimationClip()
    )
    return scene, animation_clip


def save_scene_with_animation(
    scene: Scene, animation_clip: Optional[AnimationClip], path: Union[str, Path]
) -> None:
    """Save ``scene`` plus its keyframe animation to ``path``."""
    path = Path(path)
    try:
        data = scene_to_dict_with_animation(scene, animation_clip)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.info("Scene saved to %s", path)
    except OSError as exc:
        logger.error("Failed to save scene to %s: %s", path, exc)
        raise SceneSerializationError(f"Could not write scene file: {exc}") from exc


def load_scene_with_animation(path: Union[str, Path]) -> Tuple[Scene, AnimationClip]:
    """Load a scene plus its keyframe animation from a ``.mya`` file.

    Files with no ``"animations"`` key (any Phase 1/2 file, or a
    Phase 3 file saved with no keyframes) load with an empty
    ``AnimationClip`` -- never an error.
    """
    path = Path(path)
    if not path.exists():
        raise SceneSerializationError(f"Scene file does not exist: {path}")
    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.error("Failed to read scene file %s: %s", path, exc)
        raise SceneSerializationError(f"Could not read scene file: {exc}") from exc
    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        logger.error("Invalid JSON in scene file %s: %s", path, exc)
        raise SceneSerializationError(f"Scene file is not valid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise SceneSerializationError("Scene file root must be a JSON object")

    scene, animation_clip = scene_from_dict_with_animation(data)
    logger.info("Scene loaded from %s", path)
    return scene, animation_clip
