"""Application bootstrap: logging configuration and QApplication factory.

Kept separate from main.py so main.py stays a thin entry point.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from app.settings import APPLICATION_NAME, ORGANIZATION_NAME

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def configure_logging(log_to_file: bool = True, level: int = logging.INFO) -> None:
    """Configure root logging for the application.

    Logs to stderr always, and additionally to a rotating-free simple
    log file under a user-writable ``logs/`` directory when
    ``log_to_file`` is True and the directory is writable (failures to
    create the log file are non-fatal -- console logging still works).
    """
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]

    if log_to_file:
        try:
            log_dir = Path.cwd() / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_dir / "mya3d.log", encoding="utf-8")
            handlers.append(file_handler)
        except OSError:
            # Non-fatal: fall back to console-only logging.
            pass

    logging.basicConfig(level=level, format=LOG_FORMAT, handlers=handlers, force=True)


def create_application(argv: list[str]) -> QApplication:
    """Create and configure the QApplication instance."""
    app = QApplication(argv)
    app.setOrganizationName(ORGANIZATION_NAME)
    app.setApplicationName(APPLICATION_NAME)
    app.setApplicationDisplayName(APPLICATION_NAME)

    # Explicitly give the whole application a default font with a
    # valid, positive POINT size before the stylesheet is applied.
    # This is a defensive second layer on top of ui/styles.py's own
    # px->pt fix: it guarantees QFont.pointSize() is valid from the
    # very start of the app (never -1), which is what caused
    # "QFont::setPointSize: Point size <= 0 (-1)" on Windows. Do not
    # replace this with a pixel-size font.
    default_font = QFont("Segoe UI", 9)
    app.setFont(default_font)

    return app
