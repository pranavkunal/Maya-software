"""Application bootstrap: QApplication setup, settings, logging."""
