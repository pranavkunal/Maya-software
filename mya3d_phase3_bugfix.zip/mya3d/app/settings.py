"""Application settings persistence.

Uses QSettings for lightweight application preferences (window
geometry/state, theme). Project *scene* data must never go through
QSettings -- that always goes through sceneio.scene_serializer instead.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import QByteArray, QSettings

logger = logging.getLogger(__name__)

ORGANIZATION_NAME = "MYA3D"
APPLICATION_NAME = "MYA 3D Editor"

_KEY_WINDOW_GEOMETRY = "window/geometry"
_KEY_WINDOW_STATE = "window/state"
_KEY_THEME = "appearance/theme"

DEFAULT_THEME = "dark"


class AppSettings:
    """Thin, typed wrapper around QSettings for this application."""

    def __init__(self) -> None:
        self._settings = QSettings(ORGANIZATION_NAME, APPLICATION_NAME)

    # ------------------------------------------------------------------
    def save_window_geometry(self, geometry: QByteArray) -> None:
        self._settings.setValue(_KEY_WINDOW_GEOMETRY, geometry)

    def load_window_geometry(self) -> Optional[QByteArray]:
        value = self._settings.value(_KEY_WINDOW_GEOMETRY)
        return value if isinstance(value, QByteArray) else None

    def save_window_state(self, state: QByteArray) -> None:
        self._settings.setValue(_KEY_WINDOW_STATE, state)

    def load_window_state(self) -> Optional[QByteArray]:
        value = self._settings.value(_KEY_WINDOW_STATE)
        return value if isinstance(value, QByteArray) else None

    # ------------------------------------------------------------------
    def save_theme(self, theme_name: str) -> None:
        self._settings.setValue(_KEY_THEME, theme_name)

    def load_theme(self) -> str:
        value = self._settings.value(_KEY_THEME, DEFAULT_THEME)
        return str(value) if value else DEFAULT_THEME

    # ------------------------------------------------------------------
    def clear_all(self) -> None:
        """Used by Windows > Reset Layout (clears geometry/state only)."""
        self._settings.remove(_KEY_WINDOW_GEOMETRY)
        self._settings.remove(_KEY_WINDOW_STATE)
        logger.info("Cleared saved window geometry/state")

    def sync(self) -> None:
        self._settings.sync()
