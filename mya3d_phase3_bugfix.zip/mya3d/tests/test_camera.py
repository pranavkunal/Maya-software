import math

import numpy as np

from graphics.camera import EditorCamera


def test_default_camera_has_sensible_values():
    cam = EditorCamera()
    assert cam.distance > 0
    assert 0 < cam.fov_y_degrees < 180
    assert cam.near > 0
    assert cam.far > cam.near


def test_camera_position_is_distance_away_from_target():
    cam = EditorCamera(target=(0.0, 0.0, 0.0), distance=10.0, yaw_degrees=0.0, pitch_degrees=0.0)
    pos = cam.position()
    assert math.isclose(float(np.linalg.norm(pos)), 10.0, abs_tol=1e-4)


def test_camera_forward_points_from_eye_to_target():
    cam = EditorCamera(target=(0.0, 0.0, 0.0), distance=5.0)
    forward = cam.forward()
    pos = cam.position()
    expected = -pos / np.linalg.norm(pos)
    assert np.allclose(forward, expected, atol=1e-4)


def test_orbit_changes_yaw_and_pitch():
    cam = EditorCamera(yaw_degrees=0.0, pitch_degrees=0.0)
    cam.orbit(30.0, 10.0)
    assert math.isclose(cam.yaw_degrees, 30.0, abs_tol=1e-6)
    assert math.isclose(cam.pitch_degrees, 10.0, abs_tol=1e-6)


def test_orbit_pitch_is_clamped_to_avoid_flipping():
    cam = EditorCamera(pitch_degrees=0.0)
    cam.orbit(0.0, 500.0)
    assert cam.pitch_degrees <= 89.0
    cam.orbit(0.0, -1000.0)
    assert cam.pitch_degrees >= -89.0


def test_orbit_yaw_wraps_around_360():
    cam = EditorCamera(yaw_degrees=350.0)
    cam.orbit(20.0, 0.0)
    assert 0.0 <= cam.yaw_degrees < 360.0


def test_zoom_decreases_distance_when_positive():
    cam = EditorCamera(distance=10.0)
    cam.zoom(2.0)
    assert cam.distance < 10.0


def test_zoom_is_clamped_to_minimum_distance():
    cam = EditorCamera(distance=1.0)
    cam.zoom(1000.0)
    assert cam.distance > 0.0


def test_pan_moves_target():
    cam = EditorCamera(target=(0.0, 0.0, 0.0), yaw_degrees=0.0, pitch_degrees=0.0)
    original_target = cam.target.copy()
    cam.pan(1.0, 0.0)
    assert not np.allclose(cam.target, original_target)


def test_get_view_matrix_shape():
    cam = EditorCamera()
    view = cam.get_view_matrix()
    assert view.shape == (4, 4)
    assert np.all(np.isfinite(view))


def test_get_projection_matrix_shape():
    cam = EditorCamera()
    proj = cam.get_projection_matrix()
    assert proj.shape == (4, 4)
    assert np.all(np.isfinite(proj))


def test_set_aspect_ratio_updates_value():
    cam = EditorCamera()
    cam.set_aspect_ratio(1600, 800)
    assert math.isclose(cam.aspect_ratio, 2.0, abs_tol=1e-6)


def test_set_aspect_ratio_guards_against_zero_height():
    cam = EditorCamera()
    cam.set_aspect_ratio(800, 0)
    assert cam.aspect_ratio > 0


def test_frame_target_points_camera_at_center():
    cam = EditorCamera()
    cam.frame_target((3.0, 0.0, 0.0), radius=2.0)
    assert np.allclose(cam.target, [3.0, 0.0, 0.0])
    assert cam.distance > 0


def test_reset_restores_defaults():
    cam = EditorCamera()
    cam.orbit(100.0, 50.0)
    cam.zoom(500.0)
    cam.pan(10.0, 10.0)
    cam.reset()
    assert np.allclose(cam.target, [0.0, 0.0, 0.0])
    assert math.isclose(cam.distance, 8.0, abs_tol=1e-6)
