import math

import numpy as np

from graphics.camera import (
    PROJECTION_ORTHOGRAPHIC,
    PROJECTION_PERSPECTIVE,
    EditorCamera,
    SceneCameraSettings,
    scene_camera_projection_matrix,
    scene_camera_view_matrix,
)


# ------------------------------------------------------------------
# EditorCamera orthographic mode
# ------------------------------------------------------------------
def test_editor_camera_defaults_to_perspective():
    cam = EditorCamera()
    assert cam.projection_mode == PROJECTION_PERSPECTIVE
    assert cam.is_orthographic is False


def test_editor_camera_set_orthographic_toggles_mode():
    cam = EditorCamera()
    cam.set_orthographic(True)
    assert cam.is_orthographic is True
    cam.set_orthographic(False)
    assert cam.is_orthographic is False


def test_editor_camera_orthographic_projection_is_finite():
    cam = EditorCamera()
    cam.set_orthographic(True)
    proj = cam.get_projection_matrix()
    assert proj.shape == (4, 4)
    assert np.all(np.isfinite(proj))


def test_editor_camera_orthographic_does_not_shrink_with_distance():
    """The defining property of orthographic projection: a fixed-size
    object at two different depths projects to the same apparent size."""
    cam = EditorCamera(target=(0, 0, 0), distance=10.0, yaw_degrees=0.0, pitch_degrees=0.0)
    cam.set_orthographic(True)
    view = cam.get_view_matrix()
    proj = cam.get_projection_matrix()
    vp = proj @ view

    near_point = vp @ np.array([1.0, 0.0, 5.0, 1.0], dtype=np.float32)
    far_point = vp @ np.array([1.0, 0.0, -5.0, 1.0], dtype=np.float32)
    near_ndc_x = near_point[0] / near_point[3]
    far_ndc_x = far_point[0] / far_point[3]
    assert math.isclose(near_ndc_x, far_ndc_x, abs_tol=1e-4)


def test_editor_camera_orbit_pan_zoom_still_work_in_orthographic_mode():
    cam = EditorCamera()
    cam.set_orthographic(True)
    cam.orbit(30.0, 10.0)
    cam.pan(1.0, 1.0)
    cam.zoom(1.0)
    # Should not raise, and should still produce a valid projection.
    assert np.all(np.isfinite(cam.get_projection_matrix()))
    assert np.all(np.isfinite(cam.get_view_matrix()))


def test_apply_ortho_preset_sets_yaw_and_pitch():
    cam = EditorCamera()
    cam.apply_ortho_preset(180.0, 0.0)
    assert math.isclose(cam.yaw_degrees, 180.0, abs_tol=1e-6)
    assert math.isclose(cam.pitch_degrees, 0.0, abs_tol=1e-6)


def test_apply_ortho_preset_clamps_pitch():
    cam = EditorCamera()
    cam.apply_ortho_preset(0.0, 200.0)
    assert cam.pitch_degrees <= 89.0


# ------------------------------------------------------------------
# SceneCameraSettings
# ------------------------------------------------------------------
def test_scene_camera_settings_defaults():
    settings = SceneCameraSettings.default()
    assert settings.projection == PROJECTION_PERSPECTIVE
    assert settings.fov_y_degrees > 0
    assert settings.far > settings.near


def test_scene_camera_settings_clamps_invalid_projection():
    settings = SceneCameraSettings(projection="not_a_real_mode")
    assert settings.projection == PROJECTION_PERSPECTIVE


def test_scene_camera_settings_clamps_far_greater_than_near():
    settings = SceneCameraSettings(near=10.0, far=1.0)
    assert settings.far > settings.near


def test_scene_camera_settings_to_from_dict_roundtrip():
    settings = SceneCameraSettings(
        fov_y_degrees=60.0, near=0.5, far=2000.0, projection=PROJECTION_ORTHOGRAPHIC, ortho_height=15.0
    )
    restored = SceneCameraSettings.from_dict(settings.to_dict())
    assert restored.fov_y_degrees == settings.fov_y_degrees
    assert restored.projection == PROJECTION_ORTHOGRAPHIC
    assert restored.ortho_height == 15.0


def test_scene_camera_settings_from_empty_dict_uses_defaults():
    restored = SceneCameraSettings.from_dict({})
    assert restored.projection == PROJECTION_PERSPECTIVE


# ------------------------------------------------------------------
# Scene camera view/projection matrices
# ------------------------------------------------------------------
def test_scene_camera_view_matrix_identity_rotation_looks_down_negative_z():
    view = scene_camera_view_matrix((0.0, 0.0, 5.0), (0.0, 0.0, 0.0))
    # A point at the origin (in front of the camera, since it looks
    # down -Z) should land at a negative Z in view space.
    from graphics import math3d
    point_in_view = math3d.transform_point(view, (0.0, 0.0, 0.0))
    assert point_in_view[2] < 0


def test_scene_camera_view_matrix_eye_maps_to_origin():
    from graphics import math3d
    view = scene_camera_view_matrix((3.0, 2.0, 1.0), (0.0, 0.0, 0.0))
    eye_in_view = math3d.transform_point(view, (3.0, 2.0, 1.0))
    assert np.allclose(eye_in_view, [0.0, 0.0, 0.0], atol=1e-4)


def test_scene_camera_projection_matrix_perspective():
    settings = SceneCameraSettings(projection=PROJECTION_PERSPECTIVE)
    proj = scene_camera_projection_matrix(settings, aspect_ratio=1.5)
    assert proj.shape == (4, 4)
    assert np.all(np.isfinite(proj))


def test_scene_camera_projection_matrix_orthographic():
    settings = SceneCameraSettings(projection=PROJECTION_ORTHOGRAPHIC, ortho_height=20.0)
    proj = scene_camera_projection_matrix(settings, aspect_ratio=1.5)
    assert proj.shape == (4, 4)
    assert np.all(np.isfinite(proj))


# ------------------------------------------------------------------
# SceneCameraView adapter (duck-typed like EditorCamera)
# ------------------------------------------------------------------
def test_scene_camera_view_adapter_matches_editor_camera_interface():
    from core.object_types import SceneObjectType
    from core.scene_object import SceneObject
    from graphics.camera import SceneCameraView

    obj = SceneObject(name="Camera", type=SceneObjectType.CAMERA)
    obj.transform.position.z = 5.0
    view = SceneCameraView(obj, aspect_ratio=1.777)

    assert np.allclose(view.position(), [0.0, 0.0, 5.0])
    assert view.get_view_matrix().shape == (4, 4)
    assert view.get_projection_matrix().shape == (4, 4)


def test_scene_camera_view_adapter_reads_live_metadata():
    from core.object_types import SceneObjectType
    from core.scene_object import SceneObject
    from graphics.camera import PROJECTION_ORTHOGRAPHIC, SceneCameraView

    obj = SceneObject(name="Camera", type=SceneObjectType.CAMERA)
    view = SceneCameraView(obj)
    persp_proj = view.get_projection_matrix()

    obj.metadata["camera"] = {"projection": PROJECTION_ORTHOGRAPHIC, "ortho_height": 5.0}
    ortho_proj = view.get_projection_matrix()

    assert not np.allclose(persp_proj, ortho_proj)


def test_scene_camera_view_adapter_set_aspect_ratio():
    from core.object_types import SceneObjectType
    from core.scene_object import SceneObject
    from graphics.camera import SceneCameraView

    obj = SceneObject(name="Camera", type=SceneObjectType.CAMERA)
    view = SceneCameraView(obj)
    view.set_aspect_ratio(1600, 800)
    assert math.isclose(view.aspect_ratio, 2.0, abs_tol=1e-6)
