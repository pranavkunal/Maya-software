from ui.timeline import DEFAULT_FPS, TimelineState


def test_timeline_state_defaults():
    state = TimelineState()
    assert state.start_frame == 1
    assert state.end_frame == 120
    assert state.current_frame == 1


def test_timeline_state_custom_values():
    state = TimelineState(start_frame=10, end_frame=50, current_frame=20)
    assert state.start_frame == 10
    assert state.end_frame == 50
    assert state.current_frame == 20


def test_clamp_current_clamps_below_start():
    state = TimelineState(start_frame=10, end_frame=50, current_frame=1)
    state.clamp_current()
    assert state.current_frame == 10


def test_clamp_current_clamps_above_end():
    state = TimelineState(start_frame=1, end_frame=50, current_frame=999)
    state.clamp_current()
    assert state.current_frame == 50


def test_clamp_current_leaves_in_range_value_unchanged():
    state = TimelineState(start_frame=1, end_frame=120, current_frame=42)
    state.clamp_current()
    assert state.current_frame == 42


def test_default_fps_is_24():
    assert DEFAULT_FPS == 24
