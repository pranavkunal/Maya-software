"""Ensures the project root is importable as top-level packages
(core, editor, io, graphics) when running `pytest` from the project
root, without needing an editable install.
"""
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
