import numpy as np
import pytest

from graphics.mesh import MeshData
from graphics.primitives import (
    PRIMITIVE_GENERATORS,
    generate_cube,
    generate_cylinder,
    generate_plane,
    generate_primitive,
    generate_sphere,
)


# ------------------------------------------------------------------
# Cube
# ------------------------------------------------------------------
def test_generate_cube_is_valid():
    mesh = generate_cube()
    assert isinstance(mesh, MeshData)
    assert mesh.is_valid()


def test_generate_cube_vertex_and_index_counts():
    mesh = generate_cube()
    # 6 faces * 4 unique vertices (not shared, for flat face normals)
    assert mesh.vertex_count == 24
    # 6 faces * 2 triangles * 3 indices
    assert mesh.index_count == 36
    assert mesh.triangle_count == 12


def test_generate_cube_is_centered_on_origin():
    mesh = generate_cube(size=2.0)
    centroid = mesh.positions.mean(axis=0)
    assert np.allclose(centroid, [0.0, 0.0, 0.0], atol=1e-5)


def test_generate_cube_respects_size():
    mesh = generate_cube(size=4.0)
    half_extent = np.abs(mesh.positions).max()
    assert np.isclose(half_extent, 2.0)


def test_generate_cube_normals_are_unit_length():
    mesh = generate_cube()
    lengths = np.linalg.norm(mesh.normals, axis=1)
    assert np.allclose(lengths, 1.0, atol=1e-5)


# ------------------------------------------------------------------
# Plane
# ------------------------------------------------------------------
def test_generate_plane_is_valid():
    mesh = generate_plane()
    assert mesh.is_valid()


def test_generate_plane_lies_on_y_zero():
    mesh = generate_plane()
    assert np.allclose(mesh.positions[:, 1], 0.0)


def test_generate_plane_normals_point_up():
    mesh = generate_plane()
    assert np.allclose(mesh.normals, [0.0, 1.0, 0.0])


def test_generate_plane_default_vertex_and_index_counts():
    mesh = generate_plane(segments=1)
    assert mesh.vertex_count == 4
    assert mesh.index_count == 6


def test_generate_plane_segments_increase_vertex_count():
    coarse = generate_plane(segments=1)
    fine = generate_plane(segments=4)
    assert fine.vertex_count > coarse.vertex_count
    assert fine.is_valid()


# ------------------------------------------------------------------
# Sphere
# ------------------------------------------------------------------
def test_generate_sphere_is_valid():
    mesh = generate_sphere()
    assert mesh.is_valid()


def test_generate_sphere_vertices_lie_on_radius():
    mesh = generate_sphere(radius=3.0, rings=8, segments=12)
    distances = np.linalg.norm(mesh.positions, axis=1)
    assert np.allclose(distances, 3.0, atol=1e-4)


def test_generate_sphere_normals_match_normalized_position():
    mesh = generate_sphere(radius=2.0, rings=8, segments=12)
    expected_normals = mesh.positions / np.linalg.norm(mesh.positions, axis=1, keepdims=True)
    assert np.allclose(mesh.normals, expected_normals, atol=1e-4)


def test_generate_sphere_not_degenerate_with_minimum_segments():
    mesh = generate_sphere(rings=1, segments=1)
    assert mesh.is_valid()
    assert mesh.vertex_count > 0
    assert mesh.triangle_count > 0


def test_generate_sphere_more_segments_more_geometry():
    coarse = generate_sphere(rings=4, segments=6)
    fine = generate_sphere(rings=16, segments=24)
    assert fine.vertex_count > coarse.vertex_count
    assert fine.triangle_count > coarse.triangle_count


# ------------------------------------------------------------------
# Cylinder
# ------------------------------------------------------------------
def test_generate_cylinder_is_valid():
    mesh = generate_cylinder()
    assert mesh.is_valid()


def test_generate_cylinder_height_matches_bounds():
    mesh = generate_cylinder(radius=1.0, height=4.0, segments=16)
    y_values = mesh.positions[:, 1]
    assert np.isclose(y_values.max(), 2.0, atol=1e-5)
    assert np.isclose(y_values.min(), -2.0, atol=1e-5)


def test_generate_cylinder_side_vertices_within_radius():
    mesh = generate_cylinder(radius=2.0, height=2.0, segments=16)
    radial_distance = np.linalg.norm(mesh.positions[:, [0, 2]], axis=1)
    assert np.all(radial_distance <= 2.0 + 1e-4)


def test_generate_cylinder_not_degenerate_with_minimum_segments():
    mesh = generate_cylinder(segments=3)
    assert mesh.is_valid()
    assert mesh.triangle_count > 0


def test_generate_cylinder_has_top_and_bottom_caps():
    mesh = generate_cylinder(radius=1.0, height=2.0, segments=8)
    # Cap center vertices should include a normal pointing straight up
    # and one pointing straight down.
    assert np.any(np.all(np.isclose(mesh.normals, [0.0, 1.0, 0.0]), axis=1))
    assert np.any(np.all(np.isclose(mesh.normals, [0.0, -1.0, 0.0]), axis=1))


# ------------------------------------------------------------------
# Registry / dispatch
# ------------------------------------------------------------------
def test_all_primitive_types_registered():
    assert set(PRIMITIVE_GENERATORS.keys()) == {"cube", "sphere", "cylinder", "plane"}


@pytest.mark.parametrize("name", ["cube", "sphere", "cylinder", "plane"])
def test_generate_primitive_by_name_is_valid(name):
    mesh = generate_primitive(name)
    assert mesh.is_valid()


def test_generate_primitive_unknown_name_raises():
    with pytest.raises(ValueError):
        generate_primitive("torus")


def test_no_primitive_produces_degenerate_geometry():
    for name in PRIMITIVE_GENERATORS:
        mesh = generate_primitive(name)
        assert mesh.vertex_count > 0
        assert mesh.index_count > 0
        assert mesh.index_count % 3 == 0


# ------------------------------------------------------------------
# UV coordinates (Phase 3)
# ------------------------------------------------------------------
@pytest.mark.parametrize("name", ["cube", "sphere", "cylinder", "plane"])
def test_all_primitives_have_uvs(name):
    mesh = generate_primitive(name)
    assert mesh.has_uvs
    assert mesh.uvs.shape == (mesh.vertex_count, 2)


@pytest.mark.parametrize("name", ["cube", "sphere", "cylinder", "plane"])
def test_primitive_uvs_are_within_reasonable_range(name):
    mesh = generate_primitive(name)
    # UVs should be within [0, 1] (a couple of primitives use a
    # centered projection that can dip slightly negative/over 1 at
    # extremes -- allow a small margin rather than a hard [0,1] clamp).
    assert mesh.uvs.min() >= -0.01
    assert mesh.uvs.max() <= 1.01


def test_mesh_without_uvs_still_valid_and_has_uvs_false():
    mesh = generate_cube()
    mesh_no_uv = type(mesh)(positions=mesh.positions, normals=mesh.normals, indices=mesh.indices)
    assert mesh_no_uv.has_uvs is False
    assert mesh_no_uv.is_valid() is True


def test_mesh_interleaved_without_uvs_has_6_columns():
    mesh = generate_cube()
    mesh_no_uv = type(mesh)(positions=mesh.positions, normals=mesh.normals, indices=mesh.indices)
    assert mesh_no_uv.interleaved().shape[1] == 6


def test_mesh_interleaved_with_uvs_has_8_columns():
    mesh = generate_cube()
    assert mesh.interleaved().shape[1] == 8


def test_plane_uv_corners_match_positions():
    mesh = generate_plane(segments=1)
    # 4 corners in the order generated: (-x,-z), (+x,-z), (-x,+z), (+x,+z)
    assert np.allclose(mesh.uvs[0], [0.0, 0.0])
    assert np.allclose(mesh.uvs[1], [1.0, 0.0])
    assert np.allclose(mesh.uvs[2], [0.0, 1.0])
    assert np.allclose(mesh.uvs[3], [1.0, 1.0])
