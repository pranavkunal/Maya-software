import math

import numpy as np

from graphics import gizmo_math, math3d


# ------------------------------------------------------------------
# math3d additions used by the gizmo
# ------------------------------------------------------------------
def test_orthographic_matrix_shape_and_finite():
    m = math3d.orthographic_matrix(-5, 5, -5, 5, 0.1, 100.0)
    assert m.shape == (4, 4)
    assert np.all(np.isfinite(m))


def test_orthographic_matrix_maps_center_to_origin_xy():
    m = math3d.orthographic_matrix(-5, 5, -5, 5, 0.1, 100.0)
    p = math3d.transform_point(m, (0.0, 0.0, -50.0))
    assert math.isclose(p[0], 0.0, abs_tol=1e-5)
    assert math.isclose(p[1], 0.0, abs_tol=1e-5)


def test_orthographic_matrix_does_not_shrink_with_depth():
    """The defining feature of orthographic vs perspective: an object's
    apparent size must not depend on distance from the camera."""
    m = math3d.orthographic_matrix(-5, 5, -5, 5, 0.1, 100.0)
    near_point = math3d.transform_point(m, (5.0, 0.0, -1.0))
    far_point = math3d.transform_point(m, (5.0, 0.0, -90.0))
    assert math.isclose(near_point[0], far_point[0], abs_tol=1e-5)


def test_orthographic_matrix_from_height_matches_manual_bounds():
    m1 = math3d.orthographic_matrix_from_height(10.0, 2.0, 0.1, 100.0)
    m2 = math3d.orthographic_matrix(-10.0, 10.0, -5.0, 5.0, 0.1, 100.0)
    assert np.allclose(m1, m2, atol=1e-5)


def test_closest_point_on_line_to_ray_perpendicular_case():
    # Line along X axis through origin; ray coming straight down the Y
    # axis, crossing the line at x=3.
    line_point = np.array([0.0, 0.0, 0.0])
    line_dir = np.array([1.0, 0.0, 0.0])
    ray_origin = np.array([3.0, 5.0, 0.0])
    ray_dir = np.array([0.0, -1.0, 0.0])
    closest = math3d.closest_point_on_line_to_ray(line_point, line_dir, ray_origin, ray_dir)
    assert np.allclose(closest, [3.0, 0.0, 0.0], atol=1e-5)


def test_angle_around_axis_quarter_turn():
    center = np.array([0.0, 0.0, 0.0])
    axis = np.array([0.0, 0.0, 1.0])
    reference = np.array([1.0, 0.0, 0.0])
    point = np.array([0.0, 1.0, 0.0])
    angle = math3d.angle_around_axis(point, center, axis, reference)
    assert math.isclose(angle, 90.0, abs_tol=1e-3)


def test_angle_around_axis_zero_at_reference():
    center = np.array([0.0, 0.0, 0.0])
    axis = np.array([0.0, 0.0, 1.0])
    reference = np.array([1.0, 0.0, 0.0])
    angle = math3d.angle_around_axis(reference, center, axis, reference)
    assert math.isclose(angle, 0.0, abs_tol=1e-3)


# ------------------------------------------------------------------
# gizmo_math
# ------------------------------------------------------------------
def _straight_down_ray(x, z, y_start=10.0):
    return np.array([x, y_start, z], dtype=np.float32), np.array([0.0, -1.0, 0.0], dtype=np.float32)


def test_pick_move_axis_hits_x_handle():
    center = np.array([0.0, 0.0, 0.0])
    origin, direction = _straight_down_ray(1.0, 0.0)
    result = gizmo_math.pick_move_or_scale_axis(center, handle_length=2.0, ray_origin=origin, ray_direction=direction)
    assert result is not None
    assert result.axis == "X"


def test_pick_move_axis_misses_when_far_from_all_axes():
    center = np.array([0.0, 0.0, 0.0])
    origin, direction = _straight_down_ray(5.0, 5.0)
    result = gizmo_math.pick_move_or_scale_axis(center, handle_length=2.0, ray_origin=origin, ray_direction=direction)
    assert result is None


def test_pick_move_axis_respects_handle_length():
    center = np.array([0.0, 0.0, 0.0])
    # Ray crosses the X axis line beyond the handle's length -> no hit.
    origin, direction = _straight_down_ray(10.0, 0.0)
    result = gizmo_math.pick_move_or_scale_axis(center, handle_length=2.0, ray_origin=origin, ray_direction=direction)
    assert result is None


def test_pick_rotation_ring_hits_z_ring():
    center = np.array([0.0, 0.0, 0.0])
    # Ray traveling down the Z axis lands on the Z=0 plane (the Z-axis
    # ring's plane) at radial distance 2 from center.
    origin = np.array([2.0, 0.0, 10.0], dtype=np.float32)
    direction = np.array([0.0, 0.0, -1.0], dtype=np.float32)
    axis = gizmo_math.pick_rotation_ring(center, ring_radius=2.0, ray_origin=origin, ray_direction=direction)
    assert axis == "Z"


def test_pick_rotation_ring_hits_y_ring():
    center = np.array([0.0, 0.0, 0.0])
    # Ray traveling down the Y axis lands on the Y=0 plane (the Y-axis
    # ring's plane) at radial distance 2 from center.
    origin, direction = _straight_down_ray(2.0, 0.0)
    axis = gizmo_math.pick_rotation_ring(center, ring_radius=2.0, ray_origin=origin, ray_direction=direction)
    assert axis == "Y"


def test_pick_rotation_ring_misses_wrong_radius():
    center = np.array([0.0, 0.0, 0.0])
    origin = np.array([2.0, 10.0, 0.0], dtype=np.float32)
    direction = np.array([0.0, -1.0, 0.0], dtype=np.float32)
    axis = gizmo_math.pick_rotation_ring(center, ring_radius=10.0, ray_origin=origin, ray_direction=direction)
    assert axis is None


def test_ray_hits_uniform_scale_handle_true_when_centered():
    center = np.array([0.0, 0.0, 0.0])
    origin, direction = _straight_down_ray(0.0, 0.0)
    assert gizmo_math.ray_hits_uniform_scale_handle(center, 0.3, origin, direction) is True


def test_ray_hits_uniform_scale_handle_false_when_offset():
    center = np.array([0.0, 0.0, 0.0])
    origin, direction = _straight_down_ray(5.0, 5.0)
    assert gizmo_math.ray_hits_uniform_scale_handle(center, 0.3, origin, direction) is False


def test_move_delta_along_axis_positive_direction():
    center = np.array([0.0, 0.0, 0.0])
    start_ray = _straight_down_ray(1.0, 0.0)
    current_ray = _straight_down_ray(4.0, 0.0)
    delta = gizmo_math.move_delta_along_axis(center, "X", start_ray, current_ray)
    assert math.isclose(delta, 3.0, abs_tol=1e-4)


def test_move_delta_along_axis_zero_when_ray_unchanged():
    center = np.array([0.0, 0.0, 0.0])
    ray = _straight_down_ray(1.0, 0.0)
    delta = gizmo_math.move_delta_along_axis(center, "Y", ray, ray)
    assert math.isclose(delta, 0.0, abs_tol=1e-6)


def test_rotation_delta_degrees_quarter_turn():
    center = np.array([0.0, 0.0, 0.0])
    reference = np.array([1.0, 0.0, 0.0])
    # Start ray hits the XY plane at (1,0,0); current ray hits at (0,1,0):
    # a 90-degree rotation around Z.
    start_ray = (np.array([1.0, 0.0, 10.0], dtype=np.float32), np.array([0.0, 0.0, -1.0], dtype=np.float32))
    current_ray = (np.array([0.0, 1.0, 10.0], dtype=np.float32), np.array([0.0, 0.0, -1.0], dtype=np.float32))
    delta = gizmo_math.rotation_delta_degrees(center, "Z", start_ray, current_ray, reference)
    assert math.isclose(delta, 90.0, abs_tol=1e-2)


def test_rotation_delta_degrees_zero_when_ray_unchanged():
    center = np.array([0.0, 0.0, 0.0])
    reference = np.array([1.0, 0.0, 0.0])
    ray = (np.array([1.0, 0.0, 10.0], dtype=np.float32), np.array([0.0, 0.0, -1.0], dtype=np.float32))
    delta = gizmo_math.rotation_delta_degrees(center, "Z", ray, ray, reference)
    assert math.isclose(delta, 0.0, abs_tol=1e-6)
