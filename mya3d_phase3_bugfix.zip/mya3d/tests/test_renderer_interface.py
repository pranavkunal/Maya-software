"""Regression tests for the default-framebuffer handling bug.

Root cause (see graphics/opengl_renderer.py render() docstring):
QOpenGLWidget renders into its own internally-managed FBO, not system
framebuffer 0. Code that hardcodes ``glBindFramebuffer(GL_FRAMEBUFFER, 0)``
to "return to the default" breaks on a real Qt context. The fix makes
every renderer entry point that needs to restore the host's real
default framebuffer accept an explicit ``default_framebuffer`` id
instead of assuming 0.

These tests can't create a real GL context (no GPU in this
environment), so they can't reproduce the GL_INVALID_ENUM directly.
What they *can* verify without a GPU is the contract that prevents the
regression: the renderer's public entry points must accept and default
``default_framebuffer=0`` (so existing/non-Qt callers keep working),
and must never contain a hardcoded ``glBindFramebuffer(GL_FRAMEBUFFER, 0)``
call in source, which is exactly the class of bug that caused this.
"""
import inspect
import re
from pathlib import Path

from graphics.renderer_interface import NullRenderer, RendererInterface

try:
    from graphics.opengl_renderer import OpenGLRenderer
    _HAS_RENDERER_MODULE = True
except ImportError:  # pragma: no cover - PyOpenGL not installed
    _HAS_RENDERER_MODULE = False


def test_renderer_interface_render_accepts_default_framebuffer():
    sig = inspect.signature(RendererInterface.render)
    assert "default_framebuffer" in sig.parameters
    assert sig.parameters["default_framebuffer"].default == 0


def test_renderer_interface_resize_accepts_default_framebuffer():
    sig = inspect.signature(RendererInterface.resize)
    assert "default_framebuffer" in sig.parameters
    assert sig.parameters["default_framebuffer"].default == 0


def test_null_renderer_render_accepts_default_framebuffer():
    renderer = NullRenderer()
    # Must not raise TypeError for the extra positional/keyword arg.
    renderer.render(None, None, default_framebuffer=1234)
    renderer.render(None, None)


def test_null_renderer_resize_accepts_default_framebuffer():
    renderer = NullRenderer()
    renderer.resize(800, 600, default_framebuffer=1234)
    renderer.resize(800, 600)


def test_opengl_renderer_render_signature_has_default_framebuffer():
    if not _HAS_RENDERER_MODULE:
        return
    sig = inspect.signature(OpenGLRenderer.render)
    assert "default_framebuffer" in sig.parameters
    assert sig.parameters["default_framebuffer"].default == 0


def test_opengl_renderer_resize_signature_has_default_framebuffer():
    if not _HAS_RENDERER_MODULE:
        return
    sig = inspect.signature(OpenGLRenderer.resize)
    assert "default_framebuffer" in sig.parameters
    assert sig.parameters["default_framebuffer"].default == 0


def test_opengl_renderer_pick_signature_has_default_framebuffer():
    if not _HAS_RENDERER_MODULE:
        return
    sig = inspect.signature(OpenGLRenderer.pick)
    assert "default_framebuffer" in sig.parameters
    assert sig.parameters["default_framebuffer"].default == 0


def test_opengl_renderer_source_never_hardcodes_default_framebuffer_zero():
    """The actual regression guard: statically scan the renderer source
    for the exact pattern that caused the crash. A hardcoded literal
    ``0`` as the second argument to glBindFramebuffer(GL_FRAMEBUFFER, ...)
    must never reappear -- every restore-to-default call must use the
    ``default_framebuffer`` variable instead.
    """
    source_path = Path(__file__).resolve().parent.parent / "graphics" / "opengl_renderer.py"
    source = source_path.read_text(encoding="utf-8")

    hardcoded_pattern = re.compile(r"glBindFramebuffer\(\s*gl\.GL_FRAMEBUFFER\s*,\s*0\s*\)")
    matches = hardcoded_pattern.findall(source)
    assert not matches, (
        "Found a hardcoded glBindFramebuffer(GL_FRAMEBUFFER, 0) call -- "
        "this is the exact bug that caused GL_INVALID_ENUM on real Qt "
        "QOpenGLWidget contexts. Use the default_framebuffer parameter "
        "instead of the literal 0."
    )
