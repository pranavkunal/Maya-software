import pytest

from graphics.texture import SUPPORTED_EXTENSIONS, TextureData, TextureLoadError, _flip_rows

PIL = pytest.importorskip("PIL", reason="Pillow not installed")
from PIL import Image  # noqa: E402


def _make_test_png(path, width=4, height=2, color=(255, 0, 0, 255)):
    img = Image.new("RGBA", (width, height), color)
    img.save(path, format="PNG")


def test_load_png_returns_correct_dimensions(tmp_path):
    path = tmp_path / "test.png"
    _make_test_png(path, width=8, height=4)
    tex = TextureData.load(path)
    assert tex.width == 8
    assert tex.height == 4
    assert tex.is_valid()


def test_load_png_pixel_byte_count_matches_dimensions(tmp_path):
    path = tmp_path / "test.png"
    _make_test_png(path, width=3, height=5)
    tex = TextureData.load(path)
    assert len(tex.pixels) == 3 * 5 * 4  # RGBA8


def test_load_jpeg(tmp_path):
    path = tmp_path / "test.jpg"
    img = Image.new("RGB", (6, 6), (0, 255, 0))
    img.save(path, format="JPEG")
    tex = TextureData.load(path)
    assert tex.width == 6
    assert tex.height == 6
    assert tex.is_valid()


def test_load_converts_rgb_to_rgba(tmp_path):
    path = tmp_path / "rgb.png"
    img = Image.new("RGB", (2, 2), (10, 20, 30))
    img.save(path, format="PNG")
    tex = TextureData.load(path)
    # 2x2 RGBA image = 16 bytes
    assert len(tex.pixels) == 16


def test_load_missing_file_raises(tmp_path):
    with pytest.raises(TextureLoadError):
        TextureData.load(tmp_path / "does_not_exist.png")


def test_load_invalid_image_data_raises(tmp_path):
    path = tmp_path / "not_an_image.png"
    path.write_bytes(b"this is not a valid PNG file at all")
    with pytest.raises(TextureLoadError):
        TextureData.load(path)


def test_texture_data_is_valid_false_for_mismatched_size():
    tex = TextureData(width=4, height=4, pixels=b"\x00" * 4)  # too short
    assert tex.is_valid() is False


def test_texture_data_is_valid_true_for_matching_size():
    tex = TextureData(width=2, height=2, pixels=b"\x00" * (2 * 2 * 4))
    assert tex.is_valid() is True


def test_supported_extensions_include_png_and_jpg():
    assert ".png" in SUPPORTED_EXTENSIONS
    assert ".jpg" in SUPPORTED_EXTENSIONS
    assert ".jpeg" in SUPPORTED_EXTENSIONS


def test_flip_rows_reverses_row_order():
    # 2x2 image, 1 channel for simplicity: rows [A, B] -> [B, A]
    pixels = b"AA" + b"BB"
    flipped = _flip_rows(pixels, width=2, height=2, channels=1)
    assert flipped == b"BB" + b"AA"


def test_flip_rows_single_row_unchanged():
    pixels = b"ABCD"
    flipped = _flip_rows(pixels, width=4, height=1, channels=1)
    assert flipped == pixels
