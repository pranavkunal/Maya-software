from core.object_types import SceneObjectType
from core.scene import Scene
from core.transform import Transform, Vector3
from editor.commands import (
    CommandStack,
    CreateObjectCommand,
    DeleteObjectCommand,
    DuplicateObjectCommand,
    RenameObjectCommand,
    TransformObjectCommand,
)


def test_create_object_command_adds_to_scene():
    scene = Scene()
    stack = CommandStack()
    cmd = CreateObjectCommand(scene, "Cube", SceneObjectType.MESH)
    stack.execute(cmd)

    assert len(scene) == 1
    assert cmd.created_object is not None
    assert cmd.created_object.id in scene


def test_create_object_command_undo_redo():
    scene = Scene()
    stack = CommandStack()
    cmd = CreateObjectCommand(scene, "Cube", SceneObjectType.MESH)
    stack.execute(cmd)
    object_id = cmd.created_object.id

    assert stack.undo() is True
    assert object_id not in scene

    assert stack.redo() is True
    assert object_id in scene


def test_delete_object_command_undo_restores_object():
    scene = Scene.create_default()
    camera = next(o for o in scene.all_objects() if o.name == "Camera")
    stack = CommandStack()

    stack.execute(DeleteObjectCommand(scene, camera.id))
    assert camera.id not in scene

    stack.undo()
    assert camera.id in scene
    assert scene.get_object(camera.id).name == "Camera"


def test_rename_object_command_undo_redo():
    scene = Scene()
    stack = CommandStack()
    create_cmd = CreateObjectCommand(scene, "Cube", SceneObjectType.MESH)
    stack.execute(create_cmd)
    object_id = create_cmd.created_object.id

    stack.execute(RenameObjectCommand(scene, object_id, "MyCube"))
    assert scene.get_object(object_id).name == "MyCube"

    stack.undo()
    assert scene.get_object(object_id).name == "Cube"

    stack.redo()
    assert scene.get_object(object_id).name == "MyCube"


def test_transform_object_command_undo_redo():
    scene = Scene()
    stack = CommandStack()
    create_cmd = CreateObjectCommand(scene, "Cube", SceneObjectType.MESH)
    stack.execute(create_cmd)
    object_id = create_cmd.created_object.id

    new_transform = Transform(position=Vector3(5, 0, 0))
    stack.execute(TransformObjectCommand(scene, object_id, new_transform))
    assert scene.get_object(object_id).transform.position.x == 5.0

    stack.undo()
    assert scene.get_object(object_id).transform.position.x == 0.0

    stack.redo()
    assert scene.get_object(object_id).transform.position.x == 5.0


def test_command_stack_clears_redo_on_new_execute():
    scene = Scene()
    stack = CommandStack()
    cmd1 = CreateObjectCommand(scene, "Cube", SceneObjectType.MESH)
    stack.execute(cmd1)
    stack.undo()
    assert stack.can_redo() is True

    cmd2 = CreateObjectCommand(scene, "Sphere", SceneObjectType.MESH)
    stack.execute(cmd2)
    assert stack.can_redo() is False


def test_command_stack_can_undo_can_redo_flags():
    scene = Scene()
    stack = CommandStack()
    assert stack.can_undo() is False
    assert stack.can_redo() is False

    stack.execute(CreateObjectCommand(scene, "Cube", SceneObjectType.MESH))
    assert stack.can_undo() is True
    assert stack.can_redo() is False

    stack.undo()
    assert stack.can_undo() is False
    assert stack.can_redo() is True


def test_duplicate_object_command_creates_independent_transform():
    scene = Scene()
    stack = CommandStack()
    create_cmd = CreateObjectCommand(scene, "Sphere", SceneObjectType.MESH)
    stack.execute(create_cmd)
    original_id = create_cmd.created_object.id

    dup_cmd = DuplicateObjectCommand(scene, original_id)
    stack.execute(dup_cmd)
    duplicate = dup_cmd.duplicate_object

    assert duplicate.id != original_id
    assert duplicate.name == "Sphere1"
    duplicate.transform.position.x = 10.0
    assert scene.get_object(original_id).transform.position.x == 0.0


def test_duplicate_object_command_undo_redo():
    scene = Scene()
    stack = CommandStack()
    create_cmd = CreateObjectCommand(scene, "Sphere", SceneObjectType.MESH)
    stack.execute(create_cmd)
    original_id = create_cmd.created_object.id

    dup_cmd = DuplicateObjectCommand(scene, original_id)
    stack.execute(dup_cmd)
    duplicate_id = dup_cmd.duplicate_object.id
    assert len(scene) == 2

    stack.undo()
    assert duplicate_id not in scene
    assert len(scene) == 1

    stack.redo()
    assert duplicate_id in scene
    assert len(scene) == 2
