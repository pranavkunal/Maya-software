import pytest

from core.object_types import SceneObjectType
from core.scene import Scene, SceneError
from core.scene_object import SceneObject


def test_create_default_scene_has_camera_and_light():
    scene = Scene.create_default()
    names = {obj.name for obj in scene.all_objects()}
    assert names == {"Camera", "Light"}
    assert len(scene) == 2


def test_add_object_as_root():
    scene = Scene()
    obj = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(obj)
    assert obj.id in scene
    assert obj.id in scene.root_ids()


def test_add_object_with_parent():
    scene = Scene()
    parent = SceneObject(name="Group", type=SceneObjectType.GROUP)
    scene.add_object(parent)
    child = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(child, parent_id=parent.id)

    assert child.parent_id == parent.id
    assert child.id in parent.children_ids
    assert child.id not in scene.root_ids()


def test_add_object_duplicate_id_raises():
    scene = Scene()
    obj = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(obj)
    with pytest.raises(SceneError):
        scene.add_object(obj)


def test_object_ids_are_unique():
    scene = Scene()
    obj1 = SceneObject(name="Cube", type=SceneObjectType.MESH)
    obj2 = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(obj1)
    scene.add_object(obj2)
    assert obj1.id != obj2.id


def test_remove_object():
    scene = Scene.create_default()
    camera = next(o for o in scene.all_objects() if o.name == "Camera")
    scene.remove_object(camera.id)
    assert camera.id not in scene
    assert len(scene) == 1


def test_remove_object_removes_children_recursively():
    scene = Scene()
    parent = SceneObject(name="Group", type=SceneObjectType.GROUP)
    scene.add_object(parent)
    child = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(child, parent_id=parent.id)

    scene.remove_object(parent.id)

    assert parent.id not in scene
    assert child.id not in scene


def test_remove_unknown_object_raises():
    scene = Scene()
    with pytest.raises(SceneError):
        scene.remove_object("does-not-exist")


def test_rename_object():
    scene = Scene()
    obj = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(obj)
    scene.rename_object(obj.id, "MyCube")
    assert scene.get_object(obj.id).name == "MyCube"


def test_duplicate_object_gets_new_id_and_unique_name():
    scene = Scene()
    original = SceneObject(name="Sphere", type=SceneObjectType.MESH)
    scene.add_object(original)

    duplicate = scene.duplicate_object(original.id)

    assert duplicate.id != original.id
    assert duplicate.name != original.name
    assert duplicate.name == "Sphere1"
    assert len(scene) == 2


def test_duplicate_object_does_not_share_transform():
    scene = Scene()
    original = SceneObject(name="Sphere", type=SceneObjectType.MESH)
    scene.add_object(original)

    duplicate = scene.duplicate_object(original.id)
    duplicate.transform.position.x = 42.0

    assert original.transform.position.x == 0.0
    assert duplicate.transform is not original.transform


def test_duplicate_multiple_times_produces_unique_names():
    scene = Scene()
    original = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(original)

    dup1 = scene.duplicate_object(original.id)
    dup2 = scene.duplicate_object(original.id)

    names = {o.name for o in scene.all_objects()}
    assert len(names) == 3
    assert dup1.name != dup2.name


def test_scene_signals_fire_on_add_and_remove():
    scene = Scene()
    added = []
    removed = []
    scene.object_added.connect(lambda obj: added.append(obj.id))
    scene.object_removed.connect(lambda oid: removed.append(oid))

    obj = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(obj)
    scene.remove_object(obj.id)

    assert added == [obj.id]
    assert removed == [obj.id]


def test_clear_resets_scene():
    scene = Scene.create_default()
    scene.clear()
    assert len(scene) == 0
    assert scene.root_ids() == []


# ------------------------------------------------------------------
# Phase 2: mesh SceneObjects reference a primitive by name via
# metadata -- the core scene model stays framework/GPU independent
# (no raw OpenGL objects ever live on SceneObject).
# ------------------------------------------------------------------
def test_mesh_object_stores_primitive_reference_in_metadata():
    scene = Scene()
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    scene.add_object(cube)

    stored = scene.get_object(cube.id)
    assert stored.type == SceneObjectType.MESH
    assert stored.metadata["primitive"] == "cube"


def test_multiple_mesh_objects_at_different_transforms_are_independent():
    scene = Scene()
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    cube.transform.position.x = 0.0
    sphere = SceneObject(name="Sphere", type=SceneObjectType.MESH, metadata={"primitive": "sphere"})
    sphere.transform.position.x = 3.0
    cylinder = SceneObject(name="Cylinder", type=SceneObjectType.MESH, metadata={"primitive": "cylinder"})
    cylinder.transform.position.x = -3.0

    scene.add_object(cube)
    scene.add_object(sphere)
    scene.add_object(cylinder)

    assert len(scene) == 3
    assert scene.get_object(cube.id).transform.position.x == 0.0
    assert scene.get_object(sphere.id).transform.position.x == 3.0
    assert scene.get_object(cylinder.id).transform.position.x == -3.0


def test_duplicate_mesh_object_preserves_primitive_and_gets_independent_transform():
    scene = Scene()
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    scene.add_object(cube)

    duplicate = scene.duplicate_object(cube.id)

    assert duplicate.id != cube.id
    assert duplicate.metadata.get("primitive") == "cube"
    duplicate.transform.position.x = 5.0
    assert scene.get_object(cube.id).transform.position.x == 0.0
