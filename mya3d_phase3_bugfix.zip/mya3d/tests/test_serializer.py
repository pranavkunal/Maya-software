import json

import pytest

from core.object_types import SceneObjectType
from core.scene import Scene
from core.scene_object import SceneObject
from core.transform import Vector3
from sceneio.scene_serializer import (
    SceneSerializationError,
    load_scene,
    save_scene,
    scene_from_dict,
    scene_to_dict,
)


def test_save_and_load_roundtrip(tmp_path):
    scene = Scene.create_default("MyScene")
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH)
    cube.transform.position = Vector3(1, 2, 3)
    scene.add_object(cube)

    path = tmp_path / "test_scene.mya"
    save_scene(scene, path)
    assert path.exists()

    loaded = load_scene(path)
    names = {o.name for o in loaded.all_objects()}
    assert names == {"Camera", "Light", "Cube"}

    loaded_cube = next(o for o in loaded.all_objects() if o.name == "Cube")
    assert loaded_cube.transform.position.as_tuple() == (1.0, 2.0, 3.0)


def test_save_and_load_preserves_hierarchy(tmp_path):
    scene = Scene()
    group = SceneObject(name="Group", type=SceneObjectType.GROUP)
    scene.add_object(group)
    child = SceneObject(name="Cube", type=SceneObjectType.MESH)
    scene.add_object(child, parent_id=group.id)

    path = tmp_path / "hierarchy.mya"
    save_scene(scene, path)
    loaded = load_scene(path)

    loaded_group = next(o for o in loaded.all_objects() if o.name == "Group")
    loaded_child = next(o for o in loaded.all_objects() if o.name == "Cube")
    assert loaded_child.parent_id == loaded_group.id
    assert loaded_child.id in loaded_group.children_ids


def test_load_missing_file_raises(tmp_path):
    missing_path = tmp_path / "does_not_exist.mya"
    with pytest.raises(SceneSerializationError):
        load_scene(missing_path)


def test_load_invalid_json_raises(tmp_path):
    path = tmp_path / "bad.mya"
    path.write_text("{not valid json", encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_load_missing_version_raises(tmp_path):
    path = tmp_path / "no_version.mya"
    path.write_text(json.dumps({"objects": []}), encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_load_unsupported_version_raises(tmp_path):
    path = tmp_path / "future.mya"
    path.write_text(json.dumps({"version": 999, "objects": [], "root_ids": []}), encoding="utf-8")
    with pytest.raises(SceneSerializationError):
        load_scene(path)


def test_scene_to_dict_from_dict_roundtrip_in_memory():
    scene = Scene.create_default()
    data = scene_to_dict(scene)
    restored = scene_from_dict(data)
    assert len(restored) == len(scene)
    assert {o.name for o in restored.all_objects()} == {o.name for o in scene.all_objects()}


# ------------------------------------------------------------------
# Phase 2: mesh primitive metadata must round-trip through .mya files.
# The serializer stores GPU-agnostic logical data only (metadata dict
# with a "primitive" string) -- never raw GPU buffers or OpenGL state.
# ------------------------------------------------------------------
def test_mesh_primitive_metadata_roundtrips_in_memory():
    scene = Scene()
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    scene.add_object(cube)

    data = scene_to_dict(scene)
    restored = scene_from_dict(data)

    restored_cube = restored.get_object(cube.id)
    assert restored_cube is not None
    assert restored_cube.type == SceneObjectType.MESH
    assert restored_cube.metadata.get("primitive") == "cube"


@pytest.mark.parametrize("primitive", ["cube", "sphere", "cylinder", "plane"])
def test_each_primitive_type_roundtrips_through_mya_file(tmp_path, primitive):
    scene = Scene()
    obj = SceneObject(
        name=primitive.capitalize(),
        type=SceneObjectType.MESH,
        metadata={"primitive": primitive},
    )
    obj.transform.position = Vector3(1.0, 2.0, 3.0)
    scene.add_object(obj)

    path = tmp_path / f"{primitive}.mya"
    save_scene(scene, path)
    loaded = load_scene(path)

    loaded_obj = next(o for o in loaded.all_objects() if o.name == primitive.capitalize())
    assert loaded_obj.metadata.get("primitive") == primitive
    assert loaded_obj.transform.position.as_tuple() == (1.0, 2.0, 3.0)


def test_phase1_style_scene_file_without_mesh_objects_still_loads(tmp_path):
    """A .mya file containing only Camera/Light (no mesh metadata at
    all, as any Phase 1 file would look) must still load correctly in
    Phase 2 -- backward compatibility for existing scene files.
    """
    scene = Scene.create_default("Phase1Scene")
    path = tmp_path / "phase1_style.mya"
    save_scene(scene, path)

    loaded = load_scene(path)
    names = {o.name for o in loaded.all_objects()}
    assert names == {"Camera", "Light"}
    for obj in loaded.all_objects():
        assert obj.metadata == {}


# ------------------------------------------------------------------
# Phase 3: version-1 files (from Phase 1/2) must still load, and
# animation data round-trips through the *_with_animation variants
# without affecting the plain Scene-only functions' behavior/format.
# ------------------------------------------------------------------
def test_version_1_scene_file_still_loads(tmp_path):
    path = tmp_path / "v1.mya"
    data = {
        "version": 1,
        "name": "OldScene",
        "root_ids": [],
        "objects": [],
    }
    path.write_text(json.dumps(data), encoding="utf-8")
    loaded = load_scene(path)
    assert loaded.name == "OldScene"


def test_current_saves_use_version_2():
    from sceneio.scene_serializer import SCENE_FORMAT_VERSION
    scene = Scene.create_default()
    data = scene_to_dict(scene)
    assert data["version"] == SCENE_FORMAT_VERSION
    assert SCENE_FORMAT_VERSION == 2


def test_save_and_load_with_animation_roundtrip(tmp_path):
    from core.animation import AnimationClip
    from sceneio.scene_serializer import load_scene_with_animation, save_scene_with_animation

    scene = Scene()
    cube = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    scene.add_object(cube)

    clip = AnimationClip()
    clip.get_or_create_track(cube.id).insert_keyframe(1, cube.transform.copy())
    moved = cube.transform.copy()
    moved.position = Vector3(5, 0, 0)
    clip.get_or_create_track(cube.id).insert_keyframe(30, moved)

    path = tmp_path / "animated.mya"
    save_scene_with_animation(scene, clip, path)
    loaded_scene, loaded_clip = load_scene_with_animation(path)

    loaded_cube = next(o for o in loaded_scene.all_objects() if o.name == "Cube")
    track = loaded_clip.get_track(loaded_cube.id)
    assert track is not None
    assert track.frames() == [1, 30]
    assert track.evaluate(30).position.as_tuple() == (5.0, 0.0, 0.0)


def test_load_with_animation_on_file_without_animations_key_is_empty(tmp_path):
    from sceneio.scene_serializer import load_scene_with_animation

    scene = Scene.create_default()
    path = tmp_path / "no_animation.mya"
    save_scene(scene, path)  # plain save_scene never writes "animations"

    loaded_scene, loaded_clip = load_scene_with_animation(path)
    assert loaded_clip.animated_object_ids() == []


def test_plain_save_scene_never_includes_animations_key(tmp_path):
    scene = Scene.create_default()
    path = tmp_path / "plain.mya"
    save_scene(scene, path)
    raw = json.loads(path.read_text(encoding="utf-8"))
    assert "animations" not in raw
