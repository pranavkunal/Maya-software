import numpy as np

from graphics.gizmo import build_move_gizmo_lines, build_rotate_gizmo_lines, build_scale_gizmo_lines


def test_move_gizmo_lines_shape():
    lines = build_move_gizmo_lines((0.0, 0.0, 0.0), handle_length=2.0)
    assert lines.shape[1] == 6  # pos.xyz + color.rgb
    assert lines.shape[0] % 2 == 0  # GL_LINES needs pairs of vertices


def test_move_gizmo_lines_start_at_center():
    center = (1.0, 2.0, 3.0)
    lines = build_move_gizmo_lines(center, handle_length=2.0)
    # The first vertex of each axis's main line starts at the gizmo center.
    assert np.allclose(lines[0, :3], center)


def test_move_gizmo_active_axis_uses_highlight_color():
    lines_plain = build_move_gizmo_lines((0, 0, 0), handle_length=2.0)
    lines_highlighted = build_move_gizmo_lines((0, 0, 0), handle_length=2.0, active_axis="Y")
    assert not np.allclose(lines_plain, lines_highlighted)


def test_scale_gizmo_lines_shape():
    lines = build_scale_gizmo_lines((0.0, 0.0, 0.0), handle_length=2.0)
    assert lines.shape[1] == 6
    assert lines.shape[0] % 2 == 0
    assert lines.shape[0] > 0


def test_scale_gizmo_includes_uniform_handle_near_center():
    lines = build_scale_gizmo_lines((5.0, 0.0, 0.0), handle_length=2.0)
    # At least some vertices should be close to the center (the uniform handle cross).
    distances = np.linalg.norm(lines[:, :3] - np.array([5.0, 0.0, 0.0]), axis=1)
    assert distances.min() < 0.5


def test_rotate_gizmo_lines_shape():
    lines = build_rotate_gizmo_lines((0.0, 0.0, 0.0), radius=2.0, segments=16)
    assert lines.shape[1] == 6
    assert lines.shape[0] % 2 == 0
    # 3 rings * 16 segments * 2 vertices each
    assert lines.shape[0] == 3 * 16 * 2


def test_rotate_gizmo_vertices_lie_on_radius():
    center = np.array([0.0, 0.0, 0.0])
    lines = build_rotate_gizmo_lines((0.0, 0.0, 0.0), radius=3.0, segments=32)
    distances = np.linalg.norm(lines[:, :3] - center, axis=1)
    assert np.allclose(distances, 3.0, atol=1e-3)


def test_rotate_gizmo_active_axis_uses_highlight_color():
    lines_plain = build_rotate_gizmo_lines((0, 0, 0), radius=2.0, segments=8)
    lines_highlighted = build_rotate_gizmo_lines((0, 0, 0), radius=2.0, segments=8, active_axis="X")
    assert not np.allclose(lines_plain, lines_highlighted)
