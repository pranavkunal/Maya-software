from editor.selection import SelectionManager


def test_initial_selection_is_empty():
    sel = SelectionManager()
    assert sel.selected_ids() == []
    assert sel.primary_selected_id() is None
    assert not sel.has_selection()


def test_select_single_object():
    sel = SelectionManager()
    sel.select("obj-1")
    assert sel.selected_ids() == ["obj-1"]
    assert sel.primary_selected_id() == "obj-1"
    assert sel.is_selected("obj-1")


def test_select_replaces_previous_selection():
    sel = SelectionManager()
    sel.select("obj-1")
    sel.select("obj-2")
    assert sel.selected_ids() == ["obj-2"]


def test_select_multiple_deduplicates():
    sel = SelectionManager()
    sel.select_multiple(["a", "b", "a", "c"])
    assert sel.selected_ids() == ["a", "b", "c"]


def test_add_to_selection():
    sel = SelectionManager()
    sel.select("a")
    sel.add_to_selection("b")
    assert sel.selected_ids() == ["a", "b"]


def test_deselect_removes_only_that_object():
    sel = SelectionManager()
    sel.select_multiple(["a", "b"])
    sel.deselect("a")
    assert sel.selected_ids() == ["b"]


def test_deselect_all():
    sel = SelectionManager()
    sel.select_multiple(["a", "b"])
    sel.deselect_all()
    assert sel.selected_ids() == []
    assert not sel.has_selection()


def test_selection_changed_signal_fires():
    sel = SelectionManager()
    events = []
    sel.selection_changed.connect(lambda ids: events.append(list(ids)))

    sel.select("a")
    sel.add_to_selection("b")
    sel.deselect_all()

    assert events == [["a"], ["a", "b"], []]


def test_selection_changed_not_emitted_on_noop_deselect_all():
    sel = SelectionManager()
    events = []
    sel.selection_changed.connect(lambda ids: events.append(list(ids)))
    sel.deselect_all()
    assert events == []
