from core.transform import Transform, Vector3


def test_vector3_default_is_zero():
    v = Vector3()
    assert v.as_tuple() == (0.0, 0.0, 0.0)


def test_vector3_to_from_dict_roundtrip():
    v = Vector3(1.5, -2.0, 3.25)
    data = v.to_dict()
    restored = Vector3.from_dict(data)
    assert restored.as_tuple() == v.as_tuple()


def test_transform_default_scale_is_one():
    t = Transform()
    assert t.scale.as_tuple() == (1.0, 1.0, 1.0)
    assert t.position.as_tuple() == (0.0, 0.0, 0.0)


def test_transform_copy_is_independent():
    t1 = Transform()
    t2 = t1.copy()
    t2.position.x = 99.0
    assert t1.position.x == 0.0
    assert t2.position.x == 99.0
    assert t1.position is not t2.position


def test_transform_reset():
    t = Transform()
    t.position = Vector3(1, 2, 3)
    t.scale = Vector3(2, 2, 2)
    t.reset()
    assert t.position.as_tuple() == (0.0, 0.0, 0.0)
    assert t.scale.as_tuple() == (1.0, 1.0, 1.0)


def test_transform_to_from_dict_roundtrip():
    t = Transform(position=Vector3(1, 2, 3), rotation=Vector3(0, 90, 0), scale=Vector3(2, 2, 2))
    data = t.to_dict()
    restored = Transform.from_dict(data)
    assert restored.position.as_tuple() == (1.0, 2.0, 3.0)
    assert restored.rotation.as_tuple() == (0.0, 90.0, 0.0)
    assert restored.scale.as_tuple() == (2.0, 2.0, 2.0)
