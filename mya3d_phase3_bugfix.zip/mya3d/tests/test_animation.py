from core.animation import AnimationClip, AnimationTrack, lerp, lerp_transform, lerp_vector3
from core.keyframe import Keyframe
from core.transform import Transform, Vector3


def test_lerp_basic():
    assert lerp(0.0, 10.0, 0.5) == 5.0
    assert lerp(0.0, 10.0, 0.0) == 0.0
    assert lerp(0.0, 10.0, 1.0) == 10.0


def test_lerp_vector3():
    a = Vector3(0, 0, 0)
    b = Vector3(10, 20, 30)
    result = lerp_vector3(a, b, 0.5)
    assert result.as_tuple() == (5.0, 10.0, 15.0)


def test_lerp_transform_interpolates_all_channels():
    a = Transform(position=Vector3(0, 0, 0), rotation=Vector3(0, 0, 0), scale=Vector3(1, 1, 1))
    b = Transform(position=Vector3(10, 0, 0), rotation=Vector3(90, 0, 0), scale=Vector3(2, 2, 2))
    mid = lerp_transform(a, b, 0.5)
    assert mid.position.as_tuple() == (5.0, 0.0, 0.0)
    assert mid.rotation.as_tuple() == (45.0, 0.0, 0.0)
    assert mid.scale.as_tuple() == (1.5, 1.5, 1.5)


def test_keyframe_copy_is_independent():
    kf = Keyframe(frame=10, transform=Transform(position=Vector3(1, 2, 3)))
    copy = kf.copy()
    copy.transform.position.x = 99.0
    assert kf.transform.position.x == 1.0


def test_keyframe_to_from_dict_roundtrip():
    kf = Keyframe(frame=5, transform=Transform(position=Vector3(1, 2, 3)))
    restored = Keyframe.from_dict(kf.to_dict())
    assert restored.frame == 5
    assert restored.transform.position.as_tuple() == (1.0, 2.0, 3.0)


def test_track_insert_keyframe_creates_and_sorts():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(30, Transform(position=Vector3(5, 0, 0)))
    track.insert_keyframe(1, Transform(position=Vector3(0, 0, 0)))
    assert track.frames() == [1, 30]


def test_track_insert_keyframe_at_existing_frame_updates_it():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(10, Transform(position=Vector3(1, 0, 0)))
    track.insert_keyframe(10, Transform(position=Vector3(9, 0, 0)))
    assert len(track.keyframes) == 1
    assert track.get_keyframe_at(10).transform.position.x == 9.0


def test_track_remove_keyframe():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(10, Transform())
    assert track.remove_keyframe(10) is True
    assert track.frames() == []
    assert track.remove_keyframe(10) is False


def test_track_evaluate_no_keyframes_returns_none():
    track = AnimationTrack(object_id="obj-1")
    assert track.evaluate(5) is None


def test_track_evaluate_before_first_keyframe_holds_first_value():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(10, Transform(position=Vector3(5, 0, 0)))
    result = track.evaluate(1)
    assert result.position.as_tuple() == (5.0, 0.0, 0.0)


def test_track_evaluate_after_last_keyframe_holds_last_value():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(10, Transform(position=Vector3(5, 0, 0)))
    result = track.evaluate(999)
    assert result.position.as_tuple() == (5.0, 0.0, 0.0)


def test_track_evaluate_interpolates_between_two_keyframes():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(1, Transform(position=Vector3(0, 0, 0)))
    track.insert_keyframe(30, Transform(position=Vector3(29, 0, 0)))
    result = track.evaluate(16)  # 15/29 of the way through
    assert abs(result.position.x - 15.0) < 1e-6


def test_track_evaluate_exact_keyframe_frame_returns_exact_value():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(1, Transform(position=Vector3(0, 0, 0)))
    track.insert_keyframe(30, Transform(position=Vector3(29, 0, 0)))
    result = track.evaluate(30)
    assert result.position.as_tuple() == (29.0, 0.0, 0.0)


def test_track_evaluate_with_three_keyframes_picks_correct_segment():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(1, Transform(position=Vector3(0, 0, 0)))
    track.insert_keyframe(10, Transform(position=Vector3(10, 0, 0)))
    track.insert_keyframe(20, Transform(position=Vector3(0, 0, 0)))
    assert abs(track.evaluate(5.5).position.x - 5.0) < 1e-6
    assert abs(track.evaluate(15).position.x - 5.0) < 1e-6


def test_track_to_from_dict_roundtrip():
    track = AnimationTrack(object_id="obj-1")
    track.insert_keyframe(1, Transform(position=Vector3(0, 0, 0)))
    track.insert_keyframe(30, Transform(position=Vector3(5, 0, 0)))
    restored = AnimationTrack.from_dict(track.to_dict())
    assert restored.object_id == "obj-1"
    assert restored.frames() == [1, 30]


def test_clip_get_or_create_track():
    clip = AnimationClip()
    track = clip.get_or_create_track("obj-1")
    assert track.object_id == "obj-1"
    assert clip.get_or_create_track("obj-1") is track


def test_clip_has_track_false_until_keyframe_inserted():
    clip = AnimationClip()
    clip.get_or_create_track("obj-1")
    assert clip.has_track("obj-1") is False
    clip.get_or_create_track("obj-1").insert_keyframe(1, Transform())
    assert clip.has_track("obj-1") is True


def test_clip_animated_object_ids_excludes_empty_tracks():
    clip = AnimationClip()
    clip.get_or_create_track("empty-obj")
    clip.get_or_create_track("real-obj").insert_keyframe(1, Transform())
    assert clip.animated_object_ids() == ["real-obj"]


def test_clip_remove_track_if_empty():
    clip = AnimationClip()
    track = clip.get_or_create_track("obj-1")
    track.insert_keyframe(1, Transform())
    track.remove_keyframe(1)
    clip.remove_track_if_empty("obj-1")
    assert clip.get_track("obj-1") is None


def test_clip_to_from_dict_roundtrip():
    clip = AnimationClip()
    clip.get_or_create_track("obj-1").insert_keyframe(1, Transform(position=Vector3(1, 2, 3)))
    clip.get_or_create_track("obj-2").insert_keyframe(5, Transform(position=Vector3(9, 9, 9)))
    restored = AnimationClip.from_dict(clip.to_dict())
    assert set(restored.animated_object_ids()) == {"obj-1", "obj-2"}
    assert restored.get_track("obj-1").evaluate(1).position.as_tuple() == (1.0, 2.0, 3.0)


def test_clip_to_dict_omits_empty_tracks():
    clip = AnimationClip()
    clip.get_or_create_track("empty-obj")
    data = clip.to_dict()
    assert data["tracks"] == []
