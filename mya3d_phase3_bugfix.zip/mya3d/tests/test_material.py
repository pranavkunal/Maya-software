from core.object_types import SceneObjectType
from core.scene_object import SceneObject
from graphics.material import DEFAULT_BASE_COLOR, Material


def test_material_default_values():
    mat = Material.default()
    assert mat.base_color == DEFAULT_BASE_COLOR
    assert 0.0 <= mat.roughness <= 1.0
    assert 0.0 <= mat.metallic <= 1.0
    assert mat.texture_path is None


def test_material_clamps_base_color_to_0_1():
    mat = Material(base_color=(2.0, -1.0, 0.5))
    assert mat.base_color == (1.0, 0.0, 0.5)


def test_material_clamps_roughness_and_metallic():
    mat = Material(roughness=5.0, metallic=-3.0)
    assert mat.roughness == 1.0
    assert mat.metallic == 0.0


def test_material_to_dict_omits_texture_path_when_none():
    mat = Material(base_color=(0.1, 0.2, 0.3))
    data = mat.to_dict()
    assert "texture_path" not in data
    assert data["base_color"] == [0.1, 0.2, 0.3]


def test_material_to_dict_includes_texture_path_when_set():
    mat = Material(texture_path="textures/wood.png")
    data = mat.to_dict()
    assert data["texture_path"] == "textures/wood.png"


def test_material_from_dict_roundtrip():
    mat = Material(base_color=(0.5, 0.4, 0.3), roughness=0.2, metallic=0.8, texture_path="a.png")
    restored = Material.from_dict(mat.to_dict())
    assert restored.base_color == mat.base_color
    assert restored.roughness == mat.roughness
    assert restored.metallic == mat.metallic
    assert restored.texture_path == mat.texture_path


def test_material_from_dict_missing_fields_uses_defaults():
    restored = Material.from_dict({})
    assert restored.base_color == DEFAULT_BASE_COLOR
    assert restored.texture_path is None


# ------------------------------------------------------------------
# Renderer-side material resolution (backward compatibility with
# Phase 2 scenes that only ever set metadata["color"])
# ------------------------------------------------------------------
def test_material_for_object_uses_phase3_material_dict():
    from graphics.opengl_renderer import _material_for_object

    obj = SceneObject(
        name="Cube",
        type=SceneObjectType.MESH,
        metadata={"primitive": "cube", "material": {"base_color": [0.1, 0.2, 0.3]}},
    )
    material = _material_for_object(obj)
    assert material.base_color == (0.1, 0.2, 0.3)


def test_material_for_object_falls_back_to_legacy_color():
    from graphics.opengl_renderer import _material_for_object

    obj = SceneObject(
        name="Cube",
        type=SceneObjectType.MESH,
        metadata={"primitive": "cube", "color": (0.9, 0.1, 0.1)},
    )
    material = _material_for_object(obj)
    assert material.base_color == (0.9, 0.1, 0.1)


def test_material_for_object_defaults_when_no_metadata():
    from graphics.opengl_renderer import _material_for_object

    obj = SceneObject(name="Cube", type=SceneObjectType.MESH, metadata={"primitive": "cube"})
    material = _material_for_object(obj)
    assert material.base_color == DEFAULT_BASE_COLOR
