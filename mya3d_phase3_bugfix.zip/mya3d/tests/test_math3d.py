import math

import numpy as np

from graphics import math3d


def test_identity4_is_identity():
    m = math3d.identity4()
    assert np.allclose(m, np.eye(4))


def test_translation_matrix_moves_origin():
    m = math3d.translation_matrix(1.0, 2.0, 3.0)
    point = math3d.transform_point(m, (0.0, 0.0, 0.0))
    assert np.allclose(point, [1.0, 2.0, 3.0])


def test_scale_matrix_scales_point():
    m = math3d.scale_matrix(2.0, 3.0, 4.0)
    point = math3d.transform_point(m, (1.0, 1.0, 1.0))
    assert np.allclose(point, [2.0, 3.0, 4.0])


def test_rotation_matrix_y_90_degrees_maps_x_to_negative_z():
    m = math3d.rotation_matrix_y(90.0)
    point = math3d.transform_point(m, (1.0, 0.0, 0.0))
    assert np.allclose(point, [0.0, 0.0, -1.0], atol=1e-5)


def test_rotation_matrix_x_90_degrees_maps_y_to_z():
    m = math3d.rotation_matrix_x(90.0)
    point = math3d.transform_point(m, (0.0, 1.0, 0.0))
    assert np.allclose(point, [0.0, 0.0, 1.0], atol=1e-5)


def test_rotation_matrix_z_90_degrees_maps_x_to_y():
    m = math3d.rotation_matrix_z(90.0)
    point = math3d.transform_point(m, (1.0, 0.0, 0.0))
    assert np.allclose(point, [0.0, 1.0, 0.0], atol=1e-5)


def test_rotation_matrix_zero_degrees_is_identity():
    m = math3d.rotation_matrix_euler_xyz(0.0, 0.0, 0.0)
    assert np.allclose(m, np.eye(4), atol=1e-6)


def test_model_matrix_applies_scale_then_rotate_then_translate():
    m = math3d.model_matrix(
        position=(5.0, 0.0, 0.0),
        rotation_degrees=(0.0, 0.0, 0.0),
        scale=(2.0, 2.0, 2.0),
    )
    point = math3d.transform_point(m, (1.0, 0.0, 0.0))
    # scaled to (2,0,0) then translated by (5,0,0) -> (7,0,0)
    assert np.allclose(point, [7.0, 0.0, 0.0])


def test_model_matrix_identity_transform_is_identity_matrix():
    m = math3d.model_matrix((0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0))
    assert np.allclose(m, np.eye(4), atol=1e-6)


def test_normalize_unit_length():
    v = math3d.normalize(np.array([3.0, 4.0, 0.0]))
    assert math.isclose(float(np.linalg.norm(v)), 1.0, abs_tol=1e-6)


def test_normalize_zero_vector_returns_unchanged():
    v = math3d.normalize(np.array([0.0, 0.0, 0.0]))
    assert np.allclose(v, [0.0, 0.0, 0.0])


def test_look_at_matrix_eye_maps_to_origin_in_view_space():
    view = math3d.look_at_matrix(eye=(0.0, 0.0, 5.0), target=(0.0, 0.0, 0.0), up=(0.0, 1.0, 0.0))
    eye_in_view_space = math3d.transform_point(view, (0.0, 0.0, 5.0))
    assert np.allclose(eye_in_view_space, [0.0, 0.0, 0.0], atol=1e-5)


def test_look_at_matrix_target_is_in_front_of_camera():
    # Camera at +Z looking at origin: in view space, the target should
    # lie on the camera's local -Z axis (OpenGL convention).
    view = math3d.look_at_matrix(eye=(0.0, 0.0, 5.0), target=(0.0, 0.0, 0.0), up=(0.0, 1.0, 0.0))
    target_in_view_space = math3d.transform_point(view, (0.0, 0.0, 0.0))
    assert target_in_view_space[2] < 0


def test_perspective_matrix_shape_and_finite():
    proj = math3d.perspective_matrix(45.0, 16.0 / 9.0, 0.1, 1000.0)
    assert proj.shape == (4, 4)
    assert np.all(np.isfinite(proj))


def test_perspective_matrix_aspect_ratio_affects_x_scale():
    narrow = math3d.perspective_matrix(45.0, 1.0, 0.1, 1000.0)
    wide = math3d.perspective_matrix(45.0, 2.0, 0.1, 1000.0)
    # Wider aspect ratio compresses the X term (m[0,0] = f / aspect).
    assert wide[0, 0] < narrow[0, 0]


def test_perspective_matrix_invalid_aspect_ratio_falls_back_to_one():
    proj = math3d.perspective_matrix(45.0, 0.0, 0.1, 1000.0)
    assert np.all(np.isfinite(proj))


def test_screen_to_ndc_center_pixel_is_near_zero():
    ndc_x, ndc_y = math3d.screen_to_ndc(400, 300, 800, 600)
    assert math.isclose(ndc_x, 0.0, abs_tol=1e-6)
    assert math.isclose(ndc_y, 0.0, abs_tol=1e-6)


def test_screen_to_ndc_top_left_is_negative_x_positive_y():
    ndc_x, ndc_y = math3d.screen_to_ndc(0, 0, 800, 600)
    assert ndc_x < 0
    assert ndc_y > 0


def test_unproject_ray_direction_is_unit_length():
    view = math3d.look_at_matrix((0, 0, 5), (0, 0, 0), (0, 1, 0))
    proj = math3d.perspective_matrix(45.0, 1.0, 0.1, 1000.0)
    origin, direction = math3d.unproject_ray(0.0, 0.0, view, proj)
    assert math.isclose(float(np.linalg.norm(direction)), 1.0, abs_tol=1e-4)


def test_unproject_ray_center_points_towards_target():
    view = math3d.look_at_matrix((0, 0, 5), (0, 0, 0), (0, 1, 0))
    proj = math3d.perspective_matrix(45.0, 1.0, 0.1, 1000.0)
    origin, direction = math3d.unproject_ray(0.0, 0.0, view, proj)
    # Ray through the center of the screen should point roughly -Z.
    assert direction[2] < 0


def test_ray_plane_intersection_hits_ground_plane():
    origin = np.array([0.0, 5.0, 0.0])
    direction = math3d.normalize(np.array([0.0, -1.0, 0.0]))
    hit = math3d.ray_plane_intersection(
        origin, direction, np.array([0.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])
    )
    assert hit is not None
    assert np.allclose(hit, [0.0, 0.0, 0.0], atol=1e-5)


def test_ray_plane_intersection_parallel_ray_returns_none():
    origin = np.array([0.0, 5.0, 0.0])
    direction = math3d.normalize(np.array([1.0, 0.0, 0.0]))  # parallel to Y=const plane
    hit = math3d.ray_plane_intersection(
        origin, direction, np.array([0.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])
    )
    assert hit is None


def test_ray_plane_intersection_behind_origin_returns_none():
    origin = np.array([0.0, -5.0, 0.0])
    direction = math3d.normalize(np.array([0.0, -1.0, 0.0]))  # pointing away from the plane
    hit = math3d.ray_plane_intersection(
        origin, direction, np.array([0.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])
    )
    assert hit is None
