# MYA 3D Editor

An original, Maya-inspired 3D content creation application, built in Python with PySide6/Qt6 and a real-time OpenGL viewport.

MYA 3D Editor is **not** affiliated with or endorsed by Autodesk. It is an independent application that follows the general *workflow* conventions of professional 3D DCC (Digital Content Creation) tools without copying any copyrighted visual assets, branding, or code.

## Current Phase: Phase 3 — Transform Gizmos, Animation, Cameras, Materials

Phase 1 delivered the editor shell. Phase 2 replaced the placeholder viewport with a real OpenGL 3.3 renderer. **Phase 3** adds interactive transform gizmos, a keyframe animation system with real QTimer-driven playback, a proper scene-Camera object with true orthographic views and camera switching, and a basic material/texture system — all built on top of, and without breaking, Phases 1 and 2.

## Features Implemented

### Phase 1 (editor shell)
Main window with dark theme and saved layout; menu bar (File/Edit/Create/Select/Modify/View/Windows/Help); toolbar; Outliner; Properties; Timeline; status bar; framework-agnostic `Scene`/`SceneObject`/`Transform` data model; central `SelectionManager`; `CommandStack` undo/redo; object create/rename/delete/duplicate; versioned JSON `.mya` serializer.

### Phase 2 (real-time OpenGL viewport)
Real OpenGL 3.3 core-profile `QOpenGLWidget` viewport; `OpenGLRenderer` implementing `RendererInterface`; GLSL shaders; `EditorCamera` (orbit/pan/zoom); world grid + axes; basic directional lighting; `MeshData`/`MeshGPU` separation; procedural Cube/Sphere/Cylinder/Plane primitives; GPU color-picking selection; a first Move interaction (superseded by the Phase 3 gizmo below); Frame Selected; Reset View.

### Phase 3 (new)
- **Interactive transform gizmos** (`graphics/gizmo.py`, `graphics/gizmo_math.py`, `graphics/transform_gizmo.py`) — Move (3 axis handles + arrowheads), Rotate (3 axis rings), and Scale (3 axis box handles + a center uniform-scale handle) gizmos, rendered on top of the scene and following the selected object. Hit-testing uses real ray/axis and ray/plane-then-radius math (`gizmo_math.py`), not screen-space heuristics.
- **Mouse priority: gizmo > object picking > camera navigation** — a click first hit-tests the active tool's gizmo handles; only on a miss does it fall through to object picking; only Alt+Left/Right/Middle drags (which never hit a gizmo) drive camera navigation. Implemented in `ui/viewport.py::_try_begin_gizmo_drag`.
- **Axis constraints** — holding **X**/**Y**/**Z** while dragging a Move handle re-locks the drag to that world axis (toggle on/off); Scale drags are always per-axis (or uniform, via the center handle) by construction.
- **One undo command per drag** — Move/Rotate/Scale gizmo drags each produce exactly one `TransformObjectCommand` on mouse release (not per-pixel spam), matching Phase 2's existing Move-tool undo behavior.
- **Keyframe animation system** (`core/keyframe.py`, `core/animation.py`) — `Keyframe` (frame + full Transform snapshot), `AnimationTrack` (per-object, sorted, insert/remove/evaluate), `AnimationClip` (one track per animated object, owned by `MainWindow`, not `Scene`). Linear interpolation of position/rotation/scale between the two surrounding keyframes; held constant before the first and after the last.
- **Insert Keyframe** — press **I** with an object selected (viewport-scoped, so it never fires while renaming text) or Modify > Insert Keyframe, storing the object's current Transform at the current timeline frame (updates the keyframe in place if one already exists there).
- **Timeline keyframe markers** — a new diamond-marker track under the scrubber (`ui/timeline.py::KeyframeTrackWidget`) shows every keyframe of the selected object; clicking a marker (or anywhere on the track) jumps to that frame.
- **Real Play/Pause/Stop** (`QTimer`-driven, never a blocking loop) — Play starts a timer at the configured FPS (default 24) advancing the current frame and looping at the end frame; Pause stops the timer in place; Stop pauses and returns to the start frame. Every frame change (scrubbing *or* playback) re-evaluates every animated object's Transform and applies it directly to the scene (bypassing the undo stack — scrubbing through 100 frames must not create 100 undo entries) and triggers a viewport/Properties refresh.
- **Scene Camera vs. Editor Camera, properly distinguished** (see below) — a `Camera`-type `SceneObject` now carries real camera properties (FOV, near/far clip, projection type) via `graphics/camera.py::SceneCameraSettings`, editable in the Properties panel, and the viewport can render *through* it via **View > Look Through Selected Camera** (or return via the checkbox / Numpad 0).
- **True orthographic projection** (`graphics/math3d.py::orthographic_matrix`) — a real orthographic projection matrix, not a perspective camera pushed far away. The View menu's Front/Back/Left/Right/Top/Bottom presets switch `EditorCamera` into orthographic mode with the documented viewing direction for each; Perspective switches back.
- **Basic material system** (`graphics/material.py::Material`) — base_color/roughness/metallic, stored as logical scene data in `SceneObject.metadata["material"]` (falls back to the Phase 2 `metadata["color"]` convention for old objects/scenes, so nothing regresses).
- **Basic texture support** (`graphics/texture.py`) — Pillow-based PNG/JPEG loading (`TextureData`, GPU-independent, unit-tested) and GPU upload/bind/release (`TextureGPU`). A material's optional `texture_path` is sampled and modulated with `base_color` in the shader.
- **UV coordinates** (`graphics/mesh.py`, `graphics/primitives.py`) — `MeshData.uvs` is optional (`None` for meshes without UVs, fully backward compatible); Cube/Sphere/Cylinder/Plane all generate real per-vertex UVs.
- **Shader upgrade** (`graphics/shaders/basic.vert`/`basic.frag`) — now carries an optional UV attribute and samples an optional base-color texture, plus roughness/metallic-influenced specular hints. Still explicitly not PBR.
- **`.mya` format bumped to version 2**, backward compatible — `SUPPORTED_VERSIONS = (1, 2)`, so **every Phase 1/2 file still loads unchanged**. Keyframe animation is stored separately from `Scene` (via new `save_scene_with_animation`/`load_scene_with_animation` functions) so the plain `save_scene`/`load_scene`/`scene_to_dict`/`scene_from_dict` functions keep their exact Phase 1/2 signatures and behavior.
- **QFont warning fixed** — root cause: `ui/styles.py`'s global stylesheet set `font-size` in pixels, which puts every `QFont` into "pixel size" mode where `QFont.pointSize()` always returns -1; a Qt-internal code path (dock/title-bar font handling) read that back into `QFont.setPointSize()`, producing `QFont::setPointSize: Point size <= 0 (-1)`. Fixed by switching the stylesheet to point units, plus a defensive explicit `QFont("Segoe UI", 9)` set on the `QApplication` itself (`app/application.py`) so the whole app starts with a valid point-size font regardless of stylesheet timing.

## Features Intentionally NOT Implemented (Phase 3)

Per the Phase 3 spec's explicit boundary: PBR, HDR, IBL, advanced shadows, SSAO, bloom, node-based materials, sculpting, rigging/skinning/IK, an advanced UV editor, an animation graph editor or nonlinear animation, particles, physics, cloth/fluid/hair, subdivision/boolean modeling, a plugin system, a scripting API, collaboration, or AI features. None of these were implemented, not even partially.

Also still out of scope (carried over / explicitly deferred):
- Vertex/edge/face mesh editing
- Rendering *through* a scene camera's own visual identity in the viewport (no camera-frustum gizmo drawn yet — only the transform gizmo)
- Cut/Copy/Paste, Import/Export (still menu stubs)

## Editor Camera vs. Scene Camera

`graphics/camera.py::EditorCamera` is the **UI navigation aid** used to fly around the viewport (orbit/pan/zoom). It is never serialized into `.mya` files and has no `SceneObject` of its own.

A `Camera`-type `SceneObject` (Create > Camera) is a real, logical, selectable, animatable scene object with its own `Transform` **and** camera properties (FOV/near/far/projection, `graphics/camera.py::SceneCameraSettings`, stored in `metadata["camera"]`), editable in the Properties panel and saved/loaded with the scene. **View > Look Through Selected Camera** switches the viewport to render through it (via `graphics/camera.py::SceneCameraView`, a thin adapter exposing the same `get_view_matrix()`/`get_projection_matrix()`/`position()` interface `EditorCamera` does, so `OpenGLRenderer` needs no camera-type branching at all); the toggle (or Numpad 0) returns to the `EditorCamera`. Camera navigation (orbit/pan/zoom/Reset View/view presets) is disabled while locked to a scene camera.

## Coordinate Convention

Unchanged from Phase 2, documented in `graphics/math3d.py`: right-handed, Y-up, camera looks down its own local −Z with local +Y as up, rotations are Euler XYZ in degrees. A scene Camera object follows the exact same convention (`graphics/camera.py::scene_camera_view_matrix`), so it rotates exactly like any other SceneObject.

Orthographic view directions (View menu / `_VIEW_PRESETS` in `ui/viewport.py`): Front looks toward −Z, Back toward +Z, Left toward +X, Right toward −X, Top toward −Y, Bottom toward +Y.

## Mouse Controls

| Action | Control |
|---|---|
| Select object | Left-click (no drag) on it; click empty space to deselect |
| **Drag a gizmo handle** | Left-drag an axis/ring/box handle to Move/Rotate/Scale the selected object (Move/Rotate/Scale tool) |
| Orbit | **Alt + Left-drag**, or **Right-drag** (disabled while looking through a scene camera) |
| Pan | **Middle-drag** (disabled while looking through a scene camera) |
| Zoom | Mouse wheel (disabled while looking through a scene camera) |
| Constrain a Move drag to an axis | Hold **X**, **Y**, or **Z** while dragging (press again to release) |
| Jump to a keyframe | Click its diamond marker on the Timeline's keyframe track |

Mouse priority is **gizmo handle > object picking > camera navigation**: a click first hit-tests the active tool's gizmo; only a miss falls through to picking, and only Alt/Right/Middle drags (which never hit a gizmo) navigate the camera.

## Keyboard Shortcuts

Global (modifier-based, never interfere with typing):

| Shortcut | Action |
|---|---|
| Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S | New / Open / Save / Save As |
| Ctrl+Z / Ctrl+Shift+Z | Undo / Redo |
| Ctrl+D | Duplicate selected |
| Ctrl+Q | Exit |

Viewport-scoped (handled inside the viewport widget itself, so they only fire while the 3D viewport has keyboard focus — never while renaming an object in the Outliner or editing the Properties Name field):

| Key | Action |
|---|---|
| Q / W / E / R | Select / Move / Rotate / Scale tool |
| Delete / Backspace | Delete selected object(s) |
| F | Frame Selected |
| I | Insert Keyframe for the selection at the current frame |
| Numpad 0 | Return to the editor camera (when looking through a scene camera) |

## Grid Visibility

**View > Grid** toggles the world grid/axes without ever hiding mesh objects.

## Animation Workflow

1. Select an object, move the Timeline to a frame, then press **I** (or Modify > Insert Keyframe) to record its current Transform there.
2. Repeat at other frames — the Timeline's keyframe track shows a diamond at each one.
3. Scrub the Timeline (drag the slider, click a marker, or edit the Frame field) to preview the interpolated pose at any frame.
4. Press **Play** to animate at the configured FPS (loops at the end frame); **Pause** stops in place; **Stop** pauses and returns to the start frame.

Interpolation is linear only (Phase 3 scope); Bezier/curve interpolation is future work (kept isolated behind `core/animation.py::lerp_transform` so it can be swapped in later without touching `AnimationTrack`).

## Camera Workflow

- Create a Camera (Create > Camera), select it, and set its Field of View / Near Clip / Far Clip / Projection in the Properties panel.
- **View > Look Through Selected Camera** switches the viewport to render through it; toggle it off (or press Numpad 0) to return to the free-navigating editor camera.
- **View > Perspective/Front/Back/Left/Right/Top/Bottom** switch the *editor* camera's projection/angle — these are independent of any scene Camera object.

## Materials & Textures

Every mesh object has an implicit default material (a neutral gray). Phase 3 does not yet add a Properties-panel material editor UI — materials/textures are set via `SceneObject.metadata["material"]` (a plain dict matching `graphics/material.py::Material.to_dict()`), which the renderer reads every frame; this keeps material data logical/serializable rather than GPU-only state. A texture is referenced by file path (`material.texture_path`, PNG/JPEG via Pillow) and sampled in the shader when the mesh has UVs.

## Serialization

The `.mya` format is now version 2 (`sceneio/scene_serializer.py::SCENE_FORMAT_VERSION`), but **every Phase 1/2 file still loads unchanged** — `SUPPORTED_VERSIONS = (1, 2)`, and the SceneObject/metadata schema shape never actually changed (mesh primitive, camera, and material data all already lived in the generic `metadata` dict). Keyframe animation is stored under a separate top-level `"animations"` key via `save_scene_with_animation`/`load_scene_with_animation`; the plain `save_scene`/`load_scene` functions are untouched and never write or expect that key, for full backward/forward compatibility. No raw GPU buffers or OpenGL state are ever serialized.

## Current Limitations

- Rotate/Scale gizmos are functional but visually simple (line-based handles, not shaded 3D geometry).
- No camera-frustum visualization is drawn for scene Camera objects yet.
- No material/texture editor UI in Properties — set via scene metadata (see "Materials & Textures").
- Animation interpolation is linear only; no curve editor.
- This environment could not create a real OpenGL/Qt context to visually verify rendering, gizmo interaction, or playback — see "Testing" below for exactly what was and wasn't verified.

## Requirements

- Python 3.12+
- PySide6 (Qt6)
- PyOpenGL
- NumPy
- Pillow (texture loading)
- pytest

See `requirements.txt`.

## Installation

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Then:
```bash
pip install -r requirements.txt
```

## Running the Application

```bash
python main.py
```

## Running Tests

```bash
pytest
```

The suite is entirely CPU-side/unit-level (no GPU or Qt event loop required): Phase 1/2 tests (`test_transform.py`, `test_scene.py`, `test_selection.py`, `test_commands.py`, `test_serializer.py`, `test_math3d.py`, `test_camera.py`, `test_primitives.py`, `test_renderer_interface.py`) plus Phase 3 additions (`test_animation.py`, `test_gizmo_math.py`, `test_gizmo_geometry.py`, `test_material.py`, `test_texture.py`, `test_camera_modes.py`, `test_timeline.py`) and extensions to `test_serializer.py`/`test_scene.py` for mesh/camera/animation metadata.

`test_timeline.py` tests the Qt-independent `TimelineState` class only; it, like all of `ui/*`, requires PySide6 to even import and so needs a real PySide6 install to run.

## Project Architecture

```
mya3d/
├── main.py
├── app/                         # QApplication bootstrap, logging, settings
├── core/                        # Framework-agnostic scene + animation data (no Qt/GL)
│   ├── scene.py / scene_object.py / transform.py / ids.py / object_types.py / signal.py
│   └── keyframe.py / animation.py        # Phase 3: Keyframe, AnimationTrack, AnimationClip
├── editor/                      # SelectionManager, ToolManager, CommandStack (Qt-free)
├── ui/                          # PySide6 widgets
│   ├── main_window.py            # Assembly/wiring; owns AnimationClip
│   ├── viewport.py               # ViewportGLWidget: camera, renderer, gizmo interaction
│   ├── outliner.py / properties.py / timeline.py / toolbar.py / styles.py
├── sceneio/
│   └── scene_serializer.py       # Versioned JSON .mya (+ *_with_animation variants)
├── graphics/                    # Rendering pipeline (no Qt)
│   ├── renderer_interface.py / opengl_renderer.py / camera.py / mesh.py / primitives.py / math3d.py
│   ├── material.py / texture.py           # Phase 3
│   ├── gizmo.py / gizmo_math.py / transform_gizmo.py   # Phase 3
│   └── shaders/  (basic.vert/frag, grid.vert/frag, picking.frag)
├── resources/icons/
├── tests/                       # pytest suite (CPU/unit only)
├── requirements.txt / .gitignore / README.md
```

Design principles preserved from Phase 1/2: `core`/`editor` never import Qt or OpenGL; `graphics` never imports Qt (`OpenGLRenderer` reads `Scene`/`SceneObject` read-only, no selection/undo/UI logic inside it — the viewport tells it what's selected each frame); `ui` widgets read from `Scene`/`SelectionManager` and write through `CommandStack`, never calling each other directly; `MainWindow` only assembles and wires; GPU resources are created once and cached, never rebuilt per frame; the `.mya` format is versioned with a clear, honest compatibility story.

## Testing

This environment could not install PySide6/PyOpenGL (no network access) and therefore could not create a real Qt/OpenGL context. It **did** have NumPy and Pillow available, so all pure-Python/NumPy/Pillow logic — gizmo math, camera math (including orthographic and scene-camera matrices), primitive/UV generation, animation interpolation, material resolution, and real texture file decoding — was actually executed, not just read. What was and wasn't verified is stated precisely in the Phase 3 completion report delivered with this codebase; in short:

- **Verified by actually running the tests**: all CPU/unit tests — 232 test cases, 0 failures.
- **Verified by static review only**: gizmo GPU rendering/interaction, scene-camera "look through" switching, animation-driven viewport updates, material/texture GPU upload and shader sampling, timeline keyframe-marker painting, and all other Qt widget code.
- **Not verified at all in this environment**: an actual running window, real gizmo dragging, real playback, real camera switching. These require a machine with a real GPU/driver and PySide6+PyOpenGL+Pillow installed.

```bash
pip install -r requirements.txt
python main.py
pytest
```

## Roadmap / Phase 4 (not started)

Full professional manipulator polish (screen-space-constant gizmo sizing, shaded 3D handle geometry); Bezier/curve animation interpolation and a curve editor; camera-frustum visualization; a Properties-panel material/texture editor; vertex/edge/face mesh editing.
