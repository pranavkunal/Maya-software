"""Renderer abstraction.

Phase 1 shipped this module with NO real rendering code, so
``ViewportWidget`` could depend only on the interface and never a
concrete renderer. Phase 2 implements it for real in
``graphics/opengl_renderer.py`` (``OpenGLRenderer``), but the
abstraction is preserved so a future renderer backend could still be
swapped in without changing ``ui/viewport.py``'s structure.

Extension note (Phase 2): the ``render()`` method now takes ``scene``
and ``camera`` arguments, matching the spec's requested
``render(scene, camera)`` signature -- this is one intentional change
to the Phase 1 interface, needed because a real renderer must know
*what* to draw and *from where*. ``resize()`` and ``render()`` also
gained an optional ``default_framebuffer: int = 0`` parameter: under
Qt, ``QOpenGLWidget`` renders into its own internally-managed FBO, not
system framebuffer 0, so a concrete renderer must be told which FBO id
to restore to after any offscreen pass (e.g. picking) rather than
assuming 0 -- hardcoding 0 previously caused ``GL_INVALID_ENUM``
failures on real Qt/Windows contexts. The parameter defaults to 0 so
non-Qt callers (tests, a future headless/offscreen renderer) keep
working unchanged. Concrete renderers may also expose additional,
non-abstract attributes/methods (e.g. ``OpenGLRenderer.selected_ids``
/ ``.grid_visible`` / ``.pick()``) for renderer-specific state that
doesn't belong in the shared interface.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class RendererInterface(ABC):
    """Abstract base class every renderer backend must implement."""

    @abstractmethod
    def initialize(self, surface: Any) -> None:
        """Set up GPU resources against the given native surface/widget."""

    @abstractmethod
    def resize(self, width: int, height: int, default_framebuffer: int = 0) -> None:
        """Handle a viewport resize.

        ``default_framebuffer`` is the FBO id the host widget renders
        into (see the module docstring); pass the real value under Qt.
        """

    @abstractmethod
    def render(self, scene: Any, camera: Any, default_framebuffer: int = 0) -> None:
        """Render a single frame of ``scene`` as seen from ``camera``.

        ``default_framebuffer`` is the FBO id the host widget renders
        into (see the module docstring); pass the real value under Qt.
        """

    @abstractmethod
    def shutdown(self) -> None:
        """Release all GPU resources."""


class NullRenderer(RendererInterface):
    """A no-op renderer.

    Not used by the running application, but provided as a trivial,
    safe reference implementation of the interface and a convenient
    default for tests that need *some* RendererInterface instance
    without touching real GPU resources.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._size: Optional[tuple] = None

    def initialize(self, surface: Any) -> None:
        self._initialized = True

    def resize(self, width: int, height: int, default_framebuffer: int = 0) -> None:
        self._size = (width, height)

    def render(self, scene: Any, camera: Any, default_framebuffer: int = 0) -> None:
        return None

    def shutdown(self) -> None:
        self._initialized = False
