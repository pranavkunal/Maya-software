"""Minimal material abstraction (Phase 3 scope only -- NOT PBR).

A ``Material`` is plain logical scene data: a base color plus two
scalar hints (roughness, metallic) that the basic shader may use to
tweak its simple diffuse+specular lighting. There is no BRDF, no
IBL, no texture-slot system beyond a single optional base-color
texture path -- a full PBR pipeline is explicitly future work.

Framework-independent (no Qt/GL/Pillow import here); stored on a
SceneObject via its existing generic ``metadata["material"]`` dict
(see ``core/scene_object.py``), the same extension pattern already
used for ``metadata["primitive"]``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

DEFAULT_BASE_COLOR: Tuple[float, float, float] = (0.65, 0.65, 0.68)


@dataclass
class Material:
    """A basic material: base color plus optional roughness/metallic
    hints and an optional base-color texture path.
    """

    base_color: Tuple[float, float, float] = DEFAULT_BASE_COLOR
    roughness: float = 0.6
    metallic: float = 0.0
    texture_path: Optional[str] = None

    def __post_init__(self) -> None:
        r, g, b = self.base_color
        self.base_color = (
            float(max(0.0, min(1.0, r))),
            float(max(0.0, min(1.0, g))),
            float(max(0.0, min(1.0, b))),
        )
        self.roughness = float(max(0.0, min(1.0, self.roughness)))
        self.metallic = float(max(0.0, min(1.0, self.metallic)))

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "base_color": list(self.base_color),
            "roughness": self.roughness,
            "metallic": self.metallic,
        }
        if self.texture_path:
            data["texture_path"] = self.texture_path
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Material":
        base_color = data.get("base_color", list(DEFAULT_BASE_COLOR))
        return cls(
            base_color=(float(base_color[0]), float(base_color[1]), float(base_color[2])),
            roughness=float(data.get("roughness", 0.6)),
            metallic=float(data.get("metallic", 0.0)),
            texture_path=data.get("texture_path"),
        )

    @classmethod
    def default(cls) -> "Material":
        return cls()
