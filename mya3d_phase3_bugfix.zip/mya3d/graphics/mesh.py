"""Mesh abstraction: CPU-side ``MeshData`` and GPU-side ``MeshGPU``.

Kept as two distinct classes on purpose:

    MeshData  -- plain NumPy arrays (positions/normals/indices). No
                 OpenGL dependency at all; fully unit-testable without
                 a GPU or even PyOpenGL installed.
    MeshGPU   -- owns the actual VAO/VBO/EBO and uploads a MeshData
                 once. Only this class touches PyOpenGL.

``SceneObject`` never touches either of these directly -- the renderer
looks up/creates a ``MeshGPU`` for a given primitive type and reuses
it across every SceneObject that references that primitive (see
``graphics/opengl_renderer.py``), so GPU buffers are never rebuilt
per-frame or per-instance.
"""
from __future__ import annotations

import ctypes
import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

try:  # PyOpenGL may not be installed in headless/CI/dev environments.
    from OpenGL import GL as gl  # type: ignore
    _HAS_OPENGL = True
except ImportError:  # pragma: no cover - exercised only when PyOpenGL is absent
    gl = None  # type: ignore
    _HAS_OPENGL = False


@dataclass
class MeshData:
    """CPU-side geometry: positions, normals, triangle indices, and
    optional UV texture coordinates.

    Attributes:
        positions: (N, 3) float32 array of vertex positions.
        normals: (N, 3) float32 array of per-vertex normals.
        indices: (M,) uint32 array of triangle vertex indices
            (M is a multiple of 3).
        uvs: optional (N, 2) float32 array of per-vertex UV
            coordinates. ``None`` for meshes without UVs (fully
            backward compatible -- existing meshes/tests that never
            set this keep working unchanged; the renderer/shader only
            samples a texture when both a UV-having mesh AND a
            textured material are present).
    """

    positions: np.ndarray
    normals: np.ndarray
    indices: np.ndarray
    uvs: Optional[np.ndarray] = None

    def __post_init__(self) -> None:
        self.positions = np.asarray(self.positions, dtype=np.float32).reshape(-1, 3)
        self.normals = np.asarray(self.normals, dtype=np.float32).reshape(-1, 3)
        self.indices = np.asarray(self.indices, dtype=np.uint32).reshape(-1)
        if self.uvs is not None:
            self.uvs = np.asarray(self.uvs, dtype=np.float32).reshape(-1, 2)

    @property
    def has_uvs(self) -> bool:
        return self.uvs is not None and self.uvs.shape[0] == self.positions.shape[0]

    @property
    def vertex_count(self) -> int:
        return self.positions.shape[0]

    @property
    def index_count(self) -> int:
        return self.indices.shape[0]

    @property
    def triangle_count(self) -> int:
        return self.index_count // 3

    def is_valid(self) -> bool:
        """Basic sanity check: no empty/degenerate geometry, indices in range."""
        if self.vertex_count == 0 or self.index_count == 0:
            return False
        if self.index_count % 3 != 0:
            return False
        if self.normals.shape[0] != self.positions.shape[0]:
            return False
        if self.uvs is not None and self.uvs.shape[0] != self.positions.shape[0]:
            return False
        if int(self.indices.max(initial=0)) >= self.vertex_count:
            return False
        return True

    def interleaved(self) -> np.ndarray:
        """Return a single (N, 6) or (N, 8) float32 array of
        ``[pos.xyz, normal.xyz]`` or ``[pos.xyz, normal.xyz, uv.xy]``
        depending on whether this mesh has UVs. Interleaving keeps
        vertex attribute setup simple (one VBO, fixed stride).
        """
        if self.has_uvs:
            return np.hstack([self.positions, self.normals, self.uvs]).astype(np.float32)
        return np.hstack([self.positions, self.normals]).astype(np.float32)


class MeshGPU:
    """Owns the GPU-side VAO/VBO/EBO for a single ``MeshData``.

    Usage:
        mesh_gpu = MeshGPU(mesh_data)
        mesh_gpu.upload()   # once, inside a valid GL context
        ...
        mesh_gpu.draw()     # every frame
        ...
        mesh_gpu.release()  # on shutdown / context loss
    """

    _POSITION_ATTRIB_LOCATION = 0
    _NORMAL_ATTRIB_LOCATION = 1
    _UV_ATTRIB_LOCATION = 2

    def __init__(self, mesh_data: MeshData) -> None:
        self.mesh_data = mesh_data
        self._vao: Optional[int] = None
        self._vbo: Optional[int] = None
        self._ebo: Optional[int] = None
        self._uploaded = False

    @property
    def is_uploaded(self) -> bool:
        return self._uploaded

    @property
    def has_uvs(self) -> bool:
        return self.mesh_data.has_uvs

    def upload(self) -> None:
        """Create VAO/VBO/EBO and upload geometry. Must be called once,
        inside a current/valid OpenGL context.
        """
        if not _HAS_OPENGL:
            raise RuntimeError(
                "PyOpenGL is not installed; cannot upload mesh GPU buffers. "
                "Install it with `pip install PyOpenGL`."
            )
        if self._uploaded:
            return
        if not self.mesh_data.is_valid():
            raise ValueError("Cannot upload invalid/degenerate MeshData to the GPU")

        vertex_data = self.mesh_data.interleaved()
        index_data = self.mesh_data.indices
        stride_floats = 8 if self.mesh_data.has_uvs else 6

        self._vao = gl.glGenVertexArrays(1)
        gl.glBindVertexArray(self._vao)

        self._vbo = gl.glGenBuffers(1)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self._vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, vertex_data.nbytes, vertex_data, gl.GL_STATIC_DRAW)

        self._ebo = gl.glGenBuffers(1)
        gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, self._ebo)
        gl.glBufferData(
            gl.GL_ELEMENT_ARRAY_BUFFER, index_data.nbytes, index_data, gl.GL_STATIC_DRAW
        )

        stride = stride_floats * 4  # 4 bytes per float32
        gl.glEnableVertexAttribArray(self._POSITION_ATTRIB_LOCATION)
        gl.glVertexAttribPointer(
            self._POSITION_ATTRIB_LOCATION, 3, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(0)
        )
        gl.glEnableVertexAttribArray(self._NORMAL_ATTRIB_LOCATION)
        gl.glVertexAttribPointer(
            self._NORMAL_ATTRIB_LOCATION,
            3,
            gl.GL_FLOAT,
            gl.GL_FALSE,
            stride,
            ctypes.c_void_p(3 * 4),
        )
        if self.mesh_data.has_uvs:
            gl.glEnableVertexAttribArray(self._UV_ATTRIB_LOCATION)
            gl.glVertexAttribPointer(
                self._UV_ATTRIB_LOCATION,
                2,
                gl.GL_FLOAT,
                gl.GL_FALSE,
                stride,
                ctypes.c_void_p(6 * 4),
            )

        gl.glBindVertexArray(0)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)
        gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, 0)

        self._uploaded = True
        logger.debug(
            "Uploaded mesh: %d vertices, %d triangles, uvs=%s",
            self.mesh_data.vertex_count,
            self.mesh_data.triangle_count,
            self.mesh_data.has_uvs,
        )

    def draw(self, mode: Optional[int] = None) -> None:
        """Bind and draw this mesh. Requires ``upload()`` to have run."""
        if not _HAS_OPENGL:
            raise RuntimeError("PyOpenGL is not installed; cannot draw mesh")
        if not self._uploaded or self._vao is None:
            raise RuntimeError("MeshGPU.draw() called before upload()")
        draw_mode = mode if mode is not None else gl.GL_TRIANGLES
        gl.glBindVertexArray(self._vao)
        gl.glDrawElements(draw_mode, self.mesh_data.index_count, gl.GL_UNSIGNED_INT, None)
        gl.glBindVertexArray(0)

    def release(self) -> None:
        """Release GPU resources. Safe to call multiple times.

        Must be called with a valid/current GL context; the renderer
        is responsible for calling this only during an active context
        (e.g. from ``OpenGLRenderer.shutdown()``), never after the
        context has already been destroyed.
        """
        if not _HAS_OPENGL or not self._uploaded:
            self._uploaded = False
            return
        try:
            if self._vbo is not None:
                gl.glDeleteBuffers(1, [self._vbo])
            if self._ebo is not None:
                gl.glDeleteBuffers(1, [self._ebo])
            if self._vao is not None:
                gl.glDeleteVertexArrays(1, [self._vao])
        except Exception:  # pragma: no cover - defensive; context may already be gone
            logger.exception("Failed to release MeshGPU resources cleanly")
        finally:
            self._vao = None
            self._vbo = None
            self._ebo = None
            self._uploaded = False
