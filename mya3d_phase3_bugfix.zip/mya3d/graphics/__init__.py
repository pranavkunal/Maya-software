"""Rendering abstraction layer. Phase 1 defines interfaces only."""
