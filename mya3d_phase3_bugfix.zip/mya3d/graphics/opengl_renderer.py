"""Concrete ``RendererInterface`` implementation using modern (3.3 core
profile) OpenGL via PyOpenGL.

Architecture (see also the module docstring in ``ui/viewport.py``):

    ViewportWidget (Qt/QOpenGLWidget)
        -> OpenGLRenderer (this module)
            -> ShaderProgram   (graphics/shader_program.py)
            -> MeshGPU         (graphics/mesh.py)
            -> EditorCamera    (graphics/camera.py, owned by the widget)

``OpenGLRenderer`` only knows about graphics: shaders, GPU buffers,
matrices, and draw calls. It reads ``Scene``/``SceneObject`` data
(read-only) to decide *what* to draw, but never mutates scene state
and contains no selection/undo/UI logic of its own -- the viewport
tells it what's selected via ``self.selected_ids`` before each
``render()`` call.

GPU resource lifecycle: every shader program and every primitive
``MeshGPU`` is created exactly once, in ``initialize()`` or lazily on
first use (and cached), never rebuilt per-frame. ``shutdown()``
releases everything; it must be called while the owning GL context is
still current (the viewport does this from its own cleanup, before
the context is destroyed).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from core.object_types import SceneObjectType
from core.scene import Scene
from core.scene_object import SceneObject
from graphics import math3d
from graphics.camera import EditorCamera
from graphics.material import Material
from graphics.mesh import MeshData, MeshGPU
from graphics.primitives import generate_primitive
from graphics.renderer_interface import RendererInterface
from graphics.shader_program import ShaderCompilationError, ShaderProgram
from graphics.texture import TextureData, TextureGPU, TextureLoadError
from graphics.transform_gizmo import DynamicLineGPU

logger = logging.getLogger(__name__)

try:
    from OpenGL import GL as gl  # type: ignore
    _HAS_OPENGL = True
except ImportError:  # pragma: no cover
    gl = None  # type: ignore
    _HAS_OPENGL = False

_SHADERS_DIR = Path(__file__).parent / "shaders"

_BACKGROUND_COLOR = (0.09, 0.094, 0.106)
_GRID_LINE_COLOR = (0.30, 0.31, 0.33)
_GRID_LINE_COLOR_MAJOR = (0.42, 0.43, 0.46)
_AXIS_X_COLOR = (0.85, 0.25, 0.25)
_AXIS_Y_COLOR = (0.30, 0.75, 0.30)
_AXIS_Z_COLOR = (0.25, 0.45, 0.90)


class RendererInitError(RuntimeError):
    """Raised when OpenGL initialization (context/shaders) fails."""


class _LineGPU:
    """A minimal GPU line-list buffer: interleaved position+color, no
    index buffer, drawn with GL_LINES. Used for the grid/axes only.
    """

    def __init__(self, vertices: np.ndarray) -> None:
        # vertices: (N, 6) float32 [x,y,z, r,g,b]
        self._vertices = np.asarray(vertices, dtype=np.float32)
        self._vao: Optional[int] = None
        self._vbo: Optional[int] = None
        self._uploaded = False

    @property
    def vertex_count(self) -> int:
        return self._vertices.shape[0]

    def upload(self) -> None:
        if not _HAS_OPENGL:
            raise RuntimeError("PyOpenGL is not installed; cannot upload line buffer")
        if self._uploaded or self.vertex_count == 0:
            return
        import ctypes

        self._vao = gl.glGenVertexArrays(1)
        gl.glBindVertexArray(self._vao)

        self._vbo = gl.glGenBuffers(1)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self._vbo)
        gl.glBufferData(
            gl.GL_ARRAY_BUFFER, self._vertices.nbytes, self._vertices, gl.GL_STATIC_DRAW
        )

        stride = 6 * 4
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(1)
        gl.glVertexAttribPointer(1, 3, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(3 * 4))

        gl.glBindVertexArray(0)
        self._uploaded = True

    def draw(self) -> None:
        if not self._uploaded or self._vao is None:
            return
        gl.glBindVertexArray(self._vao)
        gl.glDrawArrays(gl.GL_LINES, 0, self.vertex_count)
        gl.glBindVertexArray(0)

    def release(self) -> None:
        if not _HAS_OPENGL or not self._uploaded:
            self._uploaded = False
            return
        try:
            if self._vbo is not None:
                gl.glDeleteBuffers(1, [self._vbo])
            if self._vao is not None:
                gl.glDeleteVertexArrays(1, [self._vao])
        except Exception:  # pragma: no cover - defensive
            logger.exception("Failed to release grid line buffer")
        finally:
            self._vao = None
            self._vbo = None
            self._uploaded = False


def _build_grid_and_axes_vertices(
    half_extent: float = 20.0, spacing: float = 1.0, major_every: int = 5
) -> np.ndarray:
    """Build interleaved [pos.xyz, color.rgb] line vertices for a ground
    grid on the X/Z plane plus X/Y/Z axis indicator lines, in world space.
    """
    lines: List[Tuple[float, float, float, float, float, float]] = []

    steps = int(half_extent / spacing)
    for i in range(-steps, steps + 1):
        coord = i * spacing
        is_major = (i % major_every) == 0
        color = _GRID_LINE_COLOR_MAJOR if is_major else _GRID_LINE_COLOR
        if abs(coord) < 1e-6:
            continue  # the origin lines are drawn as colored axes below
        # Line parallel to X axis at Z = coord
        lines.append((-half_extent, 0.0, coord, *color))
        lines.append((half_extent, 0.0, coord, *color))
        # Line parallel to Z axis at X = coord
        lines.append((coord, 0.0, -half_extent, *color))
        lines.append((coord, 0.0, half_extent, *color))

    # World axes through the origin, drawn on top of the grid.
    lines.append((-half_extent, 0.0, 0.0, *_AXIS_X_COLOR))
    lines.append((half_extent, 0.0, 0.0, *_AXIS_X_COLOR))
    lines.append((0.0, 0.0, -half_extent, *_AXIS_Z_COLOR))
    lines.append((0.0, 0.0, half_extent, *_AXIS_Z_COLOR))
    lines.append((0.0, 0.0, 0.0, *_AXIS_Y_COLOR))
    lines.append((0.0, half_extent * 0.15, 0.0, *_AXIS_Y_COLOR))

    return np.array(lines, dtype=np.float32)


def _normal_matrix_from_model(model: np.ndarray) -> np.ndarray:
    """3x3 inverse-transpose of the model matrix's upper-left 3x3, for
    correct normal transformation under non-uniform scale.
    """
    m3 = model[:3, :3]
    try:
        return np.linalg.inv(m3).T.astype(np.float32)
    except np.linalg.LinAlgError:
        # Degenerate (zero) scale on some axis -- fall back to the
        # rotation-only part rather than crashing the render loop.
        return m3.astype(np.float32)


def _encode_pick_id(index: int) -> Tuple[float, float, float]:
    """Encode a positive integer object index as an RGB color (0..1 floats)."""
    r = index & 0xFF
    g = (index >> 8) & 0xFF
    b = (index >> 16) & 0xFF
    return (r / 255.0, g / 255.0, b / 255.0)


def _decode_pick_id(pixel: Tuple[int, int, int]) -> int:
    r, g, b = pixel
    return int(r) | (int(g) << 8) | (int(b) << 16)


def _material_for_object(obj: SceneObject) -> Material:
    """Resolve the Material to render ``obj`` with.

    Prefers the Phase 3 ``metadata["material"]`` dict; falls back to
    the Phase 2 ``metadata["color"]`` convention (a plain RGB tuple)
    for scenes/objects created before materials existed, so nothing
    regresses. Objects with neither get the default material.
    """
    raw_material = obj.metadata.get("material")
    if isinstance(raw_material, dict):
        return Material.from_dict(raw_material)
    legacy_color = obj.metadata.get("color")
    if legacy_color is not None:
        return Material(base_color=tuple(legacy_color))
    return Material.default()


class OpenGLRenderer(RendererInterface):
    """Modern OpenGL (3.3 core) renderer for the MYA 3D Editor viewport.

    Renderer-specific state that is *not* part of the shared
    ``RendererInterface`` (see that module's docstring for why) is
    exposed as plain attributes the viewport sets before each frame:

        renderer.selected_ids = {"object-id-1", ...}
        renderer.grid_visible = True
    """

    def __init__(self) -> None:
        self._surface = None
        self._initialized = False
        self._width = 1
        self._height = 1

        self._basic_program: Optional[ShaderProgram] = None
        self._grid_program: Optional[ShaderProgram] = None
        self._picking_program: Optional[ShaderProgram] = None

        self._mesh_cache: Dict[str, MeshGPU] = {}
        self._texture_cache: Dict[str, Optional[TextureGPU]] = {}
        self._grid_lines: Optional[_LineGPU] = None
        self._gizmo_lines: Optional[DynamicLineGPU] = None

        self._picking_fbo: Optional[int] = None
        self._picking_color_tex: Optional[int] = None
        self._picking_depth_rb: Optional[int] = None
        self._picking_size: Tuple[int, int] = (0, 0)

        # Renderer state the viewport updates each frame / on demand.
        self.selected_ids: Set[str] = set()
        self.grid_visible: bool = True
        self.wireframe: bool = False
        self.light_direction = np.array([-0.45, -1.0, -0.35], dtype=np.float32)
        self.light_color = np.array([1.0, 1.0, 1.0], dtype=np.float32)

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    # ------------------------------------------------------------------
    # RendererInterface
    # ------------------------------------------------------------------
    def initialize(self, surface) -> None:
        if not _HAS_OPENGL:
            raise RendererInitError(
                "PyOpenGL is not installed. Install it with `pip install PyOpenGL` "
                "to enable the 3D viewport."
            )
        self._surface = surface

        try:
            self._basic_program = ShaderProgram.from_files(
                "basic", _SHADERS_DIR / "basic.vert", _SHADERS_DIR / "basic.frag"
            )
            self._grid_program = ShaderProgram.from_files(
                "grid", _SHADERS_DIR / "grid.vert", _SHADERS_DIR / "grid.frag"
            )
            self._picking_program = ShaderProgram.from_files(
                "picking", _SHADERS_DIR / "basic.vert", _SHADERS_DIR / "picking.frag"
            )
        except ShaderCompilationError as exc:
            logger.error("Shader compilation failed during renderer init: %s", exc)
            raise RendererInitError(str(exc)) from exc

        grid_vertices = _build_grid_and_axes_vertices()
        self._grid_lines = _LineGPU(grid_vertices)
        self._grid_lines.upload()

        gl.glEnable(gl.GL_DEPTH_TEST)
        gl.glDepthFunc(gl.GL_LESS)
        gl.glEnable(gl.GL_CULL_FACE)
        gl.glCullFace(gl.GL_BACK)
        gl.glClearColor(*_BACKGROUND_COLOR, 1.0)

        self._initialized = True
        logger.info("OpenGLRenderer initialized")

    def resize(self, width: int, height: int, default_framebuffer: int = 0) -> None:
        self._width = max(1, int(width))
        self._height = max(1, int(height))
        if not self._initialized:
            return
        gl.glViewport(0, 0, self._width, self._height)
        self._resize_picking_fbo(self._width, self._height, default_framebuffer)

    def render(self, scene: Scene, camera: EditorCamera, default_framebuffer: int = 0) -> None:
        """Render one frame of the scene.

        ``default_framebuffer`` must be the FBO id the host widget
        actually wants the final image drawn into. Under Qt,
        ``QOpenGLWidget`` does **not** render into system framebuffer 0
        -- it renders into its own internally-managed FBO, and the id
        of that FBO is exposed via ``QOpenGLWidget.defaultFramebufferObject()``.
        Hardcoding ``0`` here previously caused ``GL_INVALID_ENUM`` /
        rendered-nothing failures on real Qt contexts (this is
        documented Qt behavior, not a driver bug): the caller must
        pass the widget's actual default FBO id every frame, since Qt
        may recreate that FBO (e.g. on resize or a format change).
        This module stays Qt-independent -- it only takes a plain int,
        never a Qt object.
        """
        if not self._initialized:
            return

        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, default_framebuffer)
        gl.glViewport(0, 0, self._width, self._height)
        gl.glClearColor(*_BACKGROUND_COLOR, 1.0)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)
        gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_LINE if self.wireframe else gl.GL_FILL)

        view = camera.get_view_matrix()
        projection = camera.get_projection_matrix()

        if self.grid_visible and self._grid_lines is not None:
            self._draw_grid(view, projection)

        self._draw_meshes(scene, view, projection, camera)

        gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_FILL)

    def shutdown(self) -> None:
        """Release all GPU resources. Must be called with a valid/current
        GL context (the viewport calls this from its own context-aware
        cleanup, before the context is destroyed).
        """
        if not _HAS_OPENGL:
            self._initialized = False
            return
        for mesh_gpu in self._mesh_cache.values():
            mesh_gpu.release()
        self._mesh_cache.clear()

        for texture_gpu in self._texture_cache.values():
            if texture_gpu is not None:
                texture_gpu.release()
        self._texture_cache.clear()

        if self._grid_lines is not None:
            self._grid_lines.release()
            self._grid_lines = None

        if self._gizmo_lines is not None:
            self._gizmo_lines.release()
            self._gizmo_lines = None

        for program in (self._basic_program, self._grid_program, self._picking_program):
            if program is not None:
                program.release()
        self._basic_program = None
        self._grid_program = None
        self._picking_program = None

        self._release_picking_fbo()
        self._initialized = False
        logger.info("OpenGLRenderer shut down, GPU resources released")

    def get_local_radius(self, primitive_name: Optional[str]) -> float:
        """Approximate local-space bounding radius of a primitive mesh,
        used by ``ViewportGLWidget.frame_selected`` -- computed once
        from cached mesh data (not per-frame).
        """
        mesh_gpu = self._get_or_create_mesh_gpu(primitive_name)
        if mesh_gpu is None:
            return 1.0
        distances = np.linalg.norm(mesh_gpu.mesh_data.positions, axis=1)
        if distances.size == 0:
            return 1.0
        return float(distances.max())

    # ------------------------------------------------------------------
    # Mesh cache
    # ------------------------------------------------------------------
    def _get_or_create_mesh_gpu(self, primitive_name: Optional[str]) -> Optional[MeshGPU]:
        if not primitive_name:
            return None
        cached = self._mesh_cache.get(primitive_name)
        if cached is not None:
            return cached
        try:
            mesh_data: MeshData = generate_primitive(primitive_name)
            mesh_gpu = MeshGPU(mesh_data)
            mesh_gpu.upload()
        except (ValueError, RuntimeError) as exc:
            logger.error("Failed to build mesh for primitive '%s': %s", primitive_name, exc)
            return None
        self._mesh_cache[primitive_name] = mesh_gpu
        return mesh_gpu

    def _get_or_create_texture_gpu(self, texture_path: Optional[str]) -> Optional[TextureGPU]:
        """Look up (or lazily load + upload) a texture by file path.

        Failures (missing file, unreadable image, no Pillow) are
        logged once and cached as ``None`` so a bad texture path
        doesn't retry-and-fail every single frame -- the object then
        simply renders with its flat base color, never crashing the
        render loop over a missing/bad texture file.
        """
        if not texture_path:
            return None
        if texture_path in self._texture_cache:
            return self._texture_cache[texture_path]
        try:
            texture_data = TextureData.load(texture_path)
            texture_gpu = TextureGPU(texture_data)
            texture_gpu.upload()
        except (TextureLoadError, ValueError, RuntimeError) as exc:
            logger.error("Failed to load texture '%s': %s", texture_path, exc)
            self._texture_cache[texture_path] = None
            return None
        self._texture_cache[texture_path] = texture_gpu
        return texture_gpu

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------
    def _draw_grid(self, view: np.ndarray, projection: np.ndarray) -> None:
        self._grid_program.use()
        self._grid_program.set_mat4("u_view", view)
        self._grid_program.set_mat4("u_projection", projection)
        self._grid_lines.draw()
        ShaderProgram.unuse()

    def render_gizmo_lines(
        self, vertices: np.ndarray, view: np.ndarray, projection: np.ndarray
    ) -> None:
        """Draw transform-gizmo overlay lines on top of the scene.

        Reuses the grid shader (plain position+color line rendering --
        no need for a third shader for this). Depth testing is
        disabled for this one draw call so the gizmo is always visible
        on top of scene geometry, then restored immediately after,
        matching standard DCC-app gizmo rendering.
        """
        if not self._initialized or vertices.shape[0] == 0:
            return
        if self._gizmo_lines is None:
            self._gizmo_lines = DynamicLineGPU()
        self._gizmo_lines.update(vertices)

        gl.glDisable(gl.GL_DEPTH_TEST)
        self._grid_program.use()
        self._grid_program.set_mat4("u_view", view)
        self._grid_program.set_mat4("u_projection", projection)
        self._gizmo_lines.draw()
        ShaderProgram.unuse()
        gl.glEnable(gl.GL_DEPTH_TEST)

    def _draw_meshes(
        self, scene: Scene, view: np.ndarray, projection: np.ndarray, camera: EditorCamera
    ) -> None:
        self._basic_program.use()
        self._basic_program.set_mat4("u_view", view)
        self._basic_program.set_mat4("u_projection", projection)
        light_dir = math3d.normalize(self.light_direction)
        self._basic_program.set_vec3("u_light_direction", *light_dir.tolist())
        self._basic_program.set_vec3("u_light_color", *self.light_color.tolist())
        eye = camera.position()
        self._basic_program.set_vec3("u_camera_position", *eye.tolist())

        for obj in scene.all_objects():
            if obj.type != SceneObjectType.MESH or not obj.visible:
                continue
            primitive_name = obj.metadata.get("primitive")
            mesh_gpu = self._get_or_create_mesh_gpu(primitive_name)
            if mesh_gpu is None:
                continue

            model = math3d.model_matrix(
                obj.transform.position.as_tuple(),
                obj.transform.rotation.as_tuple(),
                obj.transform.scale.as_tuple(),
            )
            normal_matrix = _normal_matrix_from_model(model)

            material = _material_for_object(obj)
            texture_gpu = (
                self._get_or_create_texture_gpu(material.texture_path)
                if material.texture_path and mesh_gpu.has_uvs
                else None
            )

            self._basic_program.set_mat4("u_model", model)
            self._basic_program.set_mat3("u_normal_matrix", normal_matrix)
            self._basic_program.set_vec3("u_base_color", *material.base_color)
            self._basic_program.set_float("u_roughness", material.roughness)
            self._basic_program.set_float("u_metallic", material.metallic)
            self._basic_program.set_float(
                "u_selected", 1.0 if obj.id in self.selected_ids else 0.0
            )
            if texture_gpu is not None:
                texture_gpu.bind(unit=0)
                self._basic_program.set_int("u_base_texture", 0)
                self._basic_program.set_float("u_has_texture", 1.0)
            else:
                self._basic_program.set_float("u_has_texture", 0.0)
            mesh_gpu.draw()

        ShaderProgram.unuse()

    # ------------------------------------------------------------------
    # GPU color picking
    # ------------------------------------------------------------------
    def _resize_picking_fbo(self, width: int, height: int, default_framebuffer: int = 0) -> None:
        if self._picking_size == (width, height) and self._picking_fbo is not None:
            return
        self._release_picking_fbo()

        self._picking_fbo = gl.glGenFramebuffers(1)
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, self._picking_fbo)

        self._picking_color_tex = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self._picking_color_tex)
        gl.glTexImage2D(
            gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, width, height, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, None
        )
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_NEAREST)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_NEAREST)
        gl.glFramebufferTexture2D(
            gl.GL_FRAMEBUFFER, gl.GL_COLOR_ATTACHMENT0, gl.GL_TEXTURE_2D, self._picking_color_tex, 0
        )

        self._picking_depth_rb = gl.glGenRenderbuffers(1)
        gl.glBindRenderbuffer(gl.GL_RENDERBUFFER, self._picking_depth_rb)
        gl.glRenderbufferStorage(gl.GL_RENDERBUFFER, gl.GL_DEPTH_COMPONENT24, width, height)
        gl.glFramebufferRenderbuffer(
            gl.GL_FRAMEBUFFER, gl.GL_DEPTH_ATTACHMENT, gl.GL_RENDERBUFFER, self._picking_depth_rb
        )

        status = gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER)
        if status != gl.GL_FRAMEBUFFER_COMPLETE:
            logger.error("Picking framebuffer incomplete (status=%s); picking disabled", status)
            self._release_picking_fbo()
        else:
            self._picking_size = (width, height)

        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, default_framebuffer)

    def _release_picking_fbo(self) -> None:
        if not _HAS_OPENGL:
            self._picking_fbo = None
            self._picking_color_tex = None
            self._picking_depth_rb = None
            self._picking_size = (0, 0)
            return
        try:
            if self._picking_color_tex is not None:
                gl.glDeleteTextures([self._picking_color_tex])
            if self._picking_depth_rb is not None:
                gl.glDeleteRenderbuffers(1, [self._picking_depth_rb])
            if self._picking_fbo is not None:
                gl.glDeleteFramebuffers(1, [self._picking_fbo])
        except Exception:  # pragma: no cover - defensive
            logger.exception("Failed to release picking framebuffer")
        finally:
            self._picking_fbo = None
            self._picking_color_tex = None
            self._picking_depth_rb = None
            self._picking_size = (0, 0)

    def pick(
        self,
        screen_x: int,
        screen_y: int,
        scene: Scene,
        camera: EditorCamera,
        default_framebuffer: int = 0,
    ) -> Optional[str]:
        """Return the id of the mesh SceneObject under widget-local pixel
        (``screen_x``, ``screen_y``), or ``None`` if nothing was hit.

        ``screen_y`` is in Qt's top-down convention; this method handles
        the flip to OpenGL's bottom-up framebuffer convention internally.

        IMPORTANT: like ``render()``/``resize()``, this issues real GL
        calls and requires the caller's GL context to already be
        current. Unlike ``render()`` (always called from
        ``QOpenGLWidget.paintGL()``, where Qt guarantees this), ``pick()``
        is typically called from a mouse event handler -- Qt does
        **not** make the context current for those automatically. The
        Qt-specific fix (``self.makeCurrent()`` / ``self.doneCurrent()``)
        belongs in the caller (see ``ui/viewport.py::_perform_pick``),
        not here -- this module stays Qt-independent.
        """
        if not self._initialized or self._picking_fbo is None:
            return None
        if not (0 <= screen_x < self._width and 0 <= screen_y < self._height):
            return None

        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, self._picking_fbo)
        gl.glViewport(0, 0, self._width, self._height)
        gl.glClearColor(0.0, 0.0, 0.0, 1.0)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)

        view = camera.get_view_matrix()
        projection = camera.get_projection_matrix()

        id_map: Dict[int, str] = {}
        pixel_bytes = b""
        try:
            self._picking_program.use()
            self._picking_program.set_mat4("u_view", view)
            self._picking_program.set_mat4("u_projection", projection)

            pick_index = 1
            for obj in scene.all_objects():
                if obj.type != SceneObjectType.MESH or not obj.visible:
                    continue
                primitive_name = obj.metadata.get("primitive")
                mesh_gpu = self._get_or_create_mesh_gpu(primitive_name)
                if mesh_gpu is None:
                    continue

                model = math3d.model_matrix(
                    obj.transform.position.as_tuple(),
                    obj.transform.rotation.as_tuple(),
                    obj.transform.scale.as_tuple(),
                )
                self._picking_program.set_mat4("u_model", model)
                self._picking_program.set_mat3("u_normal_matrix", _normal_matrix_from_model(model))
                self._picking_program.set_vec3("u_pick_color", *_encode_pick_id(pick_index))
                mesh_gpu.draw()

                id_map[pick_index] = obj.id
                pick_index += 1

            gl_y = self._height - 1 - screen_y
            pixel = gl.glReadPixels(screen_x, gl_y, 1, 1, gl.GL_RGB, gl.GL_UNSIGNED_BYTE)
            pixel_bytes = bytes(pixel) if not isinstance(pixel, (bytes, bytearray)) else pixel
        finally:
            # Always restore GL state -- even if a draw call above
            # raises (e.g. GL_INVALID_OPERATION from a context/driver
            # issue) -- so a failed pick can never leave the picking
            # FBO/shader permanently bound and corrupt the next frame's
            # normal render. See ui/viewport.py::_perform_pick for the
            # matching requirement that the GL context is actually
            # current before this method is ever called at all.
            ShaderProgram.unuse()
            gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, default_framebuffer)

        if len(pixel_bytes) < 3:
            return None
        decoded = _decode_pick_id((pixel_bytes[0], pixel_bytes[1], pixel_bytes[2]))
        if decoded == 0:
            return None
        return id_map.get(decoded)
