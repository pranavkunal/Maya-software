"""Basic 2D image texture support (Phase 3 scope only).

Split into two pieces, matching the ``MeshData``/``MeshGPU`` pattern:

    TextureData  -- loads a PNG/JPEG file with Pillow and holds plain
                    RGBA pixel bytes + dimensions. No OpenGL
                    dependency; fully unit-testable without a GPU.
    TextureGPU   -- uploads a ``TextureData`` to an OpenGL texture
                    object once, binds it to a texture unit, and
                    releases it. Only this class touches PyOpenGL.

No UDIM, no texture painting, no node-based materials -- one image,
one GPU texture, bound to texture unit 0 for the basic shader's
optional base-color texture sample.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Union

logger = logging.getLogger(__name__)

try:  # Pillow may not be installed in headless/CI/dev environments.
    from PIL import Image
    _HAS_PIL = True
except ImportError:  # pragma: no cover - exercised only when Pillow is absent
    Image = None  # type: ignore
    _HAS_PIL = False

try:  # PyOpenGL may not be installed either.
    from OpenGL import GL as gl  # type: ignore
    _HAS_OPENGL = True
except ImportError:  # pragma: no cover
    gl = None  # type: ignore
    _HAS_OPENGL = False

SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg")


class TextureLoadError(Exception):
    """Raised when a texture image cannot be found, read, or decoded."""


class TextureData:
    """CPU-side decoded image: RGBA8 pixel bytes + dimensions.

    Attributes:
        width: Image width in pixels.
        height: Image height in pixels.
        pixels: Raw RGBA8 bytes, row-major, top-to-bottom (Pillow's
            native order -- flipped to bottom-up at GPU-upload time,
            matching OpenGL's texture coordinate convention).
        source_path: The path this texture was loaded from, kept for
            re-upload after a context loss and for serialization.
    """

    def __init__(self, width: int, height: int, pixels: bytes, source_path: Optional[str] = None) -> None:
        self.width = width
        self.height = height
        self.pixels = pixels
        self.source_path = source_path

    def is_valid(self) -> bool:
        return self.width > 0 and self.height > 0 and len(self.pixels) == self.width * self.height * 4

    @classmethod
    def load(cls, path: Union[str, Path]) -> "TextureData":
        """Load a PNG/JPEG image from disk as RGBA8.

        Raises:
            TextureLoadError: if Pillow isn't installed, the file is
                missing, or the file can't be decoded as an image.
        """
        if not _HAS_PIL:
            raise TextureLoadError(
                "Pillow is not installed; cannot load textures. Install it with `pip install Pillow`."
            )
        path = Path(path)
        if not path.exists():
            raise TextureLoadError(f"Texture file does not exist: {path}")
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            logger.warning("Texture file has an unusual extension: %s", path)
        try:
            with Image.open(path) as img:
                rgba = img.convert("RGBA")
                width, height = rgba.size
                pixels = rgba.tobytes()
        except Exception as exc:  # Pillow raises various error types per format
            raise TextureLoadError(f"Could not decode texture image '{path}': {exc}") from exc

        return cls(width=width, height=height, pixels=pixels, source_path=str(path))


class TextureGPU:
    """Owns a single GPU texture object for one ``TextureData``.

    Usage:
        tex_gpu = TextureGPU(texture_data)
        tex_gpu.upload()        # once, inside a valid GL context
        ...
        tex_gpu.bind(unit=0)    # every frame that uses it
        ...
        tex_gpu.release()       # on shutdown / context loss
    """

    def __init__(self, texture_data: TextureData) -> None:
        self.texture_data = texture_data
        self._texture_id: Optional[int] = None
        self._uploaded = False

    @property
    def is_uploaded(self) -> bool:
        return self._uploaded

    def upload(self) -> None:
        if not _HAS_OPENGL:
            raise RuntimeError(
                "PyOpenGL is not installed; cannot upload texture. Install it with `pip install PyOpenGL`."
            )
        if self._uploaded:
            return
        if not self.texture_data.is_valid():
            raise ValueError("Cannot upload invalid/empty TextureData to the GPU")

        # Pillow decodes top-to-bottom; OpenGL's default texture
        # coordinate origin is bottom-left, so flip rows at upload time
        # rather than baking a flip into every mesh's UVs.
        flipped = _flip_rows(
            self.texture_data.pixels, self.texture_data.width, self.texture_data.height
        )

        self._texture_id = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self._texture_id)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_S, gl.GL_REPEAT)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_T, gl.GL_REPEAT)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glTexImage2D(
            gl.GL_TEXTURE_2D,
            0,
            gl.GL_RGBA8,
            self.texture_data.width,
            self.texture_data.height,
            0,
            gl.GL_RGBA,
            gl.GL_UNSIGNED_BYTE,
            flipped,
        )
        gl.glGenerateMipmap(gl.GL_TEXTURE_2D)
        gl.glBindTexture(gl.GL_TEXTURE_2D, 0)

        self._uploaded = True
        logger.debug(
            "Uploaded texture: %dx%d from %s",
            self.texture_data.width,
            self.texture_data.height,
            self.texture_data.source_path,
        )

    def bind(self, unit: int = 0) -> None:
        if not self._uploaded or self._texture_id is None:
            return
        gl.glActiveTexture(gl.GL_TEXTURE0 + unit)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self._texture_id)

    def release(self) -> None:
        """Release the GPU texture. Safe to call multiple times; must
        be called with a valid/current GL context.
        """
        if not _HAS_OPENGL or not self._uploaded:
            self._uploaded = False
            return
        try:
            if self._texture_id is not None:
                gl.glDeleteTextures([self._texture_id])
        except Exception:  # pragma: no cover - defensive; context may already be gone
            logger.exception("Failed to release TextureGPU resources cleanly")
        finally:
            self._texture_id = None
            self._uploaded = False


def _flip_rows(pixels: bytes, width: int, height: int, channels: int = 4) -> bytes:
    """Flip image rows top-to-bottom -> bottom-to-top for OpenGL upload."""
    row_size = width * channels
    rows = [pixels[i * row_size : (i + 1) * row_size] for i in range(height)]
    return b"".join(reversed(rows))
