"""GPU-side dynamic line buffer for transform-gizmo rendering.

Unlike the static grid/axis lines (``_LineGPU`` in
``graphics/opengl_renderer.py``, uploaded once and never touched
again), the gizmo's line geometry changes every frame it's visible --
it follows the selected object and highlights whichever axis is being
dragged. ``DynamicLineGPU`` therefore creates its VAO/VBO **once**
(satisfying "do not create GPU buffers every frame") and re-uploads
just the buffer *contents* via ``glBufferData`` with
``GL_DYNAMIC_DRAW`` each time ``update()`` is called -- the buffer
object itself is never deleted/recreated between frames.
"""
from __future__ import annotations

import ctypes
import logging
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

try:
    from OpenGL import GL as gl  # type: ignore
    _HAS_OPENGL = True
except ImportError:  # pragma: no cover
    gl = None  # type: ignore
    _HAS_OPENGL = False


class DynamicLineGPU:
    """A ``GL_LINES`` buffer of interleaved ``[pos.xyz, color.rgb]``
    vertices whose contents can be replaced every frame without
    recreating the underlying VAO/VBO.
    """

    _STRIDE_FLOATS = 6

    def __init__(self) -> None:
        self._vao: Optional[int] = None
        self._vbo: Optional[int] = None
        self._capacity_bytes = 0
        self._vertex_count = 0
        self._created = False

    @property
    def vertex_count(self) -> int:
        return self._vertex_count

    def _ensure_created(self) -> None:
        if self._created:
            return
        if not _HAS_OPENGL:
            raise RuntimeError("PyOpenGL is not installed; cannot create gizmo line buffer")

        self._vao = gl.glGenVertexArrays(1)
        gl.glBindVertexArray(self._vao)

        self._vbo = gl.glGenBuffers(1)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self._vbo)

        stride = self._STRIDE_FLOATS * 4
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(1)
        gl.glVertexAttribPointer(1, 3, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(3 * 4))

        gl.glBindVertexArray(0)
        self._created = True

    def update(self, vertices: np.ndarray) -> None:
        """Replace the buffer's contents with ``vertices`` (an (N, 6)
        float32 array). Grows the underlying GPU allocation only when
        the new data is larger than the current capacity.
        """
        self._ensure_created()
        data = np.ascontiguousarray(vertices, dtype=np.float32)
        self._vertex_count = data.shape[0]

        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self._vbo)
        if data.nbytes > self._capacity_bytes:
            gl.glBufferData(gl.GL_ARRAY_BUFFER, data.nbytes, data, gl.GL_DYNAMIC_DRAW)
            self._capacity_bytes = data.nbytes
        elif data.nbytes > 0:
            gl.glBufferSubData(gl.GL_ARRAY_BUFFER, 0, data.nbytes, data)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)

    def draw(self) -> None:
        if not self._created or self._vertex_count == 0:
            return
        gl.glBindVertexArray(self._vao)
        gl.glDrawArrays(gl.GL_LINES, 0, self._vertex_count)
        gl.glBindVertexArray(0)

    def release(self) -> None:
        if not _HAS_OPENGL or not self._created:
            self._created = False
            return
        try:
            if self._vbo is not None:
                gl.glDeleteBuffers(1, [self._vbo])
            if self._vao is not None:
                gl.glDeleteVertexArrays(1, [self._vao])
        except Exception:  # pragma: no cover - defensive
            logger.exception("Failed to release gizmo line buffer")
        finally:
            self._vao = None
            self._vbo = None
            self._capacity_bytes = 0
            self._vertex_count = 0
            self._created = False
