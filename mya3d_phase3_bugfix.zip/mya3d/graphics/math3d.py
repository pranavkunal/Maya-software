"""Reusable 3D math helpers: matrices and vectors, built on NumPy.

Coordinate convention (documented here as the single source of truth --
see also README.md "Coordinate Convention" section):

    * Right-handed coordinate system.
    * X = left(-) / right(+)
    * Y = down(-) / up(+)      (Y is the "up" axis)
    * Z = out of screen towards viewer (+) / into screen (-), i.e.
      "depth" -- the camera looks down its own local -Z axis, matching
      standard OpenGL/right-handed camera convention.
    * Units are arbitrary "scene units" (treat as meters by convention).
    * Rotations are stored on ``Transform`` as Euler angles in DEGREES,
      applied in X, then Y, then Z order (i.e. the model matrix is
      ``T @ Rz @ Ry @ Rx @ S``, matrix-multiplied against column
      vectors: ``v' = M @ v``).

All matrices returned by this module are 4x4 ``numpy.ndarray`` of
dtype float32, laid out for **column-vector** math (``M @ v``), i.e.
the same convention used throughout classic OpenGL literature. When
uploading to a shader with ``glUniformMatrix4fv``, callers pass
``transpose=GL_TRUE`` because NumPy stores arrays row-major while
GLSL's default expects column-major storage; transposing at upload
time reconciles the two without changing any of the math below.
"""
from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np

Vec3 = Tuple[float, float, float]


def identity4() -> np.ndarray:
    """Return a 4x4 identity matrix."""
    return np.identity(4, dtype=np.float32)


def translation_matrix(x: float, y: float, z: float) -> np.ndarray:
    """Return a 4x4 translation matrix for column-vector math."""
    m = np.identity(4, dtype=np.float32)
    m[0, 3] = x
    m[1, 3] = y
    m[2, 3] = z
    return m


def scale_matrix(x: float, y: float, z: float) -> np.ndarray:
    """Return a 4x4 non-uniform scale matrix."""
    m = np.identity(4, dtype=np.float32)
    m[0, 0] = x
    m[1, 1] = y
    m[2, 2] = z
    return m


def rotation_matrix_x(degrees: float) -> np.ndarray:
    """Rotation about the X axis (degrees), right-handed."""
    a = math.radians(degrees)
    c, s = math.cos(a), math.sin(a)
    m = np.identity(4, dtype=np.float32)
    m[1, 1] = c
    m[1, 2] = -s
    m[2, 1] = s
    m[2, 2] = c
    return m


def rotation_matrix_y(degrees: float) -> np.ndarray:
    """Rotation about the Y axis (degrees), right-handed."""
    a = math.radians(degrees)
    c, s = math.cos(a), math.sin(a)
    m = np.identity(4, dtype=np.float32)
    m[0, 0] = c
    m[0, 2] = s
    m[2, 0] = -s
    m[2, 2] = c
    return m


def rotation_matrix_z(degrees: float) -> np.ndarray:
    """Rotation about the Z axis (degrees), right-handed."""
    a = math.radians(degrees)
    c, s = math.cos(a), math.sin(a)
    m = np.identity(4, dtype=np.float32)
    m[0, 0] = c
    m[0, 1] = -s
    m[1, 0] = s
    m[1, 1] = c
    return m


def rotation_matrix_euler_xyz(x_deg: float, y_deg: float, z_deg: float) -> np.ndarray:
    """Combined Euler rotation matrix, applied X then Y then Z.

    i.e. ``R = Rz @ Ry @ Rx`` so that, for a column vector ``v``, the
    X rotation is applied first, matching the order documented at the
    top of this module and used consistently by ``model_matrix``.
    """
    return rotation_matrix_z(z_deg) @ rotation_matrix_y(y_deg) @ rotation_matrix_x(x_deg)


def model_matrix(
    position: Vec3,
    rotation_degrees: Vec3,
    scale: Vec3,
) -> np.ndarray:
    """Build a model (object-to-world) matrix from Transform-style data.

    Order: ``M = T @ R @ S`` (scale first, then rotate, then translate),
    the standard TRS composition for column-vector math.
    """
    t = translation_matrix(*position)
    r = rotation_matrix_euler_xyz(*rotation_degrees)
    s = scale_matrix(*scale)
    return (t @ r @ s).astype(np.float32)


def normalize(v: np.ndarray) -> np.ndarray:
    """Return a unit-length copy of ``v``; a zero vector is returned unchanged."""
    length = float(np.linalg.norm(v))
    if length < 1e-8:
        return v.astype(np.float32)
    return (v / length).astype(np.float32)


def look_at_matrix(eye: Vec3, target: Vec3, up: Vec3) -> np.ndarray:
    """Right-handed view matrix (world-to-camera), OpenGL convention.

    The camera looks down its local -Z axis; +X is "camera right", +Y
    is "camera up", matching the module-level coordinate convention.
    """
    eye_v = np.array(eye, dtype=np.float32)
    target_v = np.array(target, dtype=np.float32)
    up_v = np.array(up, dtype=np.float32)

    forward = normalize(eye_v - target_v)  # camera's local +Z (points *away* from target)
    if float(np.linalg.norm(np.cross(up_v, forward))) < 1e-6:
        # `up` is (nearly) parallel to the view direction -- nudge it
        # to avoid a degenerate basis (camera looking straight up/down).
        up_v = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    right = normalize(np.cross(up_v, forward))
    true_up = np.cross(forward, right)

    rotation = np.identity(4, dtype=np.float32)
    rotation[0, 0:3] = right
    rotation[1, 0:3] = true_up
    rotation[2, 0:3] = forward

    translation = np.identity(4, dtype=np.float32)
    translation[0, 3] = -eye_v[0]
    translation[1, 3] = -eye_v[1]
    translation[2, 3] = -eye_v[2]

    return (rotation @ translation).astype(np.float32)


def perspective_matrix(
    fov_y_degrees: float,
    aspect_ratio: float,
    near: float,
    far: float,
) -> np.ndarray:
    """Right-handed OpenGL perspective projection matrix (NDC z in [-1, 1])."""
    if aspect_ratio <= 0:
        aspect_ratio = 1.0
    fov_y = math.radians(fov_y_degrees)
    f = 1.0 / math.tan(fov_y / 2.0)
    m = np.zeros((4, 4), dtype=np.float32)
    m[0, 0] = f / aspect_ratio
    m[1, 1] = f
    m[2, 2] = (far + near) / (near - far)
    m[2, 3] = (2.0 * far * near) / (near - far)
    m[3, 2] = -1.0
    return m


def orthographic_matrix(
    left: float,
    right: float,
    bottom: float,
    top: float,
    near: float,
    far: float,
) -> np.ndarray:
    """Right-handed OpenGL orthographic projection matrix (NDC z in [-1, 1]).

    Used for the true Front/Back/Left/Right/Top/Bottom orthographic
    viewport modes (Phase 3) -- a real projection matrix, not a
    perspective camera pushed far away.
    """
    if right == left:
        right = left + 1.0
    if top == bottom:
        top = bottom + 1.0
    if far == near:
        far = near + 1.0
    m = np.identity(4, dtype=np.float32)
    m[0, 0] = 2.0 / (right - left)
    m[1, 1] = 2.0 / (top - bottom)
    m[2, 2] = -2.0 / (far - near)
    m[0, 3] = -(right + left) / (right - left)
    m[1, 3] = -(top + bottom) / (top - bottom)
    m[2, 3] = -(far + near) / (far - near)
    return m


def orthographic_matrix_from_height(
    view_height: float, aspect_ratio: float, near: float, far: float
) -> np.ndarray:
    """Convenience wrapper: build a symmetric orthographic frustum from
    a vertical "view height" (world units) and aspect ratio, matching
    how an editor's ortho zoom is usually expressed.
    """
    if aspect_ratio <= 0:
        aspect_ratio = 1.0
    half_height = max(view_height, 1e-4) / 2.0
    half_width = half_height * aspect_ratio
    return orthographic_matrix(-half_width, half_width, -half_height, half_height, near, far)


def transform_point(matrix: np.ndarray, point: Vec3) -> np.ndarray:
    """Transform a 3D point (w=1) by a 4x4 matrix, returning xyz."""
    v = np.array([point[0], point[1], point[2], 1.0], dtype=np.float32)
    result = matrix @ v
    return result[:3]


def screen_to_ndc(pixel_x: float, pixel_y: float, width: int, height: int) -> Tuple[float, float]:
    """Convert top-left-origin pixel coordinates (Qt convention) to
    OpenGL normalized device coordinates in [-1, 1], Y flipped so +Y is up.
    """
    width = max(1, width)
    height = max(1, height)
    ndc_x = (2.0 * pixel_x / width) - 1.0
    ndc_y = 1.0 - (2.0 * pixel_y / height)
    return ndc_x, ndc_y


def unproject_ray(
    ndc_x: float, ndc_y: float, view: np.ndarray, projection: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Cast a world-space ray from the camera through NDC point (x, y).

    Returns ``(ray_origin, ray_direction)`` where ``ray_direction`` is
    unit length. Used for viewport picking-adjacent math (e.g.
    ray/plane intersection while dragging an object).
    """
    inv_vp = np.linalg.inv(projection @ view)

    near_clip = np.array([ndc_x, ndc_y, -1.0, 1.0], dtype=np.float32)
    far_clip = np.array([ndc_x, ndc_y, 1.0, 1.0], dtype=np.float32)

    near_world = inv_vp @ near_clip
    far_world = inv_vp @ far_clip
    near_world = near_world[:3] / near_world[3]
    far_world = far_world[:3] / far_world[3]

    origin = near_world.astype(np.float32)
    direction = normalize((far_world - near_world).astype(np.float32))
    return origin, direction


def ray_plane_intersection(
    ray_origin: np.ndarray,
    ray_direction: np.ndarray,
    plane_point: np.ndarray,
    plane_normal: np.ndarray,
) -> Optional[np.ndarray]:
    """Intersect a ray with a plane; returns the world-space hit point,
    or ``None`` if the ray is (near-)parallel to the plane.
    """
    denom = float(np.dot(plane_normal, ray_direction))
    if abs(denom) < 1e-6:
        return None
    t = float(np.dot(plane_point - ray_origin, plane_normal)) / denom
    if t < 0:
        return None
    return (ray_origin + ray_direction * t).astype(np.float32)


def closest_point_on_line_to_ray(
    line_point: np.ndarray,
    line_direction: np.ndarray,
    ray_origin: np.ndarray,
    ray_direction: np.ndarray,
) -> np.ndarray:
    """Closest point on an infinite 3D line to a ray (skew-line closest
    point). Used by the move/scale gizmos to figure out where along a
    single world axis the user's mouse ray is "pointing", which is the
    standard technique for dragging along a 3D axis handle with a 2D
    mouse (a literal ray/axis intersection almost never exists).
    """
    line_dir = normalize(line_direction)
    ray_dir = normalize(ray_direction)

    w0 = line_point - ray_origin
    a = float(np.dot(line_dir, line_dir))
    b = float(np.dot(line_dir, ray_dir))
    c = float(np.dot(ray_dir, ray_dir))
    d = float(np.dot(line_dir, w0))
    e = float(np.dot(ray_dir, w0))
    denom = a * c - b * b

    if abs(denom) < 1e-8:
        # Nearly parallel: any point on the line is equally valid: pick
        # the projection of the ray origin onto the line.
        t_line = d / a if abs(a) > 1e-8 else 0.0
    else:
        t_line = (b * e - c * d) / denom

    return (line_point + line_dir * t_line).astype(np.float32)


def angle_around_axis(
    point: np.ndarray, center: np.ndarray, axis: np.ndarray, reference: np.ndarray
) -> float:
    """Signed angle (degrees) of ``point`` around ``axis`` (through
    ``center``), measured from the ``reference`` direction using the
    right-hand rule. Used by the rotate gizmo: the hit point on the
    ring's plane is converted to an angle, and rotation deltas are
    just differences of this angle between mouse-move events.
    """
    axis_n = normalize(axis)
    ref_n = normalize(reference - axis_n * float(np.dot(reference, axis_n)))
    if float(np.linalg.norm(ref_n)) < 1e-6:
        return 0.0
    side = np.cross(axis_n, ref_n)

    to_point = point - center
    to_point = to_point - axis_n * float(np.dot(to_point, axis_n))
    if float(np.linalg.norm(to_point)) < 1e-6:
        return 0.0
    to_point_n = normalize(to_point)

    cos_a = float(np.clip(np.dot(ref_n, to_point_n), -1.0, 1.0))
    sin_a = float(np.dot(side, to_point_n))
    return math.degrees(math.atan2(sin_a, cos_a))
