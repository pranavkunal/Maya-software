"""Gizmo hit-testing math: mouse ray vs. gizmo handle geometry.

Kept separate from ``graphics/math3d.py`` (generic 3D math, reusable
outside gizmos) and from ``graphics/gizmo.py``/``transform_gizmo.py``
(gizmo rendering + interaction state) so the actual hit-testing
formulas are isolated, framework-independent, and unit-testable
without a GPU or Qt.

Axis colors/handle lengths are visual concerns and live in
``graphics/transform_gizmo.py``; this module only answers "given a
mouse ray and the gizmo's world transform, what did the user hit (if
anything), and how far/what angle did they drag".
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from graphics import math3d

#: World-space unit axis directions, indexed by axis name -- the
#: gizmo's axes align with world axes in Phase 3 ("world" mode only;
#: a "local" mode could pass the object's rotated axes instead without
#: changing this module's API).
AXIS_DIRECTIONS = {
    "X": np.array([1.0, 0.0, 0.0], dtype=np.float32),
    "Y": np.array([0.0, 1.0, 0.0], dtype=np.float32),
    "Z": np.array([0.0, 0.0, 1.0], dtype=np.float32),
}

AXIS_NAMES = ("X", "Y", "Z")


@dataclass
class AxisHitTestResult:
    axis: str
    closest_point: np.ndarray
    distance_to_ray: float


def pick_move_or_scale_axis(
    gizmo_center: np.ndarray,
    handle_length: float,
    ray_origin: np.ndarray,
    ray_direction: np.ndarray,
    pick_tolerance: float = 0.12,
) -> Optional[AxisHitTestResult]:
    """Return which axis handle (if any) the mouse ray is closest to.

    ``pick_tolerance`` is a fraction of ``handle_length`` used as the
    world-space distance threshold, so picking stays proportionally
    forgiving regardless of the gizmo's world-space size.
    """
    best: Optional[AxisHitTestResult] = None
    tolerance = handle_length * pick_tolerance

    for axis_name in AXIS_NAMES:
        axis_dir = AXIS_DIRECTIONS[axis_name]
        closest = math3d.closest_point_on_line_to_ray(
            gizmo_center, axis_dir, ray_origin, ray_direction
        )
        t_along_axis = float(np.dot(closest - gizmo_center, axis_dir))
        if t_along_axis < 0 or t_along_axis > handle_length:
            continue

        to_closest = closest - ray_origin
        proj_len = float(np.dot(to_closest, ray_direction))
        proj_point = ray_origin + ray_direction * max(proj_len, 0.0)
        distance = float(np.linalg.norm(closest - proj_point))

        if distance <= tolerance and (best is None or distance < best.distance_to_ray):
            best = AxisHitTestResult(axis=axis_name, closest_point=closest, distance_to_ray=distance)

    return best


def pick_rotation_ring(
    gizmo_center: np.ndarray,
    ring_radius: float,
    ray_origin: np.ndarray,
    ray_direction: np.ndarray,
    pick_tolerance: float = 0.15,
) -> Optional[str]:
    """Return which rotation ring (if any) the mouse ray hits.

    Each ring lies in the plane perpendicular to its axis, through the
    gizmo center. The ray is intersected with that plane; a hit counts
    if the intersection point lands within ``pick_tolerance`` (fraction
    of ``ring_radius``) of the ring's radius.
    """
    best_axis: Optional[str] = None
    best_error = None
    tolerance = ring_radius * pick_tolerance

    for axis_name in AXIS_NAMES:
        axis_dir = AXIS_DIRECTIONS[axis_name]
        hit = math3d.ray_plane_intersection(ray_origin, ray_direction, gizmo_center, axis_dir)
        if hit is None:
            continue
        radial_distance = float(np.linalg.norm(hit - gizmo_center))
        error = abs(radial_distance - ring_radius)
        if error <= tolerance and (best_error is None or error < best_error):
            best_axis = axis_name
            best_error = error

    return best_axis


def ray_hits_uniform_scale_handle(
    gizmo_center: np.ndarray,
    handle_radius: float,
    ray_origin: np.ndarray,
    ray_direction: np.ndarray,
) -> bool:
    """Simple ray/sphere test for the small center "uniform scale" handle."""
    to_center = gizmo_center - ray_origin
    t = float(np.dot(to_center, ray_direction))
    if t < 0:
        return False
    closest = ray_origin + ray_direction * t
    return float(np.linalg.norm(closest - gizmo_center)) <= handle_radius


def move_delta_along_axis(
    gizmo_center: np.ndarray,
    axis_name: str,
    start_ray: Tuple[np.ndarray, np.ndarray],
    current_ray: Tuple[np.ndarray, np.ndarray],
) -> float:
    """Signed distance (world units) to move along ``axis_name`` between
    the drag-start mouse ray and the current mouse ray.
    """
    axis_dir = AXIS_DIRECTIONS[axis_name]
    start_point = math3d.closest_point_on_line_to_ray(gizmo_center, axis_dir, *start_ray)
    current_point = math3d.closest_point_on_line_to_ray(gizmo_center, axis_dir, *current_ray)
    return float(np.dot(current_point - start_point, axis_dir))


def rotation_delta_degrees(
    gizmo_center: np.ndarray,
    axis_name: str,
    start_ray: Tuple[np.ndarray, np.ndarray],
    current_ray: Tuple[np.ndarray, np.ndarray],
    reference: np.ndarray,
) -> float:
    """Signed rotation delta (degrees) around ``axis_name`` between the
    drag-start and current mouse rays, both projected onto the ring's plane.
    """
    axis_dir = AXIS_DIRECTIONS[axis_name]
    start_hit = math3d.ray_plane_intersection(*start_ray, gizmo_center, axis_dir)
    current_hit = math3d.ray_plane_intersection(*current_ray, gizmo_center, axis_dir)
    if start_hit is None or current_hit is None:
        return 0.0
    start_angle = math3d.angle_around_axis(start_hit, gizmo_center, axis_dir, reference)
    current_angle = math3d.angle_around_axis(current_hit, gizmo_center, axis_dir, reference)
    delta = current_angle - start_angle
    while delta > 180.0:
        delta -= 360.0
    while delta <= -180.0:
        delta += 360.0
    return delta
