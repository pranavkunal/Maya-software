"""CPU-side geometry for the Move/Rotate/Scale transform gizmos.

Pure NumPy, no OpenGL/Qt dependency -- fully unit-testable. Each
builder returns an (N, 6) float32 array of interleaved
``[pos.xyz, color.rgb]`` line-list vertices (drawn with ``GL_LINES``),
matching the existing grid/axis line format in
``graphics/opengl_renderer.py`` so the same line-shader/draw path can
render them (see ``graphics/transform_gizmo.py``).

All geometry is generated in **world space** directly from the
gizmo's center (the selected object's world position) and a world-
space size, recomputed every time the selection/camera changes -- this
is intentionally cheap CPU work (a few dozen line segments), not
comparable to rebuilding real mesh geometry, and is the norm for
gizmo overlays in real-time editors.
"""
from __future__ import annotations

import math
from typing import List, Optional, Tuple

import numpy as np

AXIS_COLORS = {
    "X": (0.90, 0.25, 0.25),
    "Y": (0.30, 0.80, 0.30),
    "Z": (0.30, 0.50, 0.95),
}
_HIGHLIGHT_COLOR = (1.0, 0.85, 0.15)

Vec3 = Tuple[float, float, float]


def _axis_vector(axis: str) -> np.ndarray:
    return {
        "X": np.array([1.0, 0.0, 0.0]),
        "Y": np.array([0.0, 1.0, 0.0]),
        "Z": np.array([0.0, 0.0, 1.0]),
    }[axis]


def build_move_gizmo_lines(
    center: Vec3, handle_length: float, active_axis: Optional[str] = None
) -> np.ndarray:
    """Three axis lines from ``center`` out to ``handle_length``, plus a
    small arrowhead cross at the tip. The currently-hovered/dragged
    axis (``active_axis``) is drawn highlighted.
    """
    center_v = np.array(center, dtype=np.float64)
    lines: List[Tuple[float, float, float, float, float, float]] = []

    for axis in ("X", "Y", "Z"):
        color = _HIGHLIGHT_COLOR if axis == active_axis else AXIS_COLORS[axis]
        direction = _axis_vector(axis)
        tip = center_v + direction * handle_length
        lines.append((*center_v.tolist(), *color))
        lines.append((*tip.tolist(), *color))

        # Small arrowhead: two short cross-ticks near the tip.
        perp = np.roll(direction, 1) * (handle_length * 0.08)
        head_base = center_v + direction * (handle_length * 0.85)
        lines.append((*(head_base + perp).tolist(), *color))
        lines.append((*tip.tolist(), *color))
        lines.append((*(head_base - perp).tolist(), *color))
        lines.append((*tip.tolist(), *color))

    return np.array(lines, dtype=np.float32)


def build_scale_gizmo_lines(
    center: Vec3, handle_length: float, active_axis: Optional[str] = None
) -> np.ndarray:
    """Three axis lines ending in a small box (cube outline) handle,
    plus a small center cross marking the uniform-scale handle.
    """
    center_v = np.array(center, dtype=np.float64)
    lines: List[Tuple[float, float, float, float, float, float]] = []
    box_half = handle_length * 0.06

    for axis in ("X", "Y", "Z"):
        color = _HIGHLIGHT_COLOR if axis == active_axis else AXIS_COLORS[axis]
        direction = _axis_vector(axis)
        tip = center_v + direction * handle_length
        lines.append((*center_v.tolist(), *color))
        lines.append((*tip.tolist(), *color))

        # Tiny box outline at the tip (axis-aligned, cheap approximation
        # of a cube handle -- good enough at gizmo scale).
        for perp_axis in ("X", "Y", "Z"):
            if perp_axis == axis:
                continue
            perp = _axis_vector(perp_axis) * box_half
            lines.append((*(tip - perp).tolist(), *color))
            lines.append((*(tip + perp).tolist(), *color))

    uniform_color = _HIGHLIGHT_COLOR if active_axis == "XYZ" else (0.85, 0.85, 0.85)
    s = handle_length * 0.09
    for perp_axis in ("X", "Y", "Z"):
        perp = _axis_vector(perp_axis) * s
        lines.append((*(center_v - perp).tolist(), *uniform_color))
        lines.append((*(center_v + perp).tolist(), *uniform_color))

    return np.array(lines, dtype=np.float32)


def build_rotate_gizmo_lines(
    center: Vec3, radius: float, active_axis: Optional[str] = None, segments: int = 48
) -> np.ndarray:
    """Three circular rings (approximated as line segments), one per axis."""
    center_v = np.array(center, dtype=np.float64)
    lines: List[Tuple[float, float, float, float, float, float]] = []

    ring_basis = {
        "X": (np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])),  # ring in Y/Z plane
        "Y": (np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])),  # ring in X/Z plane
        "Z": (np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])),  # ring in X/Y plane
    }

    for axis in ("X", "Y", "Z"):
        color = _HIGHLIGHT_COLOR if axis == active_axis else AXIS_COLORS[axis]
        u, v = ring_basis[axis]
        prev_point = None
        for i in range(segments + 1):
            angle = (i / segments) * 2.0 * math.pi
            point = center_v + (u * math.cos(angle) + v * math.sin(angle)) * radius
            if prev_point is not None:
                lines.append((*prev_point.tolist(), *color))
                lines.append((*point.tolist(), *color))
            prev_point = point

    return np.array(lines, dtype=np.float32)
