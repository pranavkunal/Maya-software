"""A 3D editor ("orbit") camera, plus a lightweight scene-camera view helper.

This module provides two distinct things, per the Phase 3 spec's
explicit requirement to never conflate them:

    EditorCamera      -- the **editor camera** used to navigate the
                          viewport. Purely a UI navigation aid, like
                          the viewport camera in any DCC application.
                          Never serialized into the ``.mya`` scene
                          file, and has no ``SceneObject`` of its own.

    SceneCameraSettings /
    scene_camera_view_matrix() /
    scene_camera_projection_matrix()
                       -- pure functions/data for computing view and
                          projection matrices for a ``Camera``-type
                          ``SceneObject`` (a real, animatable,
                          selectable scene object with its own
                          Transform). Used when the viewport is
                          switched to "look through" a scene camera
                          (see ``ui/viewport.py`` /
                          "Look Through Selected Camera").

Implemented as an orbit camera: position is derived from a target
point, a distance, and yaw/pitch angles, which makes orbit/pan/zoom
navigation simple and keeps the camera from ever flipping upside down
(pitch is clamped).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Tuple

import numpy as np

from graphics import math3d

Vec3 = Tuple[float, float, float]

_MIN_PITCH_DEG = -89.0
_MAX_PITCH_DEG = 89.0
_MIN_DISTANCE = 0.05
_MAX_DISTANCE = 10_000.0

PROJECTION_PERSPECTIVE = "perspective"
PROJECTION_ORTHOGRAPHIC = "orthographic"


class EditorCamera:
    """Orbit-style editor/viewport camera.

    Coordinate convention: right-handed, Y-up (see graphics/math3d.py
    module docstring). Yaw rotates around world +Y; pitch tilts up/down
    and is clamped to avoid the camera flipping through the poles.

    Supports both perspective (default) and true orthographic
    projection (``projection_mode``); orbiting/panning/zooming behave
    identically in both modes so switching modes never destabilizes
    navigation. In orthographic mode, the mouse-wheel zoom (which
    adjusts ``distance``) changes the orthographic frustum's world-
    space height instead of moving the eye closer -- see
    ``get_projection_matrix()``.
    """

    def __init__(
        self,
        target: Vec3 = (0.0, 0.0, 0.0),
        distance: float = 8.0,
        yaw_degrees: float = -40.0,
        pitch_degrees: float = 25.0,
        fov_y_degrees: float = 45.0,
        near: float = 0.01,
        far: float = 5000.0,
        aspect_ratio: float = 1.0,
        projection_mode: str = PROJECTION_PERSPECTIVE,
    ) -> None:
        self.target = np.array(target, dtype=np.float32)
        self.distance = float(distance)
        self.yaw_degrees = float(yaw_degrees)
        self.pitch_degrees = float(pitch_degrees)
        self.fov_y_degrees = float(fov_y_degrees)
        self.near = float(near)
        self.far = float(far)
        self.aspect_ratio = float(aspect_ratio) if aspect_ratio > 0 else 1.0
        self.projection_mode = projection_mode

    # ------------------------------------------------------------------
    def position(self) -> np.ndarray:
        """World-space camera eye position, derived from target/distance/angles."""
        yaw = math.radians(self.yaw_degrees)
        pitch = math.radians(self.pitch_degrees)
        x = self.distance * math.cos(pitch) * math.sin(yaw)
        y = self.distance * math.sin(pitch)
        z = self.distance * math.cos(pitch) * math.cos(yaw)
        return self.target + np.array([x, y, z], dtype=np.float32)

    def forward(self) -> np.ndarray:
        """Unit vector from the camera towards its target."""
        return math3d.normalize(self.target - self.position())

    def right(self) -> np.ndarray:
        world_up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        return math3d.normalize(np.cross(self.forward(), world_up))

    def up(self) -> np.ndarray:
        return math3d.normalize(np.cross(self.right(), self.forward()))

    # ------------------------------------------------------------------
    def get_view_matrix(self) -> np.ndarray:
        eye = self.position()
        return math3d.look_at_matrix(
            tuple(eye), tuple(self.target), (0.0, 1.0, 0.0)
        )

    def get_projection_matrix(self) -> np.ndarray:
        if self.projection_mode == PROJECTION_ORTHOGRAPHIC:
            # Tie the ortho frustum's world-space height to `distance`
            # via the perspective FOV, so switching Perspective<->Ortho
            # (or zooming) keeps roughly the same apparent framing
            # instead of jumping to an arbitrary fixed size.
            view_height = 2.0 * self.distance * math.tan(math.radians(self.fov_y_degrees) / 2.0)
            return math3d.orthographic_matrix_from_height(
                max(view_height, 0.01), self.aspect_ratio, self.near, self.far
            )
        return math3d.perspective_matrix(
            self.fov_y_degrees, self.aspect_ratio, self.near, self.far
        )

    def set_orthographic(self, enabled: bool) -> None:
        self.projection_mode = PROJECTION_ORTHOGRAPHIC if enabled else PROJECTION_PERSPECTIVE

    @property
    def is_orthographic(self) -> bool:
        return self.projection_mode == PROJECTION_ORTHOGRAPHIC

    def set_aspect_ratio(self, width: int, height: int) -> None:
        if height <= 0:
            height = 1
        self.aspect_ratio = width / height

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def orbit(self, delta_yaw_degrees: float, delta_pitch_degrees: float) -> None:
        """Rotate the camera around ``self.target``."""
        self.yaw_degrees = (self.yaw_degrees + delta_yaw_degrees) % 360.0
        self.pitch_degrees = max(
            _MIN_PITCH_DEG, min(_MAX_PITCH_DEG, self.pitch_degrees + delta_pitch_degrees)
        )

    def pan(self, delta_x: float, delta_y: float) -> None:
        """Move the camera (and its target) parallel to the view plane.

        ``delta_x``/``delta_y`` are in the same "world units per pixel"
        scale the caller chooses (the viewport scales these by distance
        so panning feels consistent whether zoomed in or out).
        """
        offset = self.right() * (-delta_x) + self.up() * delta_y
        self.target = self.target + offset

    def zoom(self, delta: float) -> None:
        """Move the camera towards (`delta` > 0) or away from (`delta` < 0)
        the target. In orthographic mode this still adjusts ``distance``,
        which ``get_projection_matrix()`` uses to derive the ortho
        frustum size -- so the same wheel gesture zooms correctly in
        both projection modes.
        """
        self.distance = max(_MIN_DISTANCE, min(_MAX_DISTANCE, self.distance - delta))

    def frame_target(self, center: Vec3, radius: float) -> None:
        """Point the camera at ``center`` with a distance that fits ``radius``."""
        self.target = np.array(center, dtype=np.float32)
        fov_rad = math.radians(max(1.0, self.fov_y_degrees))
        fit_distance = max(radius, 0.01) / math.sin(fov_rad / 2.0)
        self.distance = max(_MIN_DISTANCE, min(_MAX_DISTANCE, fit_distance * 1.5))

    def reset(self) -> None:
        """Restore a sensible default editor view."""
        self.target = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        self.distance = 8.0
        self.yaw_degrees = -40.0
        self.pitch_degrees = 25.0

    def apply_ortho_preset(self, yaw_degrees: float, pitch_degrees: float) -> None:
        """Set yaw/pitch directly (used by the View menu's Front/Top/...
        presets) without touching target/distance/projection mode.
        """
        self.yaw_degrees = yaw_degrees % 360.0
        self.pitch_degrees = max(_MIN_PITCH_DEG, min(_MAX_PITCH_DEG, pitch_degrees))


# ----------------------------------------------------------------------
# Scene camera (a Camera-type SceneObject) -- NOT the EditorCamera.
# ----------------------------------------------------------------------
@dataclass
class SceneCameraSettings:
    """Camera properties stored on a Camera-type SceneObject's
    ``metadata["camera"]`` dict (see core/scene_object.py). Kept as a
    plain, framework-independent dataclass, mirroring ``Material``.
    """

    fov_y_degrees: float = 50.0
    near: float = 0.1
    far: float = 5000.0
    projection: str = PROJECTION_PERSPECTIVE
    ortho_height: float = 10.0

    def __post_init__(self) -> None:
        self.fov_y_degrees = max(1.0, min(179.0, float(self.fov_y_degrees)))
        self.near = max(1e-4, float(self.near))
        self.far = max(self.near + 1e-3, float(self.far))
        self.ortho_height = max(0.01, float(self.ortho_height))
        if self.projection not in (PROJECTION_PERSPECTIVE, PROJECTION_ORTHOGRAPHIC):
            self.projection = PROJECTION_PERSPECTIVE

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fov_y_degrees": self.fov_y_degrees,
            "near": self.near,
            "far": self.far,
            "projection": self.projection,
            "ortho_height": self.ortho_height,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SceneCameraSettings":
        return cls(
            fov_y_degrees=float(data.get("fov_y_degrees", 50.0)),
            near=float(data.get("near", 0.1)),
            far=float(data.get("far", 5000.0)),
            projection=data.get("projection", PROJECTION_PERSPECTIVE),
            ortho_height=float(data.get("ortho_height", 10.0)),
        )

    @classmethod
    def default(cls) -> "SceneCameraSettings":
        return cls()


def scene_camera_view_matrix(position: Vec3, rotation_degrees: Vec3) -> np.ndarray:
    """View matrix for a scene Camera object at ``position``/``rotation_degrees``.

    Convention (documented once, here): the camera looks down its own
    local -Z axis with local +Y as up, exactly like ``EditorCamera``
    and the rest of the app (see graphics/math3d.py module docstring)
    -- rotation is applied the same Euler X->Y->Z order used for every
    other Transform in the app, so a scene Camera object rotates
    exactly the way any other SceneObject would.
    """
    rotation = math3d.rotation_matrix_euler_xyz(*rotation_degrees)
    forward_local = np.array([0.0, 0.0, -1.0, 0.0], dtype=np.float32)
    up_local = np.array([0.0, 1.0, 0.0, 0.0], dtype=np.float32)
    forward_world = (rotation @ forward_local)[:3]
    up_world = (rotation @ up_local)[:3]

    pos = np.array(position, dtype=np.float32)
    target = pos + forward_world
    return math3d.look_at_matrix(tuple(pos), tuple(target), tuple(up_world))


def scene_camera_projection_matrix(
    settings: SceneCameraSettings, aspect_ratio: float
) -> np.ndarray:
    """Projection matrix for a scene Camera object, per its settings."""
    if settings.projection == PROJECTION_ORTHOGRAPHIC:
        return math3d.orthographic_matrix_from_height(
            settings.ortho_height, aspect_ratio, settings.near, settings.far
        )
    return math3d.perspective_matrix(
        settings.fov_y_degrees, aspect_ratio, settings.near, settings.far
    )


class SceneCameraView:
    """Adapts a Camera-type SceneObject to the same duck-typed
    ``get_view_matrix()`` / ``get_projection_matrix()`` / ``position()``
    interface ``EditorCamera`` exposes, so ``OpenGLRenderer.render()``
    can render through either one without any renderer-side branching
    (see ui/viewport.py "Look Through Selected Camera").

    Reads the SceneObject's transform/settings fresh on every call
    (never caches them), so it stays correct across undo/redo,
    Properties-panel edits, and animation playback with no extra
    wiring needed.
    """

    def __init__(self, scene_object: Any, aspect_ratio: float = 1.0) -> None:
        self._scene_object = scene_object
        self.aspect_ratio = aspect_ratio if aspect_ratio > 0 else 1.0

    def _settings(self) -> SceneCameraSettings:
        raw = self._scene_object.metadata.get("camera", {})
        return SceneCameraSettings.from_dict(raw) if raw else SceneCameraSettings.default()

    def position(self) -> np.ndarray:
        return np.array(self._scene_object.transform.position.as_tuple(), dtype=np.float32)

    def get_view_matrix(self) -> np.ndarray:
        transform = self._scene_object.transform
        return scene_camera_view_matrix(
            transform.position.as_tuple(), transform.rotation.as_tuple()
        )

    def get_projection_matrix(self) -> np.ndarray:
        return scene_camera_projection_matrix(self._settings(), self.aspect_ratio)

    def set_aspect_ratio(self, width: int, height: int) -> None:
        self.aspect_ratio = width / height if height > 0 else 1.0
