#version 330 core

in vec3 v_world_normal;
in vec3 v_world_position;
in vec2 v_uv;

// Base (display) color of the object -- logical scene data, set per
// draw call from the object's Material (graphics/material.py), not
// baked into the mesh.
uniform vec3 u_base_color;

// Optional base-color texture (Phase 3: one texture slot, modulated
// with u_base_color -- no PBR texture set, no normal/roughness maps).
uniform sampler2D u_base_texture;
uniform float u_has_texture;   // 0.0 or 1.0

// Simple directional light (one light is enough to make geometry
// visually understandable; see graphics/opengl_renderer.py). Basic
// roughness/metallic hints (Phase 3 material) subtly affect the
// specular term below -- this is still not a real BRDF.
uniform vec3 u_light_direction;   // points FROM the light TOWARDS the surface
uniform vec3 u_light_color;
uniform vec3 u_camera_position;
uniform float u_roughness;
uniform float u_metallic;

// Selection highlight: additively tinted when > 0.
uniform float u_selected;

out vec4 out_color;

void main() {
    vec3 normal = normalize(v_world_normal);
    vec3 to_light = normalize(-u_light_direction);

    vec3 sampled_color = u_base_color;
    if (u_has_texture > 0.5) {
        vec3 tex_color = texture(u_base_texture, v_uv).rgb;
        sampled_color = u_base_color * tex_color;
    }

    float ambient_strength = 0.25;
    vec3 ambient = ambient_strength * u_light_color;

    float diffuse_strength = max(dot(normal, to_light), 0.0);
    vec3 diffuse = diffuse_strength * u_light_color;

    // A small rim/specular-ish term to help read curved surfaces (cheap,
    // not physically based -- Phase 3 explicitly avoids full PBR).
    // Rougher materials get a wider, dimmer highlight; more "metallic"
    // materials get a brighter one -- simple hints, not a real BRDF.
    vec3 view_dir = normalize(u_camera_position - v_world_position);
    vec3 half_vec = normalize(to_light + view_dir);
    float shininess = mix(8.0, 64.0, 1.0 - u_roughness);
    float spec_strength = pow(max(dot(normal, half_vec), 0.0), shininess)
        * mix(0.1, 0.4, u_metallic);

    vec3 lit_color = (ambient + diffuse) * sampled_color + spec_strength * u_light_color;

    // Selection tint: blend towards a bright highlight color without
    // permanently altering the object's actual base color.
    vec3 selection_color = vec3(1.0, 0.65, 0.15);
    lit_color = mix(lit_color, selection_color, u_selected * 0.45);

    out_color = vec4(lit_color, 1.0);
}
