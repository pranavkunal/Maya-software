#version 330 core

// Grid/axis lines are plain colored line segments generated once on
// the CPU (graphics/opengl_renderer.py _build_grid_geometry) and drawn
// with GL_LINES -- there is no per-frame regeneration.
layout(location = 0) in vec3 in_position;
layout(location = 1) in vec3 in_color;

uniform mat4 u_view;
uniform mat4 u_projection;

out vec3 v_color;

void main() {
    v_color = in_color;
    gl_Position = u_projection * u_view * vec4(in_position, 1.0);
}
