#version 330 core

// Used only when rendering into the offscreen picking framebuffer
// (see graphics/opengl_renderer.py::pick). Outputs a flat, unlit color
// that encodes an object index -- never shown on screen.
uniform vec3 u_pick_color;
out vec4 out_color;

void main() {
    out_color = vec4(u_pick_color, 1.0);
}
