"""SceneObject data model.

A SceneObject is a lightweight node in the scene hierarchy. It is
intentionally minimal in Phase 1 -- it only knows its identity,
hierarchy relationships, and its transform. Future phases will attach
richer data (mesh geometry, materials, cameras, lights, skeletons,
animation curves) via the ``components`` and ``metadata`` dictionaries
rather than by growing this class with dozens of optional fields.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core.ids import generate_id
from core.object_types import SceneObjectType
from core.transform import Transform


@dataclass
class SceneObject:
    """A single node in the scene hierarchy.

    Attributes:
        id: Globally-unique, immutable identifier (never the name).
        name: User-facing, editable display name.
        type: The SceneObjectType of this node.
        parent_id: ID of the parent SceneObject, or None for a root.
        children_ids: IDs of direct children, in display order.
        transform: Local position/rotation/scale.
        components: Placeholder for future attached data (Mesh,
            Material, Camera, Light, Skeleton, Animation, ...). Phase 1
            does not populate this, but the field exists so those
            systems can be added without changing this class's shape.
        metadata: Free-form extra data (e.g. {"primitive": "cube"}).
        visible: Whether the object is shown (Display > Show/Hide).
        locked: Reserved for future selection/editing locks.
    """

    name: str
    type: SceneObjectType
    id: str = field(default_factory=generate_id)
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    transform: Transform = field(default_factory=Transform)
    components: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    visible: bool = True
    locked: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": str(self.type),
            "parent_id": self.parent_id,
            "children_ids": list(self.children_ids),
            "transform": self.transform.to_dict(),
            "metadata": dict(self.metadata),
            "visible": self.visible,
            "locked": self.locked,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SceneObject":
        return cls(
            id=data["id"],
            name=data["name"],
            type=SceneObjectType(data["type"]),
            parent_id=data.get("parent_id"),
            children_ids=list(data.get("children_ids", [])),
            transform=Transform.from_dict(data.get("transform", {})),
            metadata=dict(data.get("metadata", {})),
            visible=data.get("visible", True),
            locked=data.get("locked", False),
        )
