"""A minimal, dependency-free observer/signal implementation.

The core and editor packages must remain importable and testable
without PySide6 (e.g. in headless CI). This tiny Signal class gives
Scene/SelectionManager a Qt-Signal-like API (``connect`` / ``emit``)
without importing Qt. UI code connects its Qt slots to these signals
just like it would to a real QSignal.
"""
from __future__ import annotations

from typing import Any, Callable, List


class Signal:
    """A simple synchronous multi-listener callback dispatcher."""

    def __init__(self) -> None:
        self._listeners: List[Callable[..., None]] = []

    def connect(self, listener: Callable[..., None]) -> None:
        if listener not in self._listeners:
            self._listeners.append(listener)

    def disconnect(self, listener: Callable[..., None]) -> None:
        if listener in self._listeners:
            self._listeners.remove(listener)

    def emit(self, *args: Any, **kwargs: Any) -> None:
        # Iterate over a copy so a listener disconnecting itself (or
        # others) during emission doesn't corrupt iteration.
        for listener in list(self._listeners):
            listener(*args, **kwargs)
