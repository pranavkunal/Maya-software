"""Transform data model.

A plain-data representation of position/rotation/scale. Deliberately
framework-agnostic (no Qt, no rendering math library) so it can be
reused by the core scene model, the editor, the serializer, and later
by the Phase 2 renderer/gizmo systems.

Rotation is stored in degrees (Euler XYZ) for Phase 1 simplicity. This
may be replaced by/extended with quaternions in a later phase; the
serializer's version field exists specifically to allow that kind of
evolution.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Tuple


@dataclass
class Vector3:
    """A simple mutable 3-component vector."""

    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def as_tuple(self) -> Tuple[float, float, float]:
        return (self.x, self.y, self.z)

    def to_dict(self) -> Dict[str, float]:
        return {"x": self.x, "y": self.y, "z": self.z}

    @classmethod
    def from_dict(cls, data: Dict[str, float]) -> "Vector3":
        return cls(
            x=float(data.get("x", 0.0)),
            y=float(data.get("y", 0.0)),
            z=float(data.get("z", 0.0)),
        )

    def copy(self) -> "Vector3":
        return Vector3(self.x, self.y, self.z)


@dataclass
class Transform:
    """Position, rotation (degrees), and scale of a scene object."""

    position: Vector3 = field(default_factory=Vector3)
    rotation: Vector3 = field(default_factory=Vector3)
    scale: Vector3 = field(default_factory=lambda: Vector3(1.0, 1.0, 1.0))

    def to_dict(self) -> Dict[str, Dict[str, float]]:
        return {
            "position": self.position.to_dict(),
            "rotation": self.rotation.to_dict(),
            "scale": self.scale.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Dict[str, float]]) -> "Transform":
        return cls(
            position=Vector3.from_dict(data.get("position", {})),
            rotation=Vector3.from_dict(data.get("rotation", {})),
            scale=Vector3.from_dict(data.get("scale", {"x": 1.0, "y": 1.0, "z": 1.0})),
        )

    def copy(self) -> "Transform":
        """Return a deep copy so duplicated objects never share vectors."""
        return Transform(
            position=self.position.copy(),
            rotation=self.rotation.copy(),
            scale=self.scale.copy(),
        )

    def reset(self) -> None:
        """Reset to identity transform (used by Modify > Reset Transform)."""
        self.position = Vector3(0.0, 0.0, 0.0)
        self.rotation = Vector3(0.0, 0.0, 0.0)
        self.scale = Vector3(1.0, 1.0, 1.0)

    def freeze(self) -> None:
        """Placeholder for Modify > Freeze Transform.

        In a full implementation this would bake the current transform
        into child geometry/pivot and reset the transform channels.
        Phase 1 has no geometry to bake into, so this currently just
        resets the transform channels to identity, matching the visual
        effect a user would expect from a freeze on an empty object.
        """
        self.reset()
