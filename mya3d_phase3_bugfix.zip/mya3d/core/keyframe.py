"""Keyframe data model.

A ``Keyframe`` stores a full Transform snapshot (position, rotation,
scale) at a given integer frame. Framework-independent (no Qt/GL),
mirroring the rest of ``core/``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from core.transform import Transform


@dataclass
class Keyframe:
    """A single keyframe: a frame number and the Transform at that frame."""

    frame: int
    transform: Transform

    def to_dict(self) -> Dict[str, Any]:
        return {"frame": self.frame, "transform": self.transform.to_dict()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Keyframe":
        return cls(frame=int(data["frame"]), transform=Transform.from_dict(data.get("transform", {})))

    def copy(self) -> "Keyframe":
        return Keyframe(frame=self.frame, transform=self.transform.copy())
