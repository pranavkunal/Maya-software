"""Scene object type constants.

Kept as a simple str-based enum so serialized scene files remain
human-readable JSON strings ("mesh", "camera", ...) rather than opaque
integers, and so new types can be appended without breaking the
integer ordering of an IntEnum.
"""
from __future__ import annotations

from enum import Enum


class SceneObjectType(str, Enum):
    GROUP = "group"
    NULL = "null"
    CAMERA = "camera"
    LIGHT = "light"
    MESH = "mesh"
    SCENE_ROOT = "scene_root"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


# Mesh sub-types are tracked separately via SceneObject.metadata["primitive"]
# (e.g. "cube", "sphere", "cylinder", "plane") rather than as distinct
# SceneObjectType values, since in later phases all of these will share
# the same underlying Mesh component and differ only in how their
# initial geometry is generated.
MESH_PRIMITIVES = ("cube", "sphere", "cylinder", "plane")
