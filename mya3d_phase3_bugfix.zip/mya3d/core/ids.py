"""Unique identifier generation for scene objects.

Kept isolated so the ID strategy (currently UUID4-based) can be swapped
later (e.g. for deterministic incrementing IDs, or IDs namespaced per
document) without touching SceneObject or Scene.
"""
from __future__ import annotations

import uuid


def generate_id() -> str:
    """Return a new globally-unique identifier as a string.

    Object *names* are never used as identifiers -- names are
    user-facing and can change or collide; IDs must not.
    """
    return uuid.uuid4().hex
