"""Framework-agnostic core data model: Scene, SceneObject, Transform.

Nothing in this package imports Qt/PySide6. It must remain usable in
headless tests and, eventually, in a batch/CLI processing mode.
"""
