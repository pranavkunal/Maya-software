"""Basic keyframe animation: ``AnimationTrack`` + linear interpolation.

Phase 3 scope only: linear interpolation of position/rotation/scale
between the two keyframes surrounding the current frame. Held constant
before the first keyframe and after the last. Bezier/curve
interpolation is explicitly future work -- kept isolated behind
``lerp_transform`` so it can be swapped later without touching
``AnimationTrack`` or the evaluation call sites.

Framework-independent (no Qt/GL), like the rest of ``core/``.
"""
from __future__ import annotations

import bisect
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core.keyframe import Keyframe
from core.transform import Transform, Vector3


def lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation between two scalars."""
    return a + (b - a) * t


def lerp_vector3(a: Vector3, b: Vector3, t: float) -> Vector3:
    return Vector3(lerp(a.x, b.x, t), lerp(a.y, b.y, t), lerp(a.z, b.z, t))


def lerp_transform(a: Transform, b: Transform, t: float) -> Transform:
    """Linearly interpolate two Transforms (Phase 3: plain Euler-angle
    linear interpolation for rotation -- no shortest-path wrapping yet;
    see module docstring).
    """
    return Transform(
        position=lerp_vector3(a.position, b.position, t),
        rotation=lerp_vector3(a.rotation, b.rotation, t),
        scale=lerp_vector3(a.scale, b.scale, t),
    )


@dataclass
class AnimationTrack:
    """Ordered set of keyframes (by frame) for a single SceneObject."""

    object_id: str
    keyframes: List[Keyframe] = field(default_factory=list)

    def _sort(self) -> None:
        self.keyframes.sort(key=lambda kf: kf.frame)

    def insert_keyframe(self, frame: int, transform: Transform) -> Keyframe:
        """Insert a keyframe at ``frame``, replacing one already there."""
        existing = self.get_keyframe_at(frame)
        if existing is not None:
            existing.transform = transform.copy()
            return existing
        kf = Keyframe(frame=frame, transform=transform.copy())
        self.keyframes.append(kf)
        self._sort()
        return kf

    def remove_keyframe(self, frame: int) -> bool:
        existing = self.get_keyframe_at(frame)
        if existing is None:
            return False
        self.keyframes.remove(existing)
        return True

    def get_keyframe_at(self, frame: int) -> Optional[Keyframe]:
        for kf in self.keyframes:
            if kf.frame == frame:
                return kf
        return None

    def frames(self) -> List[int]:
        return [kf.frame for kf in self.keyframes]

    def has_keyframes(self) -> bool:
        return bool(self.keyframes)

    def evaluate(self, frame: float) -> Optional[Transform]:
        """Evaluate the interpolated Transform at ``frame``.

        Returns ``None`` if there are no keyframes at all (caller
        should then fall back to the object's own static Transform).
        Before the first keyframe, returns the first keyframe's value;
        after the last, the last keyframe's value; between two,
        linearly interpolates.
        """
        if not self.keyframes:
            return None
        self._sort()

        if frame <= self.keyframes[0].frame:
            return self.keyframes[0].transform.copy()
        if frame >= self.keyframes[-1].frame:
            return self.keyframes[-1].transform.copy()

        frames = self.frames()
        index = bisect.bisect_right(frames, frame) - 1
        index = max(0, min(index, len(self.keyframes) - 2))
        left = self.keyframes[index]
        right = self.keyframes[index + 1]
        span = right.frame - left.frame
        t = 0.0 if span == 0 else (frame - left.frame) / span
        return lerp_transform(left.transform, right.transform, t)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object_id": self.object_id,
            "keyframes": [kf.to_dict() for kf in self.keyframes],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnimationTrack":
        track = cls(object_id=data["object_id"])
        track.keyframes = [Keyframe.from_dict(d) for d in data.get("keyframes", [])]
        track._sort()
        return track


class AnimationClip:
    """Holds one ``AnimationTrack`` per animated SceneObject.

    Owned by the editor/UI layer (e.g. ``ui/main_window.py``), not by
    ``Scene`` itself -- keeps ``core.Scene`` focused on hierarchy/data
    and animation as a separate, optional concern layered on top,
    matching how ``SelectionManager``/``CommandStack`` are also kept
    outside ``Scene``.
    """

    def __init__(self) -> None:
        self._tracks: Dict[str, AnimationTrack] = {}

    def get_or_create_track(self, object_id: str) -> AnimationTrack:
        track = self._tracks.get(object_id)
        if track is None:
            track = AnimationTrack(object_id=object_id)
            self._tracks[object_id] = track
        return track

    def get_track(self, object_id: str) -> Optional[AnimationTrack]:
        return self._tracks.get(object_id)

    def has_track(self, object_id: str) -> bool:
        track = self._tracks.get(object_id)
        return track is not None and track.has_keyframes()

    def remove_track_if_empty(self, object_id: str) -> None:
        track = self._tracks.get(object_id)
        if track is not None and not track.has_keyframes():
            del self._tracks[object_id]

    def animated_object_ids(self) -> List[str]:
        return [oid for oid, track in self._tracks.items() if track.has_keyframes()]

    def clear(self) -> None:
        self._tracks.clear()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tracks": [
                track.to_dict() for track in self._tracks.values() if track.has_keyframes()
            ]
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnimationClip":
        clip = cls()
        for raw in data.get("tracks", []):
            track = AnimationTrack.from_dict(raw)
            if track.has_keyframes():
                clip._tracks[track.object_id] = track
        return clip
