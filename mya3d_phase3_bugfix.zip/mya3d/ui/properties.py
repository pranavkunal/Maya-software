"""Properties / Inspector dock: shows and edits the selected object's data.

Reads the current selection from ``SelectionManager`` and the object's
data from ``Scene`` -- never from the Outliner directly. Edits are
routed through ``TransformObjectCommand`` so they participate in
undo/redo from day one.
"""
from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDockWidget,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QLabel,
    QLineEdit,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from core.object_types import SceneObjectType
from core.scene import Scene
from core.transform import Transform, Vector3
from editor.commands import CommandStack, RenameObjectCommand, TransformObjectCommand
from editor.selection import SelectionManager
from graphics.camera import (
    PROJECTION_ORTHOGRAPHIC,
    PROJECTION_PERSPECTIVE,
    SceneCameraSettings,
)
from ui.styles import COLOR_TEXT_SECONDARY

logger = logging.getLogger(__name__)


class Vector3Editor(QWidget):
    """Three labeled spin boxes (X/Y/Z) editing a Vector3-shaped value."""

    value_edited = Signal(float, float, float)

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        layout = QGridLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self._spinboxes = {}
        for col, axis in enumerate(("X", "Y", "Z")):
            label = QLabel(axis)
            label.setFixedWidth(12)
            label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY};")
            spin = QDoubleSpinBox()
            spin.setRange(-1_000_000.0, 1_000_000.0)
            spin.setDecimals(3)
            spin.setSingleStep(0.1)
            spin.valueChanged.connect(self._on_any_value_changed)
            layout.addWidget(label, 0, col * 2)
            layout.addWidget(spin, 0, col * 2 + 1)
            self._spinboxes[axis] = spin

        self._emitting = False

    def set_value(self, vector: Vector3) -> None:
        self._emitting = True
        for axis, value in zip(("X", "Y", "Z"), vector.as_tuple()):
            self._spinboxes[axis].blockSignals(True)
            self._spinboxes[axis].setValue(value)
            self._spinboxes[axis].blockSignals(False)
        self._emitting = False

    def value(self) -> Vector3:
        return Vector3(
            self._spinboxes["X"].value(),
            self._spinboxes["Y"].value(),
            self._spinboxes["Z"].value(),
        )

    def set_enabled(self, enabled: bool) -> None:
        for spin in self._spinboxes.values():
            spin.setEnabled(enabled)

    def _on_any_value_changed(self, _value: float) -> None:
        if self._emitting:
            return
        v = self.value()
        self.value_edited.emit(v.x, v.y, v.z)


class PropertiesWidget(QWidget):
    """Shows Name + Transform (Position/Rotation/Scale) for the selection."""

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._scene = scene
        self._selection = selection
        self._command_stack = command_stack
        self._current_object_id: Optional[str] = None
        self._updating_ui = False

        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        outer_layout.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        self._content_layout = QVBoxLayout(content)
        self._content_layout.setContentsMargins(10, 10, 10, 10)
        self._content_layout.setSpacing(10)

        self._empty_label = QLabel("Nothing selected")
        self._empty_label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY};")
        self._empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self._name_edit = QLineEdit()
        self._name_edit.editingFinished.connect(self._on_name_edited)

        form = QFormLayout()
        form.addRow("Name:", self._name_edit)

        self._type_label = QLabel("-")
        self._type_label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY};")
        form.addRow("Type:", self._type_label)

        self._transform_header = QLabel("Transform")
        self._transform_header.setProperty("role", "section-header")

        self._position_editor = Vector3Editor()
        self._rotation_editor = Vector3Editor()
        self._scale_editor = Vector3Editor()
        self._position_editor.value_edited.connect(self._on_transform_edited)
        self._rotation_editor.value_edited.connect(self._on_transform_edited)
        self._scale_editor.value_edited.connect(self._on_transform_edited)

        transform_form = QFormLayout()
        transform_form.addRow("Position:", self._position_editor)
        transform_form.addRow("Rotation:", self._rotation_editor)
        transform_form.addRow("Scale:", self._scale_editor)

        # -- Camera-only fields (FOV/Near/Far/Projection) -----------------
        self._camera_header = QLabel("Camera")
        self._camera_header.setProperty("role", "section-header")

        self._fov_spin = QDoubleSpinBox()
        self._fov_spin.setRange(1.0, 179.0)
        self._fov_spin.setDecimals(1)
        self._fov_spin.setSuffix("\u00b0")
        self._fov_spin.valueChanged.connect(self._on_camera_settings_edited)

        self._near_spin = QDoubleSpinBox()
        self._near_spin.setRange(0.0001, 1_000_000.0)
        self._near_spin.setDecimals(4)
        self._near_spin.valueChanged.connect(self._on_camera_settings_edited)

        self._far_spin = QDoubleSpinBox()
        self._far_spin.setRange(0.01, 10_000_000.0)
        self._far_spin.setDecimals(1)
        self._far_spin.valueChanged.connect(self._on_camera_settings_edited)

        self._projection_combo = QComboBox()
        self._projection_combo.addItems([PROJECTION_PERSPECTIVE.capitalize(), PROJECTION_ORTHOGRAPHIC.capitalize()])
        self._projection_combo.currentTextChanged.connect(self._on_camera_settings_edited)

        camera_form = QFormLayout()
        camera_form.addRow("Field of View:", self._fov_spin)
        camera_form.addRow("Near Clip:", self._near_spin)
        camera_form.addRow("Far Clip:", self._far_spin)
        camera_form.addRow("Projection:", self._projection_combo)

        self._camera_form_container = QWidget()
        camera_container_layout = QVBoxLayout(self._camera_form_container)
        camera_container_layout.setContentsMargins(0, 0, 0, 0)
        camera_container_layout.setSpacing(6)
        camera_container_layout.addWidget(self._camera_header)
        camera_container_layout.addLayout(camera_form)

        self._form_container = QWidget()
        form_container_layout = QVBoxLayout(self._form_container)
        form_container_layout.setContentsMargins(0, 0, 0, 0)
        form_container_layout.setSpacing(10)
        form_container_layout.addLayout(form)
        form_container_layout.addWidget(self._transform_header)
        form_container_layout.addLayout(transform_form)
        form_container_layout.addWidget(self._camera_form_container)
        form_container_layout.addStretch(1)

        self._content_layout.addWidget(self._empty_label)
        self._content_layout.addWidget(self._form_container)

        self._selection.selection_changed.connect(self._on_selection_changed)
        self._scene.object_changed.connect(self._on_object_changed)
        self._scene.object_renamed.connect(self._on_object_changed)
        self._scene.object_removed.connect(self._on_object_removed)

        self._show_selected_object(None)

    # ------------------------------------------------------------------
    def _on_selection_changed(self, selected_ids) -> None:
        primary_id = selected_ids[0] if selected_ids else None
        self._show_selected_object(primary_id)

    def _on_object_changed(self, object_id: str) -> None:
        if object_id == self._current_object_id:
            self._show_selected_object(object_id)

    def _on_object_removed(self, object_id: str) -> None:
        if object_id == self._current_object_id:
            self._show_selected_object(None)

    def _show_selected_object(self, object_id: Optional[str]) -> None:
        self._current_object_id = object_id
        obj = self._scene.get_object(object_id) if object_id else None

        if obj is None:
            self._empty_label.setVisible(True)
            self._form_container.setVisible(False)
            return

        self._empty_label.setVisible(False)
        self._form_container.setVisible(True)

        self._updating_ui = True
        self._name_edit.setText(obj.name)
        self._type_label.setText(str(obj.type).capitalize())
        self._position_editor.set_value(obj.transform.position)
        self._rotation_editor.set_value(obj.transform.rotation)
        self._scale_editor.set_value(obj.transform.scale)

        is_camera = obj.type == SceneObjectType.CAMERA
        self._camera_form_container.setVisible(is_camera)
        if is_camera:
            settings = SceneCameraSettings.from_dict(obj.metadata.get("camera", {}))
            self._fov_spin.setValue(settings.fov_y_degrees)
            self._near_spin.setValue(settings.near)
            self._far_spin.setValue(settings.far)
            self._projection_combo.setCurrentText(settings.projection.capitalize())
        self._updating_ui = False

    # ------------------------------------------------------------------
    def _on_name_edited(self) -> None:
        if self._updating_ui or self._current_object_id is None:
            return
        obj = self._scene.get_object(self._current_object_id)
        if obj is None:
            return
        new_name = self._name_edit.text().strip()
        if not new_name or new_name == obj.name:
            self._name_edit.setText(obj.name)
            return
        self._command_stack.execute(
            RenameObjectCommand(self._scene, self._current_object_id, new_name)
        )

    def _on_transform_edited(self, *_args) -> None:
        if self._updating_ui or self._current_object_id is None:
            return
        new_transform = Transform(
            position=self._position_editor.value(),
            rotation=self._rotation_editor.value(),
            scale=self._scale_editor.value(),
        )
        self._command_stack.execute(
            TransformObjectCommand(self._scene, self._current_object_id, new_transform)
        )

    def _on_camera_settings_edited(self, *_args) -> None:
        if self._updating_ui or self._current_object_id is None:
            return
        obj = self._scene.get_object(self._current_object_id)
        if obj is None or obj.type != SceneObjectType.CAMERA:
            return
        projection = (
            PROJECTION_ORTHOGRAPHIC
            if self._projection_combo.currentText().lower() == PROJECTION_ORTHOGRAPHIC
            else PROJECTION_PERSPECTIVE
        )
        settings = SceneCameraSettings(
            fov_y_degrees=self._fov_spin.value(),
            near=self._near_spin.value(),
            far=self._far_spin.value(),
            projection=projection,
        )
        # Camera settings aren't routed through a Command (unlike
        # Transform edits) -- Phase 3 scope keeps this a direct,
        # non-undoable edit, matching Modify > Freeze/Reset Transform's
        # existing precedent for scene mutations outside the transform
        # undo system.
        obj.metadata["camera"] = settings.to_dict()
        self._scene.notify_changed(self._current_object_id)


class PropertiesDock(QDockWidget):
    """Dock wrapper hosting the PropertiesWidget."""

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__("Properties", parent)
        self.setObjectName("PropertiesDock")
        self.panel = PropertiesWidget(scene, selection, command_stack, self)
        self.setWidget(self.panel)
        self.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
            | QDockWidget.DockWidgetFeature.DockWidgetClosable
        )
