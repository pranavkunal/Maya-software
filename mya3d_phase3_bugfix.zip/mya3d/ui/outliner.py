"""Outliner dock: shows the scene hierarchy as a tree.

The Outliner never talks to the Properties panel directly -- it only
reads from ``Scene`` and writes to ``SelectionManager``. Both docks
independently observe those two models, per the "central selection
model" requirement.
"""
from __future__ import annotations

import logging
from typing import Dict, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDockWidget,
    QMenu,
    QTreeWidget,
    QTreeWidgetItem,
    QWidget,
)

from core.scene import Scene
from core.scene_object import SceneObject
from editor.commands import CommandStack, DeleteObjectCommand, RenameObjectCommand
from editor.selection import SelectionManager

logger = logging.getLogger(__name__)

_OBJECT_ID_ROLE = Qt.ItemDataRole.UserRole + 1


class OutlinerWidget(QTreeWidget):
    """Tree view of the scene hierarchy, backed by ``Scene``."""

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._scene = scene
        self._selection = selection
        self._command_stack = command_stack
        self._items_by_id: Dict[str, QTreeWidgetItem] = {}
        self._syncing_selection = False

        self.setHeaderHidden(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setAlternatingRowColors(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.setEditTriggers(
            QAbstractItemView.EditTrigger.EditKeyPressed
            | QAbstractItemView.EditTrigger.SelectedClicked
        )

        # Qt signals (widget <-> our own handlers)
        self.itemSelectionChanged.connect(self._on_tree_selection_changed)
        self.itemChanged.connect(self._on_item_edited)
        self.customContextMenuRequested.connect(self._on_context_menu_requested)

        # Domain signals (Scene / SelectionManager -> widget)
        self._scene.object_added.connect(self._on_object_added)
        self._scene.object_removed.connect(self._on_object_removed)
        self._scene.object_renamed.connect(self._on_object_renamed)
        self._scene.scene_reset.connect(self.rebuild_from_scene)
        self._selection.selection_changed.connect(self._on_external_selection_changed)

        self.rebuild_from_scene()

    # ------------------------------------------------------------------
    def rebuild_from_scene(self) -> None:
        self.blockSignals(True)
        self.clear()
        self._items_by_id.clear()
        for root in self._scene.children_of(None):
            self._add_item_recursive(root, None)
        self.expandAll()
        self.blockSignals(False)

    def _add_item_recursive(self, obj: SceneObject, parent_item: Optional[QTreeWidgetItem]) -> None:
        item = QTreeWidgetItem([obj.name])
        item.setData(0, _OBJECT_ID_ROLE, obj.id)
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
        if parent_item is None:
            self.addTopLevelItem(item)
        else:
            parent_item.addChild(item)
        self._items_by_id[obj.id] = item
        for child in self._scene.children_of(obj.id):
            self._add_item_recursive(child, item)

    # ------------------------------------------------------------------
    # Scene -> widget
    # ------------------------------------------------------------------
    def _on_object_added(self, obj: SceneObject) -> None:
        parent_item = self._items_by_id.get(obj.parent_id) if obj.parent_id else None
        self.blockSignals(True)
        self._add_item_recursive(obj, parent_item)
        self.blockSignals(False)

    def _on_object_removed(self, object_id: str) -> None:
        item = self._items_by_id.pop(object_id, None)
        if item is None:
            return
        self.blockSignals(True)
        parent = item.parent()
        if parent is not None:
            parent.removeChild(item)
        else:
            index = self.indexOfTopLevelItem(item)
            if index >= 0:
                self.takeTopLevelItem(index)
        self.blockSignals(False)

    def _on_object_renamed(self, object_id: str) -> None:
        item = self._items_by_id.get(object_id)
        obj = self._scene.get_object(object_id)
        if item is None or obj is None:
            return
        self.blockSignals(True)
        item.setText(0, obj.name)
        self.blockSignals(False)

    # ------------------------------------------------------------------
    # SelectionManager -> widget
    # ------------------------------------------------------------------
    def _on_external_selection_changed(self, selected_ids) -> None:
        if self._syncing_selection:
            return
        self._syncing_selection = True
        self.blockSignals(True)
        self.clearSelection()
        for object_id in selected_ids:
            item = self._items_by_id.get(object_id)
            if item is not None:
                item.setSelected(True)
        self.blockSignals(False)
        self._syncing_selection = False

    # ------------------------------------------------------------------
    # widget -> SelectionManager
    # ------------------------------------------------------------------
    def _on_tree_selection_changed(self) -> None:
        if self._syncing_selection:
            return
        self._syncing_selection = True
        ids = [item.data(0, _OBJECT_ID_ROLE) for item in self.selectedItems()]
        self._selection.select_multiple(ids)
        self._syncing_selection = False

    def _on_item_edited(self, item: QTreeWidgetItem, column: int) -> None:
        object_id = item.data(0, _OBJECT_ID_ROLE)
        obj = self._scene.get_object(object_id)
        if obj is None:
            return
        new_name = item.text(0).strip()
        if not new_name:
            # Reject empty names: restore the previous name.
            self.blockSignals(True)
            item.setText(0, obj.name)
            self.blockSignals(False)
            return
        if new_name == obj.name:
            return
        self._command_stack.execute(RenameObjectCommand(self._scene, object_id, new_name))

    # ------------------------------------------------------------------
    def _on_context_menu_requested(self, pos) -> None:
        item = self.itemAt(pos)
        menu = QMenu(self)
        if item is not None:
            object_id = item.data(0, _OBJECT_ID_ROLE)
            rename_action = menu.addAction("Rename")
            rename_action.triggered.connect(lambda: self.editItem(item, 0))
            delete_action = menu.addAction("Delete")
            delete_action.triggered.connect(lambda: self._delete_object(object_id))
            menu.addSeparator()
        # Placeholder for future context actions (Group, Parent, Duplicate...)
        placeholder = menu.addAction("More actions coming in a future phase")
        placeholder.setEnabled(False)
        menu.exec(self.viewport().mapToGlobal(pos))

    def _delete_object(self, object_id: str) -> None:
        if object_id not in self._scene:
            return
        self._command_stack.execute(DeleteObjectCommand(self._scene, object_id))
        self._selection.clear_if_selected(object_id)


class OutlinerDock(QDockWidget):
    """Dock wrapper hosting the OutlinerWidget."""

    def __init__(
        self,
        scene: Scene,
        selection: SelectionManager,
        command_stack: CommandStack,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__("Outliner", parent)
        self.setObjectName("OutlinerDock")
        self.tree = OutlinerWidget(scene, selection, command_stack, self)
        self.setWidget(self.tree)
        self.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
            | QDockWidget.DockWidgetFeature.DockWidgetClosable
        )
