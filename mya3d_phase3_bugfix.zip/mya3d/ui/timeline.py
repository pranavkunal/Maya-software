"""Timeline dock: frame range, current-frame scrubber, transport
controls, keyframe markers, and QTimer-driven playback.

``TimelineState`` models current/start/end frame as real data (not
just UI widget state), independent of Qt, so it was already ready for
a real keyframe editor to be layered on top -- this is that layer.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from ui.styles import COLOR_ACCENT, COLOR_BG_PANEL_ALT, COLOR_BORDER_LIGHT

logger = logging.getLogger(__name__)

DEFAULT_FPS = 24


class TimelineState:
    """Plain data holder for the current animation range/frame.

    Deliberately Qt-independent (mirrors the core/editor pattern).
    """

    def __init__(self, start_frame: int = 1, end_frame: int = 120, current_frame: int = 1) -> None:
        self.start_frame = start_frame
        self.end_frame = end_frame
        self.current_frame = current_frame

    def clamp_current(self) -> None:
        self.current_frame = max(self.start_frame, min(self.end_frame, self.current_frame))


class KeyframeTrackWidget(QWidget):
    """A thin strip painted with diamond markers at each keyframe frame
    of the current selection, aligned under the frame scrubber above
    it. Clicking a marker (or anywhere on the track) jumps the current
    frame there.
    """

    frame_clicked = Signal(int)

    def __init__(self, state: TimelineState, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.state = state
        self._keyframe_frames: List[int] = []
        self.setFixedHeight(16)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setToolTip("Keyframes for the selected object")

    def set_keyframe_frames(self, frames: List[int]) -> None:
        self._keyframe_frames = sorted(frames)
        self.update()

    def _frame_to_x(self, frame: int) -> float:
        span = max(1, self.state.end_frame - self.state.start_frame)
        t = (frame - self.state.start_frame) / span
        return t * max(1, self.width() - 1)

    def _x_to_frame(self, x: float) -> int:
        span = max(1, self.state.end_frame - self.state.start_frame)
        t = x / max(1, self.width() - 1)
        return round(self.state.start_frame + t * span)

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt override)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor(COLOR_BG_PANEL_ALT))

        pen = QPen(QColor(COLOR_BORDER_LIGHT))
        painter.setPen(pen)
        painter.drawLine(0, self.height() // 2, self.width(), self.height() // 2)

        diamond_color = QColor(COLOR_ACCENT)
        painter.setBrush(diamond_color)
        painter.setPen(Qt.PenStyle.NoPen)
        half = 5.0
        cy = self.height() / 2.0
        for frame in self._keyframe_frames:
            if not (self.state.start_frame <= frame <= self.state.end_frame):
                continue
            cx = self._frame_to_x(frame)
            painter.save()
            painter.translate(cx, cy)
            painter.rotate(45.0)
            painter.drawRect(QRectF(-half / 1.4, -half / 1.4, half * 1.4, half * 1.4))
            painter.restore()
        painter.end()

    def mousePressEvent(self, event) -> None:  # noqa: N802 (Qt override)
        frame = self._x_to_frame(event.position().x())
        self.frame_clicked.emit(frame)
        super().mousePressEvent(event)


class TimelineWidget(QWidget):
    """Frame scrubber, transport controls, and keyframe track."""

    frame_changed = Signal(int)
    play_requested = Signal()
    pause_requested = Signal()
    stop_requested = Signal()

    def __init__(self, state: Optional[TimelineState] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.state = state or TimelineState()
        self._is_playing = False
        self.fps = DEFAULT_FPS

        self._playback_timer = QTimer(self)
        self._playback_timer.timeout.connect(self._advance_playback_frame)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 6, 8, 6)
        outer.setSpacing(4)

        outer.addWidget(self._build_transport_row())
        outer.addWidget(self._build_scrub_row())

        self.keyframe_track = KeyframeTrackWidget(self.state, self)
        self.keyframe_track.frame_clicked.connect(self._set_current_frame)
        outer.addWidget(self.keyframe_track)

    # ------------------------------------------------------------------
    def _build_transport_row(self) -> QWidget:
        row = QWidget(self)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.start_frame_spin = QSpinBox()
        self.start_frame_spin.setRange(-100000, 100000)
        self.start_frame_spin.setValue(self.state.start_frame)
        self.start_frame_spin.setToolTip("Start Frame")
        self.start_frame_spin.valueChanged.connect(self._on_start_frame_changed)

        self.end_frame_spin = QSpinBox()
        self.end_frame_spin.setRange(-100000, 100000)
        self.end_frame_spin.setValue(self.state.end_frame)
        self.end_frame_spin.setToolTip("End Frame")
        self.end_frame_spin.valueChanged.connect(self._on_end_frame_changed)

        self.btn_go_start = QPushButton("|\u25c0")
        self.btn_go_start.setToolTip("Go to Start Frame")
        self.btn_go_start.setFixedWidth(32)
        self.btn_go_start.clicked.connect(self._go_to_start)

        self.btn_prev_frame = QPushButton("\u25c0")
        self.btn_prev_frame.setToolTip("Previous Frame")
        self.btn_prev_frame.setFixedWidth(32)
        self.btn_prev_frame.clicked.connect(self._go_to_previous_frame)

        self.btn_play = QPushButton("\u25b6")
        self.btn_play.setToolTip("Play")
        self.btn_play.setFixedWidth(32)
        self.btn_play.clicked.connect(self._on_play_clicked)

        self.btn_pause = QPushButton("\u23f8")
        self.btn_pause.setToolTip("Pause")
        self.btn_pause.setFixedWidth(32)
        self.btn_pause.clicked.connect(self._on_pause_clicked)

        self.btn_stop = QPushButton("\u25a0")
        self.btn_stop.setToolTip("Stop (pause and return to Start Frame)")
        self.btn_stop.setFixedWidth(32)
        self.btn_stop.clicked.connect(self._on_stop_clicked)

        self.btn_next_frame = QPushButton("\u25b6")
        self.btn_next_frame.setToolTip("Next Frame")
        self.btn_next_frame.setFixedWidth(32)
        self.btn_next_frame.clicked.connect(self._go_to_next_frame)

        self.btn_go_end = QPushButton("\u25b6|")
        self.btn_go_end.setToolTip("Go to End Frame")
        self.btn_go_end.setFixedWidth(32)
        self.btn_go_end.clicked.connect(self._go_to_end)

        self.current_frame_spin = QSpinBox()
        self.current_frame_spin.setRange(-100000, 100000)
        self.current_frame_spin.setValue(self.state.current_frame)
        self.current_frame_spin.setToolTip("Current Frame")
        self.current_frame_spin.valueChanged.connect(self._on_current_frame_spin_changed)

        layout.addWidget(QLabel("Start:"))
        layout.addWidget(self.start_frame_spin)
        layout.addWidget(self.btn_go_start)
        layout.addWidget(self.btn_prev_frame)
        layout.addWidget(self.btn_play)
        layout.addWidget(self.btn_pause)
        layout.addWidget(self.btn_stop)
        layout.addWidget(self.btn_next_frame)
        layout.addWidget(self.btn_go_end)
        layout.addWidget(QLabel("End:"))
        layout.addWidget(self.end_frame_spin)
        layout.addStretch(1)
        layout.addWidget(QLabel("Frame:"))
        layout.addWidget(self.current_frame_spin)
        return row

    def _build_scrub_row(self) -> QWidget:
        row = QWidget(self)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.scrub_slider = QSlider(Qt.Orientation.Horizontal)
        self.scrub_slider.setMinimum(self.state.start_frame)
        self.scrub_slider.setMaximum(max(self.state.start_frame, self.state.end_frame))
        self.scrub_slider.setValue(self.state.current_frame)
        self.scrub_slider.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.scrub_slider.valueChanged.connect(self._on_slider_changed)
        self.scrub_slider.setToolTip("Timeline")

        layout.addWidget(self.scrub_slider)
        return row

    # ------------------------------------------------------------------
    def set_keyframe_frames(self, frames: List[int]) -> None:
        """Called by MainWindow whenever the selection or its keyframes
        change, so the track always reflects the currently-selected
        object's AnimationTrack (see core/animation.py).
        """
        self.keyframe_track.set_keyframe_frames(frames)

    def set_fps(self, fps: int) -> None:
        self.fps = max(1, int(fps))
        if self._is_playing:
            self._playback_timer.setInterval(int(1000 / self.fps))

    # ------------------------------------------------------------------
    def _set_current_frame(self, frame: int, *, from_widget: Optional[QWidget] = None) -> None:
        frame = max(self.state.start_frame, min(self.state.end_frame, frame))
        if frame == self.state.current_frame:
            return
        self.state.current_frame = frame

        if from_widget is not self.current_frame_spin:
            self.current_frame_spin.blockSignals(True)
            self.current_frame_spin.setValue(frame)
            self.current_frame_spin.blockSignals(False)
        if from_widget is not self.scrub_slider:
            self.scrub_slider.blockSignals(True)
            self.scrub_slider.setValue(frame)
            self.scrub_slider.blockSignals(False)

        self.frame_changed.emit(frame)
        self.keyframe_track.update()

    def _on_current_frame_spin_changed(self, value: int) -> None:
        self._set_current_frame(value, from_widget=self.current_frame_spin)

    def _on_slider_changed(self, value: int) -> None:
        self._set_current_frame(value, from_widget=self.scrub_slider)

    def _on_start_frame_changed(self, value: int) -> None:
        self.state.start_frame = value
        self.scrub_slider.setMinimum(value)
        self.state.clamp_current()
        self.keyframe_track.update()

    def _on_end_frame_changed(self, value: int) -> None:
        self.state.end_frame = value
        self.scrub_slider.setMaximum(max(self.state.start_frame, value))
        self.state.clamp_current()
        self.keyframe_track.update()

    def _go_to_start(self) -> None:
        self._set_current_frame(self.state.start_frame)

    def _go_to_end(self) -> None:
        self._set_current_frame(self.state.end_frame)

    def _go_to_previous_frame(self) -> None:
        self._set_current_frame(self.state.current_frame - 1)

    def _go_to_next_frame(self) -> None:
        self._set_current_frame(self.state.current_frame + 1)

    # ------------------------------------------------------------------
    # Playback (Play / Pause / Stop) -- driven by a QTimer, never a
    # blocking loop, so the UI stays fully responsive while playing.
    # ------------------------------------------------------------------
    def _on_play_clicked(self) -> None:
        if self._is_playing:
            return
        self._is_playing = True
        self._playback_timer.start(int(1000 / self.fps))
        self.play_requested.emit()

    def _on_pause_clicked(self) -> None:
        if not self._is_playing:
            return
        self._is_playing = False
        self._playback_timer.stop()
        self.pause_requested.emit()

    def _on_stop_clicked(self) -> None:
        self._is_playing = False
        self._playback_timer.stop()
        self._set_current_frame(self.state.start_frame)
        self.stop_requested.emit()

    def _advance_playback_frame(self) -> None:
        next_frame = self.state.current_frame + 1
        if next_frame > self.state.end_frame:
            next_frame = self.state.start_frame
        self._set_current_frame(next_frame)

    @property
    def is_playing(self) -> bool:
        return self._is_playing


class TimelineDock(QDockWidget):
    """Dock wrapper hosting the TimelineWidget."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__("Timeline", parent)
        self.setObjectName("TimelineDock")
        self.timeline = TimelineWidget(parent=self)
        self.setWidget(self.timeline)
        self.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
            | QDockWidget.DockWidgetFeature.DockWidgetClosable
        )
