"""Qt/PySide6 widgets: main window, docks, toolbar, and theme."""
