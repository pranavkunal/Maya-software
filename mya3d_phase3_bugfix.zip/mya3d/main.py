#!/usr/bin/env python3
"""MYA 3D Editor entry point.

Kept intentionally thin: bootstraps logging + QApplication, creates
the MainWindow, and starts the Qt event loop. All real logic lives in
app/, core/, editor/, ui/, io/, and graphics/.
"""
from __future__ import annotations

import logging
import sys

from app.application import configure_logging, create_application
from ui.main_window import MainWindow

logger = logging.getLogger(__name__)


def main() -> int:
    configure_logging()
    logger.info("Starting MYA 3D Editor")

    app = create_application(sys.argv)

    window = MainWindow()
    window.show()

    logger.info("Entering Qt event loop")
    exit_code = app.exec()

    logger.info("MYA 3D Editor shutting down (exit code %s)", exit_code)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
