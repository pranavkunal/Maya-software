"""Foundation of the editor's undo/redo command system.

Phase 1 defines the ``Command`` interface and a ``CommandStack`` that
already supports execute/undo/redo, plus concrete commands for the
operations Phase 1 actually performs (create/delete/rename/transform
an object). This lets object creation etc. be wired through the stack
from day one instead of being retrofitted later.

Any future command (mesh edits, keyframe edits, material edits, ...)
only needs to subclass ``Command`` and implement ``do``/``undo``.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import List, Optional

from core.object_types import SceneObjectType
from core.scene import Scene
from core.scene_object import SceneObject
from core.transform import Transform

logger = logging.getLogger(__name__)


class Command(ABC):
    """Base class for all undoable editor operations."""

    #: Short human-readable label, e.g. for an "Undo Create Object" menu item.
    label: str = "Command"

    @abstractmethod
    def do(self) -> None:
        """Perform (or re-perform, on redo) the operation."""

    @abstractmethod
    def undo(self) -> None:
        """Reverse the operation performed by ``do``."""


class CommandStack:
    """Maintains undo/redo history and executes commands through it."""

    def __init__(self, max_history: int = 200) -> None:
        self._undo_stack: List[Command] = []
        self._redo_stack: List[Command] = []
        self._max_history = max_history

    def execute(self, command: Command) -> None:
        command.do()
        self._undo_stack.append(command)
        self._redo_stack.clear()
        if len(self._undo_stack) > self._max_history:
            self._undo_stack.pop(0)
        logger.debug("Executed command: %s", command.label)

    def undo(self) -> bool:
        if not self._undo_stack:
            return False
        command = self._undo_stack.pop()
        command.undo()
        self._redo_stack.append(command)
        logger.debug("Undid command: %s", command.label)
        return True

    def redo(self) -> bool:
        if not self._redo_stack:
            return False
        command = self._redo_stack.pop()
        command.do()
        self._undo_stack.append(command)
        logger.debug("Redid command: %s", command.label)
        return True

    def can_undo(self) -> bool:
        return bool(self._undo_stack)

    def can_redo(self) -> bool:
        return bool(self._redo_stack)

    def clear(self) -> None:
        self._undo_stack.clear()
        self._redo_stack.clear()


# ----------------------------------------------------------------------
# Concrete Phase 1 commands
# ----------------------------------------------------------------------
class CreateObjectCommand(Command):
    """Creates a new SceneObject of a given type/name in the scene."""

    label = "Create Object"

    def __init__(
        self,
        scene: Scene,
        name: str,
        object_type: SceneObjectType,
        transform: Optional[Transform] = None,
        parent_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> None:
        self._scene = scene
        self._name = name
        self._object_type = object_type
        self._transform = transform or Transform()
        self._parent_id = parent_id
        self._metadata = metadata or {}
        self._created_object: Optional[SceneObject] = None

    def do(self) -> None:
        if self._created_object is None:
            obj = SceneObject(
                name=self._name,
                type=self._object_type,
                transform=self._transform,
                metadata=self._metadata,
            )
            self._created_object = obj
        else:
            # Re-creating on redo: same id/name so downstream state
            # (e.g. selection) can reference it consistently.
            obj = self._created_object
        self._scene.add_object(obj, parent_id=self._parent_id)
        self.label = f"Create {self._name}"

    def undo(self) -> None:
        if self._created_object is not None:
            self._scene.remove_object(self._created_object.id)

    @property
    def created_object(self) -> Optional[SceneObject]:
        return self._created_object


class DeleteObjectCommand(Command):
    """Deletes an object (and its descendants) from the scene."""

    label = "Delete Object"

    def __init__(self, scene: Scene, object_id: str) -> None:
        self._scene = scene
        self._object_id = object_id
        self._removed_object: Optional[SceneObject] = None
        self._parent_id: Optional[str] = None

    def do(self) -> None:
        obj = self._scene.require_object(self._object_id)
        self._removed_object = obj
        self._parent_id = obj.parent_id
        self.label = f"Delete {obj.name}"
        self._scene.remove_object(self._object_id)

    def undo(self) -> None:
        if self._removed_object is not None:
            self._scene.add_object(self._removed_object, parent_id=self._parent_id)


class RenameObjectCommand(Command):
    """Renames an object, preserving its id."""

    label = "Rename Object"

    def __init__(self, scene: Scene, object_id: str, new_name: str) -> None:
        self._scene = scene
        self._object_id = object_id
        self._new_name = new_name
        self._old_name: Optional[str] = None

    def do(self) -> None:
        obj = self._scene.require_object(self._object_id)
        self._old_name = obj.name
        self._scene.rename_object(self._object_id, self._new_name)
        self.label = f"Rename to {self._new_name}"

    def undo(self) -> None:
        if self._old_name is not None:
            self._scene.rename_object(self._object_id, self._old_name)


class DuplicateObjectCommand(Command):
    """Duplicates an object with a new id, unique name, and independent Transform."""

    label = "Duplicate Object"

    def __init__(self, scene: Scene, object_id: str) -> None:
        self._scene = scene
        self._object_id = object_id
        self._duplicate_object: Optional[SceneObject] = None

    def do(self) -> None:
        if self._duplicate_object is None:
            duplicate = self._scene.duplicate_object(self._object_id)
            self._duplicate_object = duplicate
            self.label = f"Duplicate {duplicate.name}"
        else:
            # Redo: re-insert the same duplicate object (same id/name)
            # rather than generating a new one, so redo is idempotent.
            original = self._scene.require_object(self._object_id)
            self._scene.add_object(self._duplicate_object, parent_id=original.parent_id)

    def undo(self) -> None:
        if self._duplicate_object is not None:
            self._scene.remove_object(self._duplicate_object.id)

    @property
    def duplicate_object(self) -> Optional[SceneObject]:
        return self._duplicate_object


class TransformObjectCommand(Command):
    """Sets an object's transform to a new value, remembering the old one."""

    label = "Transform Object"

    def __init__(self, scene: Scene, object_id: str, new_transform: Transform) -> None:
        self._scene = scene
        self._object_id = object_id
        self._new_transform = new_transform.copy()
        self._old_transform: Optional[Transform] = None

    def do(self) -> None:
        obj = self._scene.require_object(self._object_id)
        if self._old_transform is None:
            self._old_transform = obj.transform.copy()
        obj.transform = self._new_transform.copy()
        self._scene.notify_changed(self._object_id)

    def undo(self) -> None:
        if self._old_transform is not None:
            obj = self._scene.require_object(self._object_id)
            obj.transform = self._old_transform.copy()
            self._scene.notify_changed(self._object_id)
