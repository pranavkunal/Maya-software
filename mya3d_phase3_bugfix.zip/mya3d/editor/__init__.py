"""Editor logic: selection state, active tool state, undo/redo commands.

Sits between core (pure data) and ui (Qt widgets). Also Qt-independent.
"""
