"""Editor transform tools.

Phase 1 only tracks *which* tool is active (for toolbar UI state and
the status bar) -- it does not yet manipulate the viewport, since
there is no real 3D viewport or gizmo system yet. Phase 2's gizmos
will read ``ToolManager.active_tool`` to decide what to draw/drag.
"""
from __future__ import annotations

import logging
from enum import Enum

from core.signal import Signal

logger = logging.getLogger(__name__)


class ToolType(str, Enum):
    SELECT = "select"
    MOVE = "move"
    ROTATE = "rotate"
    SCALE = "scale"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


class ToolManager:
    """Tracks the single currently-active editor tool."""

    def __init__(self, initial_tool: ToolType = ToolType.SELECT) -> None:
        self._active_tool = initial_tool
        self.tool_changed: Signal = Signal()

    @property
    def active_tool(self) -> ToolType:
        return self._active_tool

    def set_active_tool(self, tool: ToolType) -> None:
        if tool != self._active_tool:
            self._active_tool = tool
            logger.debug("Active tool changed to: %s", tool)
            self.tool_changed.emit(tool)
