"""Central selection state, shared between Outliner, Properties, and
(in later phases) the Viewport.

Widgets must never poke each other directly (e.g. Outliner must not
call into Properties). Instead everything reads/writes through a
single SelectionManager and reacts to its ``selection_changed`` signal.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from core.signal import Signal

logger = logging.getLogger(__name__)


class SelectionManager:
    """Tracks which scene object id(s) are currently selected.

    Phase 1 supports multi-selection storage (a list, order preserved,
    no duplicates) even though most Phase 1 UI only actively uses the
    primary (first) selected object -- this avoids a data-model change
    when the Viewport gains marquee/ctrl-click multi-select later.
    """

    def __init__(self) -> None:
        self._selected_ids: List[str] = []
        self.selection_changed: Signal = Signal()

    # ------------------------------------------------------------------
    def select(self, object_id: str) -> None:
        """Replace the current selection with a single object."""
        self._selected_ids = [object_id]
        logger.debug("Selection set to: %s", object_id)
        self.selection_changed.emit(self.selected_ids())

    def select_multiple(self, object_ids: List[str]) -> None:
        """Replace the current selection with a list of objects."""
        seen = []
        for oid in object_ids:
            if oid not in seen:
                seen.append(oid)
        self._selected_ids = seen
        logger.debug("Selection set to multiple: %s", seen)
        self.selection_changed.emit(self.selected_ids())

    def add_to_selection(self, object_id: str) -> None:
        if object_id not in self._selected_ids:
            self._selected_ids.append(object_id)
            self.selection_changed.emit(self.selected_ids())

    def deselect(self, object_id: str) -> None:
        if object_id in self._selected_ids:
            self._selected_ids.remove(object_id)
            logger.debug("Deselected: %s", object_id)
            self.selection_changed.emit(self.selected_ids())

    def deselect_all(self) -> None:
        if self._selected_ids:
            self._selected_ids = []
            logger.debug("Selection cleared")
            self.selection_changed.emit(self.selected_ids())

    def clear_if_selected(self, object_id: str) -> None:
        """Remove ``object_id`` from the selection if present.

        Used when an object is deleted so selection never references a
        stale/removed id.
        """
        self.deselect(object_id)

    # ------------------------------------------------------------------
    def selected_ids(self) -> List[str]:
        return list(self._selected_ids)

    def primary_selected_id(self) -> Optional[str]:
        return self._selected_ids[0] if self._selected_ids else None

    def is_selected(self, object_id: str) -> bool:
        return object_id in self._selected_ids

    def has_selection(self) -> bool:
        return bool(self._selected_ids)
